import React from "react";
import { compose, withState, withHandlers } from "recompose";

import { Input, OptionList } from "../views";
import months from "../../assets/months.json";

const dateEnhancer = compose(
  withState("date", "_setDate", ({ value }) => value),
  withHandlers({
    onChange: ({ _setDate, onChange }) => value => {
      _setDate(value);
      onChange(value);
    }
  })
);

export const Calendar = ({
  label,
  date: { day = "", month = {}, year = "" } = {},
  onChange,
  onBlur,
  error
}) => (
  <div className="form-group">
    <label htmlFor="day" className="gray-small-text">
      {label}
    </label>
    <div
      className={`datetime ${error &&
        "has-error"} d-flex flex-row justify-content-between flex-wrap`}
    >
      <div className="col-3 datetime__item day">
        <Input
          className=""
          type="tel"
          placeholder="Tanggal"
          value={day}
          maxLength={2}
          onChange={day => onChange({ day, month, year })}
        />
      </div>
      <div className="col-5 datetime__item month">
        <OptionList
          dataList={months}
          dialogTitle="Pilih Bulan"
          value={(month && month.value) || ""}
          onChange={month => onChange({ day, month, year })}
          hint="Pilih Bulan"
        />
      </div>
      <div className="col-3 datetime__item year">
        <Input
          className=""
          type="tel"
          placeholder="Tahun"
          value={year}
          maxLength={4}
          onChange={year => onChange({ day, month, year })}
          onBlur={year => onBlur({ day, month, year })}
        />
      </div>
    </div>
    {error && (
      <div className="has-error">
        <span className="help-block with-errors">{error}</span>
      </div>
    )}
  </div>
);

export const CalendarEnhancer = dateEnhancer(Calendar);
