import React from "react";
import { Radio } from "./";

export const List = ({ name, dataList, value, onChange }) => (
  <ul className="list-selection-cursor">
    {dataList.map(item => (
      <li key={item.key} data-dismiss="modal">
        <Radio
          name={name}
          value={item.value}
          isChecked={value === item.value}
          onClick={() => onChange(item)}
        />
      </li>
    ))}
  </ul>
);
