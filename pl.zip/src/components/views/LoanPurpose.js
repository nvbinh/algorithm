import React from "react";
import { withState, withHandlers, compose } from "recompose";
import { ScreenDimension, OptionList, ImageOption } from "./";

const WIDTH_MOBILE = 767;

const imageValueSelected = compose(
  withState("value", "_onChange", ({value}) => value),
  withHandlers({
    onChange: ({ _onChange, onChange }) => value => {
      _onChange(value);
      onChange(value);
    }
  })
);

const LoanPurposeOptionImage = imageValueSelected(({ value = {}, onChange, loanPurposes = [], error = "" }) => (
  <div className={`row loan-destination d-none d-sm-block ${error && "has-error"}`}>
    <div className="loan-objective__container col-12">
      <label>Pilih Tujuan Pinjaman</label>
      <div className={`options-list ${(value.key && "blur") || ""} ${(error && "validate") || ""}`}>
        {loanPurposes
          .map(item => ({
            ...item,
            imgPath: `icon-${item.value.toLowerCase()}.svg`
          }))
          .map(item => (

            <ImageOption
              checked={Object.keys(value).length === 0 ? void 0 : item.key === value.key }
              item={item}
              key={item.key}
              onChange={item => onChange && onChange(item)}
            />
          ))}
      </div>
      {error && <span className="help-block with-errors clear-both">{error}</span>}
    </div>
  </div>
));

export const LoanPurpose = ({ loanPurposes, ...props }) => (
  <ScreenDimension>
    {({ width }) =>
      (width > WIDTH_MOBILE && <LoanPurposeOptionImage loanPurposes={loanPurposes} {...props} />) || (
        <div className="loan-destination-mobile row d-block">
          <div className="loan-objective-mobile__container col-12">
            <OptionList
              className="form-group"
              label="Tujuan Pinjaman"
              dialogTitle="Pilih Tujuan Pinjaman"
              hint="Pilih Tujuan Pinjaman"
              dataList={loanPurposes}
              {...props}
              value={props.value.value}
            />
          </div>
        </div>
      )
    }
  </ScreenDimension>
);
