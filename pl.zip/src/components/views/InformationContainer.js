import React from "react";
import { Footer } from "../";

export const InformationContainer = ({ children, className }) => (
  <div>
    <div id="mainContent" className={className || ""}>
      {children}
    </div>
    <Footer />
  </div>
);
