import React from "react";
import { InputMaterialContainer } from "./";

export const Input = props => (
  <InputMaterialContainer {...props}>
    {({ onChange, ...inputProps }) => (
      <input
        className={`form-control ${props.className}
        ${props.leftText ? "input-with-unit" : ""}`}
        {...inputProps}
        onChange={e =>
          props.type === "tel"
            ? (!e.target.value || e.target.value.match(/^\d+$/) !== null) &&
              onChange(e)
            : onChange(e)
        }
      />
    )}
  </InputMaterialContainer>
);
