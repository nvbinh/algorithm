import React from "react";
import { compose, withState, withHandlers } from "recompose";

export const InputMaterialContainer = compose(
  withState("isFocus", "_isFocus", false),
  withState("value", "_setValue", ({ value }) => value),
  withHandlers({
    onFocus: ({ _isFocus }) => value => _isFocus(true),
    onBlur: ({ _isFocus, onBlur }) => ({ target: { value } }) => {
      _isFocus(false);
      onBlur && onBlur(value);
    },
    onChange: ({ _setValue, onChange }) => ({ target: { value } }) => {
      _setValue(value);
      onChange(value);
    }
  })
)(
  ({
    label,
    placeholder,
    value,
    type,
    maxLength,
    onFocus,
    onBlur,
    onChange,
    max,
    isFocus,
    error,
    assistiveText,
    leftText,
    children,
    className = "form-group field-style"
  }) => (
    <div className={`${className} ${error && "has-error"}`}>
      {children({ value, type, maxLength, onFocus, onBlur, onChange, max, placeholder })}
      <span className="bar" />
      {!placeholder && label && (
        <label className={`${(leftText && "focus") || (((value && !isFocus) || isFocus) && "focus") || ""}`}>
          {label}
        </label>
      )}
      {error && <div className="help-block with-errors">{`${error}`}</div>}
      {!error && assistiveText && <div className="caption">{assistiveText}</div>}
      {leftText && <span className="unit">{leftText}</span>}
    </div>
  )
);
