import React from "react";

export class ScreenDimension extends React.Component {
  constructor() {
    super();
    this.state = {
      width: window.innerWidth
    };
    this.handleResize = this._handleResize.bind(this);
  }

  componentDidMount() {
    window.addEventListener("resize", this.handleResize);
  }

  componentWillUnmount() {
    window.addEventListener("resize", null);
  }

  _handleResize(WindowSize, event) {
    this.setState({ width: window.innerWidth });
  }

  render() {
    return this.props.children({
      width: this.state.width
    });
  }
}
