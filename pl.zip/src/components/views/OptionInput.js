import React from "react";
import { ic_dropdown } from "../../resources";

export const OptionInput = ({ label, value, hint, input, enable, error, onClick }) => (
  <div className={`${enable && error && "has-error has-danger"}`} onClick={onClick}>
    {label && <label className="gray-small-text">{label}</label>}
    <div style={{"cursor":"pointer", "padding-right":"24px"}} className={`form-control ${!enable && "disabled"}`}>
      <span className="value option-list-text-span">{value || hint}</span>
      <input {...input} type="hidden" />
      <span className="glyphicon">
        <img src={ic_dropdown} alt="dropdown" />
      </span>
    </div>
    {enable && error && <span className="help-block with-errors">{error}</span>}
  </div>
);
