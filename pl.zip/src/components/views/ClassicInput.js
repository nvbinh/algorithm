import React from "react";
import { WIDTH_MOBILE } from "../../common/constants";

export class ClassicInput extends React.Component {
  constructor(props) {
    super(props);
    this.wasterMask = this._getPlaceHolder(window.innerWidth);
    this.state = {
      placeholder: props.value ? "" : this.wasterMask,
      value: props.value
    };
    this.updateDimensions = this.updateDimensions.bind(this);
  }

  _onChange(event) {
    this.setState({
      value: event.target.value,
      placeholder: event.target.value ? "" : this.wasterMask
    });
    this.props.onChange(event);
  }

  _getPlaceHolder(width) {
    return width > WIDTH_MOBILE
      ? this.props.fullPlaceholder
      : this.props.shortPlaceholder || this.props.fullPlaceholder;
  }

  componentWillReceiveProps({ value }) {
    const { value: currentValue } = this.state;
    currentValue !== value &&
      this.setState({
        value,
        placeholder: value ? "" : this.wasterMask
      });
  }

  updateDimensions() {
    this.wasterMask = this._getPlaceHolder(window.innerWidth);
    this.setState(prevState => ({
      placeholder: prevState.value ? "" : this.wasterMask
    }));
  }

  componentWillMount() {
    this.updateDimensions();
  }

  componentDidMount() {
    window.addEventListener("resize", this.updateDimensions);
  }

  componentWillUnmount() {
    window.removeEventListener("resize", this.updateDimensions);
  }

  render() {
    const { value, placeholder } = this.state;
    const { inputRef, fullPlaceholder, shortPlaceholder,id, ...restProps } = this.props;
    return (
      <div style={{ width: "100%", position: "relative" }}>
        <input
          type="text"
          className="form-control"
          placeholder={placeholder}
          readOnly
          style={{
            border: 0,
            backgroundColor: "transparent",
            position: "absolute",
            pointerEvents: "none"
          }}
        />
        <input
          {...restProps}
          ref={input => {
            if (inputRef) {
              inputRef(input);
            }
          }}
          value={value}
          onChange={event => this._onChange(event)}
          type="text"
          className="form-control ellipsis"
          id={id}
        />
      </div>
    );
  }
}
