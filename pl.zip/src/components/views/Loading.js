import React from "react";
import { InformationContainer } from "../views";

import { icSubmit, icLoading, icAttention, icEmail } from "../../resources";

import AppPageURL from "../../common/appPageURL";
import { DecisionCompletedLoanStatus, DecisionStatus, DecisionRejectedReasonCode } from "../../common/constants";

export class Loading extends React.Component {
  handleDecisionTimeout() {
    let { history, revokeCustomerSession } = this.props;
    history.push(AppPageURL.PENDING_PAGE);
    revokeCustomerSession();
  }

  handleDecisionApproved() {
    let { history, revokeCustomerSession } = this.props;
    history.push(AppPageURL.LOAN_APPROVAL_PAGE);
    revokeCustomerSession();
  }

  handleDecisionRejected({ rejectedReason }) {
    const { history, revokeCustomerSession } = this.props;

    if (
      rejectedReason === DecisionRejectedReasonCode.DEDUPCHECK ||
      rejectedReason === DecisionRejectedReasonCode.QUOTALIMIT
    ) {
      history.push(AppPageURL.NOT_ELIGIBLE_DEDUP_PAGE);
    } else if (rejectedReason === DecisionRejectedReasonCode.DUPLICATION) {
      history.push(AppPageURL.DUPLICATION_REJECTED_PAGE);
    } else {
      history.push(AppPageURL.REJECTED_PAGE);
    }

    revokeCustomerSession();
  }

  handleDecisionUnhappyCases() {
    let { history, revokeCustomerSession } = this.props;
    history.push(AppPageURL.ERROR_PAGE);
    revokeCustomerSession();
  }

  componentWillReceiveProps({ decisionStatus: { jobStatus, loanInfo } }) {
    switch (jobStatus) {
      case DecisionStatus.FAILED:
        this.handleDecisionUnhappyCases();
        break;

      case DecisionStatus.TIME_OUT: {
        this.handleDecisionTimeout();
        break;
      }

      case DecisionStatus.COMPLETED: {
        switch (loanInfo.status) {
          case DecisionCompletedLoanStatus.APPROVED:
            this.handleDecisionApproved();
            break;

          case DecisionCompletedLoanStatus.REJECTED: {
            this.handleDecisionRejected({ rejectedReason: loanInfo.rejectedReason });
            break;
          }
        }
        break;
      }
    }
  }

  componentDidMount() {
    this.preloadOopImage(icEmail);
    this.props.logDurationTimeToServer();
  }

  preloadOopImage(res) {
    const img = new Image();
    img.src = res;
  }

  render() {
    return (
      <InformationContainer>
        <div className="loading container-fluid">
          <div className="loading-container row">
            <div className="col-12 flex-1">
              <div className="image-submit-container">
                <img src={icSubmit} alt="symbol" />
              </div>
              <h1>Terima Kasih</h1>
              <p>Aplikasi Anda telah kami terima. Mohon tunggu beberapa saat, kami sedang memproses pengajuan Anda</p>
              <div className="image-loading-container">
                <img src={icLoading} alt="loading" />
              </div>
              <div className="alert-box">
                <img src={icAttention} alt="alert icon" />
                <span>Mohon untuk tidak menutup halaman ini</span>
              </div>
            </div>
          </div>
        </div>
      </InformationContainer>
    );
  }
}
