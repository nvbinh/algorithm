import React from "react";
import ReCAPTCHA from "react-google-recaptcha";

export const ReCaptcha = ({ onChange, error, sitekey }) => (
  <div className={`${(error && "has-error") || ""}`} id="recaptcha-div">
    <ReCAPTCHA {...{ sitekey, onChange }} />
    {error && (
      <span
        className="help-block with-errors text-center"
        style={{ position: "inherit" }}
      >
        {error}
      </span>
    )}
  </div>
);
