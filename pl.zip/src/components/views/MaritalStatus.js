import React from 'react'
import {MarriageStatus} from './../../common/constants'

export class MaritalStatus extends React.Component {
  constructor(props) {
    super(props)
    const {selectedValue} = props
    this.state = {selectedValue}
  }

  onValueSelected(selectedValue) {
    this.setState({selectedValue})
    this.props.onStatus && this.props.onStatus(selectedValue)
  }

  render() {
    const {className} = this.props
    const {SINGLE, MARRIED} = MarriageStatus
    return (
      <div className={className}>
        <label className='margin-tb-10 status d-block'>Status</label>
        <label className='radio-inline'>
          <input
            type='radio'
            name='status'
            checked={this.state.selectedValue === SINGLE}
            onChange={() => this.onValueSelected(SINGLE)}/>
          <span style={{fontFamily: "HelveticaNeue"}}>Lajang</span>
        </label>
        <label className='radio-inline'>
          <input
            type='radio'
            name='status'
            checked={this.state.selectedValue === MARRIED}
            onChange={() => this.onValueSelected(MARRIED)}/>
          <span style={{fontFamily: "HelveticaNeue"}}>Menikah</span>
        </label>
        <div className='help-block with-errors'/>
      </div>
    )
  }
}
