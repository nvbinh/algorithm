import React from "react";
import { List, OptionInput, OptionListContainer } from "./";

export const OptionList = props => (
  <OptionListContainer
    {...props}
    inputComponent={inputProps => <OptionInput {...inputProps} />}
    popupComponent={({ dataList, value, onChange, isShowModal, dialogTitle }) => (
      <div className="modal-content">
        <div className="modal-header">
          <div className="modal-title">{dialogTitle}</div>
          <button type="button" className="close" onClick={() => isShowModal(false)}>
            &times;
          </button>
        </div>
        <div className="modal-body">
          <List {...{ dataList, value, onChange }} />
        </div>
      </div>
    )}
  />
);
