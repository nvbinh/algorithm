import React from "react";
import { ClassicInput } from "./";

export const CompanyNameInput = props => (
  <ClassicInput
    {...props}
    fullPlaceholder="Cari Nama Perusahaan / Ketik Nama Usaha Anda"
    shortPlaceholder="Cari Nama Perusahaan / Usaha Anda"
    id="companyName"
  />
);
