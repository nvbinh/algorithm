import React from "react";
import { ic_tick_mark } from "../../resources";

export const Radio = ({ name, value, isChecked, onClick }) => (
  <div
    onClick={onClick}
    style={{ display: "flex", "justify-content": "space-between", "align-items": "center" }}
  >
    <a style={{ float: "none", padding: "2px 0" }}>{value}</a>
    {isChecked && <img src={ic_tick_mark} alt="tick" style={{"height": "24px"}} />}
  </div>
);
