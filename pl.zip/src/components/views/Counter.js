import React from 'react'
import iconMinus from './../../assets/images/icon-minus.svg'
import iconPlus from './../../assets/images/icon-plus.svg'

const MAX_COUNTER = 10
const MIN_COUNTER = 0
const STEP_COUNTER = 1

export class Counter extends React.Component {
  constructor (props) {
    super(props)
    this.state = {counter: props.initialCounter || 0}
  }

  increase (e) {
    e.preventDefault()
    let prevState = this.state
    const newValue = prevState.counter === MAX_COUNTER
      ? prevState.counter
      : prevState.counter + STEP_COUNTER
    this.setState({
      counter: newValue
    })
    this.props.onValue && this.props.onValue(newValue)
  }

  decrease (e) {
    e.preventDefault()
    let prevState = this.state
    const newValue = prevState.counter === MIN_COUNTER
      ? prevState.counter
      : prevState.counter - STEP_COUNTER
    this.setState({
      counter: newValue
    })
    this.props.onValue && this.props.onValue(newValue)
  }

  render () {
    const {counter} = this.state
    return (
      <div className={this.props.className}>
        <label className='margin-tb-10 status d-block'>Jumlah Anak</label>
        <img type='image' src={iconMinus} onClick={e => this.decrease(e)} alt='minus' style={{cursor: 'pointer'}}/>
        <span>{counter}</span>
        <img type='image' src={iconPlus} onClick={e => this.increase(e)} alt='plus' style={{cursor: 'pointer'}}/>
        <div className='help-block with-errors'/>
      </div>
    )
  }
}
