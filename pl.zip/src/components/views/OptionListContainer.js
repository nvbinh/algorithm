import React from "react";
import { compose, withState, withHandlers, lifecycle } from "recompose";
import ReactModal from "react-modal";

ReactModal.setAppElement("#root");

const customStyles = {
  content: {
    position: "absolute",
    top: "5%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    marginRight: "-50%",
    transform: "translateX(-50%)",
    padding: "0"
  }
};

const optionListEnhance = compose(
  withState("value", "_setValue", ({ value }) => value),
  withState("showModal", "isShowModal", false),
  withHandlers({
    onChange: ({ _setValue, onChange, isShowModal, ...props }) => item => {
      _setValue(item.value);
      isShowModal(false);
      onChange(item);
    }
  }),
  lifecycle({
    componentWillReceiveProps(nextProps) {
      nextProps.newValue !== this.props.newValue && this.props._setValue(nextProps.newValue);
    }
  })
);

export const OptionListContainer = optionListEnhance(
  ({
    label = "",
    value = "",
    hint = "",
    enable = true,
    dialogTitle = "",
    dataList = [],
    className = "",
    onChange,
    error,
    isShowModal,
    showModal,
    inputComponent,
    popupComponent
  }) => (
    <div className={`${className} ${!enable && "not-active"}`}>
      {inputComponent({
        ...{ label, value, hint, enable, error },
        onClick: () => isShowModal(true)
      })}
      <ReactModal
        shouldCloseOnOverlayClick={true}
        onRequestClose={() => isShowModal(false)}
        isOpen={showModal}
        contentLabel="Minimal Modal Example"
        style={customStyles}
        closeTimeoutMS={150}
      >
        {popupComponent({ dataList, value, onChange, isShowModal, dialogTitle })}
      </ReactModal>
    </div>
  )
);
