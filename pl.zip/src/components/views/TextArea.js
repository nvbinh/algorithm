import React from "react";
import Textarea from "react-textarea-autosize";
import { InputMaterialContainer } from "./";

export const TextArea = props => (
  <InputMaterialContainer {...props}>
    {({ maxLength, onChange, ...inputProps }) => (
      <div>
        <Textarea
          className="form-control text-area"
          style={{
            paddingLeft: 0,
            paddingTop: 0,
            paddingBottom: 0,
            overflow: "hidden",
            resize: "none"
          }}
          {...inputProps}
          onChange={e => e.target.value.length <= maxLength && onChange(e)}
        />
        <div className="right-caption">
          <span>{inputProps.value.length}</span>
          {`/${maxLength}`}
        </div>
      </div>
    )}
  </InputMaterialContainer>
);
