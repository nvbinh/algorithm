import React from "react";

export const YesNoGroup = ({ className, value, onCheck, error }) => (
  <div className={`${error && "has-error has-danger"} ${className}`}>
    <label className="radio-inline">
      <input
        type="radio"
        name="monthlyInstallment"
        id="monthlyInstallmentRadioYes"
        value=""
        checked={value === true}
        onClick={() => onCheck(true)}
      />
      <span>Ya</span>
    </label>
    <label className="radio-inline">
      <input
        type="radio"
        name="monthlyInstallment"
        id="monthlyInstallmentRadioNo"
        checked={value === false}
        value=""
        onClick={() => onCheck(false)}
      />
      <span>Tidak</span>
    </label>
    <div className="help-block with-errors">{error || "\xa0"}</div>
  </div>
);
