import React from "react";
import { ic_checked_yellow } from "../../resources";

const pathToImage = require.context("../../assets/images", true);

export const ImageOption = ({ item, checked, onChange }) => (
  <a
    className={(checked === void 0 ? "" : checked ? "active" : "blur")}
    onClick={e => {
      e.preventDefault();
      onChange && onChange(item);
    }}
  >
    <input type="radio" name="loan-destination" style={{ cursor: "pointer" }} checked={checked} value={item.value} />
    <span className="image">
      <img src={pathToImage(`./${item.imgPath}`)} alt={item.value} />
      <img src={ic_checked_yellow} className="icon-checked" alt="icon-checked" />
    </span>
    <span className="d-block">{item.value}</span>
  </a>
);
