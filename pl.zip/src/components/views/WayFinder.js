import React from "react"
import PropTypes from 'prop-types';

export const WayFinder = (props) => {
  
  let icon1 = 'circle-icon';
  let stepLine1 = 'step-line';
  let icon2 = 'circle-icon';
  let stepLine2 = 'step-line';
  let icon3 = 'circle-icon';

  const addActive = (initClass) => initClass += ' active'
  const addDone = (initClass) => initClass += ' done'
  
  switch(props.step){
    case '1':
      icon1 = addActive(icon1);
      break;
    case '2':
      icon1 = addDone(icon1);
      stepLine1 = addActive(stepLine1);
      icon2 = addActive(icon2);
      break;
    case '3':
      icon1 = addDone(icon1);
      stepLine1 = addActive(stepLine1);
      icon2 = addDone(icon2);
      stepLine2 = addActive(stepLine2);
      icon3 = addActive(icon3);
      break;
    default:
      break;
  }

  return (
    
    <div className="steps">
      <div className="step-icons d-flex justify-content-between">
        <div className={icon1} id="step1"/>
        <div className={stepLine1}/>
        <div className={icon2} id="step2"/>
        <div className={stepLine2}/>
        <div className={icon3} id="step3"/>
      </div>
    </div>
  )

}

WayFinder.propTypes = {
  step: PropTypes.string
}

WayFinder.defaultProps = {
  step: '1'
}