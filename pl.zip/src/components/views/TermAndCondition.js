import React from "react";
import { withState, withHandlers, compose, mapProps } from "recompose";
import { ReCaptcha } from "./";
import YesNoGroupButton from "../widget/yesNoGroupButton";

import { ic_syarat } from "../../resources";

const enhance = compose(
  withState("selectionStatus", "_setSelectionStatus", void 0),
  withState("token", "_setReCaptcharToken", void 0),
  withHandlers({
    onTnCSelection: props => value => {
      props.onSubmit &&
        props.onSubmit({
          selectionStatus: value,
          reCaptchaToken: props.token
        });
      props._setSelectionStatus(value);
    },
    onChange: props => value => props._setReCaptcharToken(value)
  }),
  mapProps(({ error, token, onChange, reCaptchar, ...props }) => ({
    ...props,
    reCaptchar: { ...reCaptchar, onChange, token, error }
  }))
);

export const TermAndCondition = ({ onTnCSelection, selectionStatus, reCaptchar: { token, sitekey, onChange } }) => (
  <div className="term-and-condition">
    <div className="container">
      <div className="row term-and-condition__header">
        <div className="col-12 col-md-9 term-and-condition__header-container">
          <div className="term-and-condition__header-container-inner">
            <div className="img-container">
              <img src={ic_syarat} alt="syarat" />
            </div>
            <h1>Syarat &amp; Ketentuan</h1>
          </div>
        </div>
      </div>
      <div className="row term-and-condition__content">
        <div className="col-12 col-md-9 text-container">
          <p>
            <strong>Syarat dan Ketentuan Kredit Tanpa Agunan TymeDigital (KTA TymeDigital)</strong>
          </p>
          <p>
            Halaman ini berisi Syarat dan Ketentuan atas pengajuan KTA TymeDigital melalui situs jejaring ("Syarat dan
            Ketentuan Pengajuan") yang perlu anda pahami sebelum anda mengajukan permohonan KTA TymeDigital, dengan
            melanjutkan proses pengajuan berarti Anda telah setuju dengan Syarat dan Ketentuan sebagai berikut:
          </p>
          <p>
            1. Untuk melanjutkan menggunakan situs jejaring non transaksi ini, Pemohon terlebih dahulu setuju dengan
            hal-hal sebagai berikut:
          </p>
          <p>
            a. Situs jejaring KTA TymeDigital adalah milik PT. Bank Commonwealth ("<strong>BANK</strong>") yang hanya
            memiliki fungsi non transaksi.
          </p>
          <p>
            b. Pemohon telah memahami fungsi dan karakteristik serta risiko dan konsekuensi dari penggunaan situs ini,
            termasuk risiko operasional dan kerugian yang mungkin timbul dari penggunaan situs ini, untuk itu Pemohon
            bertanggung jawab terhadap segala risiko dan akibat-akibat hukum yang mungkin timbul dikemudian hari akibat
            kesalahan atau kelalaian Pemohon.
          </p>
          <p>
            c. Pemohon memahami dan menyetujui bahwa BANK dan/atau pihak terafiliasi dengan BANK (termasuk Commonwealth
            Bank of Australia dan pihak ketiga yang bekerja sama dengan BANK) dapat menggunakan data dan informasi yang
            Pemohon berikan dalam aplikasi ini untuk keperluan internal Bank dan/atau pihak terafiliasi dengan Bank,
            termasuk juga memindahkan data secara internasional.
          </p>
          <p>
            d. Pemohon memahami dan menyetujui untuk tunduk pada peraturan perundang-undangan serta hukum yang berlaku
            di Republik Indonesia, termasuk namun tidak terbatas pada Undang-Undang dan Peraturan-peraturan terkait
            dengan Perbankan, Informasi dan Transaksi Elektronik, kejahatan finansial, dan/atau tindak pidana pencucian
            uang/korupsi, maupun aturan hukum internasional terkait.
          </p>
          <p>
            e. Pemohon memahami dan menyetujui untuk memberikan kuasa kepada BANK (dengan hak substitusi) untuk
            melakukan pemeriksaan sewaktu-waktu serta mencari dan mendapatkan informasi kepada/di/dari lembaga,
            perseroan, maupun pihak manapun atas data/identitas Pemohon serta seluruh dokumen-dokumen yang Pemohon
            berikan telah sesuai dengan ketentuan BANK.
          </p>
          <p>
            f. Pemohon menjamin kepada BANK bahwa data dan informasi yang Pemohon berikan kepada BANK, termasuk data
            telekomunikasi Pemohon adalah benar adanya, Pemohon setuju dan memberikan kewenangan kepada BANK untuk dapat
            melakukan hal-hal yang dianggap perlu oleh BANK terhadap data dan informasi Pemohon, termasuk untuk
            melakukan verifikasi kepada pihak ketiga dan/atau untuk melakukan penawaran produk dan/atau layanan BANK
            lainnya.
          </p>
          <p>
            g. Pemohon telah memahami syarat dan ketentuan dari permohonan aplikasi ini serta tujuan dan konsekuensi
            dari pengolahan data pada internal BANK dan/atau pihak lain di luar BANK.
          </p>
          <p>
            h. Pemohon memahami bahwa BANK wajib mengungkapkan seluruh informasi yang berkaitan dengan pinjaman Pemohon
            ke dalam Sistem Informasi Debitur (SID) atau Sistem Layanan Informasi Keuangan (SLIK) atau sistem informasi
            lainnya sesuai dengan ketentuan yang ditetapkan oleh Bank Indonesia (BI), Otoritas Jasa Keuangan (OJK) dan
            instansi terkait lainnya dari waktu ke waktu.
          </p>
          <p>
            i. Pemohon memahami dan menyetujui bahwa keputusan pemberian atau penolakan pengajuan KTA TymeDigital
            sepenuhnya merupakan kebijakan dan pertimbangan dari BANK sendiri.
          </p>
          <p>
            j. Syarat-syarat dan ketentuan-ketentuan lain yang belum diatur dalam Syarat dan Ketentuan mengenai
            Pengajuan KTA TymeDigital dan/atau transaksi ini, akan mengacu pada Syarat dan Ketentuan BANK yang berlaku.
          </p>
          <p>k. Syarat dan Ketentuan ini tunduk pada Hukum Negara Republik Indonesia.</p>
          <p>
            2. Apabila fasilitas KTA TymeDigital telah disetujui BANK, dana akan dicairkan secara sekaligus dalam jumlah
            yang disetujui BANK ke rekening Pemohon yang dibuka melalui mesin TymeDigital Kiosk. Pencairan dilakukan
            setelah melalui analisa kelayakan yang ditentukan oleh BANK dan seluruh persyaratan pencairan fasilitas KTA
            TymeDigital telah dipenuhi Pemohon, termasuk namun tidak terbatas pada seluruh dokumen yang dipersyaratkan
            diterima dengan lengkap oleh BANK dan pembukaan rekening Pemohon wajib dilakukan melalui TymeDigital Kiosk.
          </p>
          <p>
            3. Pemohon memahami dan menyetujui apabila fasilitas KTA TymeDigital telah disetujui BANK dan Pemohon telah
            menjadi Nasabah BANK, maka BANK sewaktu-waktu dapat mengubah syarat dan ketentuan KTA TymeDigital dengan
            pemberitahuan kepada Nasabah paling lambat 30 (tigapuluh) hari kerja sebelumnya.
          </p>
          <p className="margin-top-40">
            PT. Bank Commonwealth adalah Bank yang terdaftar dan diawasi oleh Otoritas Jasa Keuangan (OJK).
          </p>
        </div>
        <div className="col-12 col-md-9 capcha-container">
          <ReCaptcha
            {...{ onChange, sitekey }}
            error={(selectionStatus && !token && "Anda harus melakukan verifikasi captcha") || void 0}
          />
        </div>
        <div className="col-12 col-md-9">
          <div className="row row-button">
            <YesNoGroupButton
              id="tnc-group-button"
              className="row align-center"
              onYesClick={() => onTnCSelection(true)}
              onNoClick={() => onTnCSelection(false)}
            />
          </div>
        </div>
      </div>
    </div>
  </div>
);

export const TermAndConditionEnhance = enhance(TermAndCondition);
