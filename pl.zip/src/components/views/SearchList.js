import React from "react";
import { MaxLength } from "../../common/constants";
import { OptionListContainer, OptionInput } from "./";
import { AutosuggestionInputCity } from "../../containers/";

export const SearchList = props => (
  <OptionListContainer
    {...props}
    inputComponent={inputProps => <OptionInput {...inputProps} />}
    popupComponent={({ dataList, value, onChange, isShowModal, dialogTitle }) => (
      <div className="modal-content">
        <div className="modal-body">
          <div className="smart-city-container">
            <AutosuggestionInputCity
              isShowModal={isShowModal}
              className=""
              maxLength={MaxLength.INPUT_COMPANY_NAME}
              suggestions={dataList}
              emptySearchResultMessage="Mohon maaf, kota Anda belum ada di daftar kami"
              alwaysRenderSuggestions={true}
              onCitySelected={item => onChange(item)}
              value={value ? value : ""}
            />
          </div>
        </div>
      </div>
    )}
  />
);
