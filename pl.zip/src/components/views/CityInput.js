import React from "react";
import { ClassicInput } from "./";
import { icon_search } from "../../resources";

export const CityInput = ({ isShowModal, ...restProps }) => (
  <div className="smart-city-input__container">
    <div className="smart-city-input__prepend">
      <span>
        <img src={icon_search} alt="ic-search" />
      </span>
    </div>
    <ClassicInput fullPlaceholder="Cari kota" {...restProps} />
    <div
      className="smart-city-input__append"
      onClick={() => isShowModal(false)}
    >
      <span>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="14"
          height="14"
          viewBox="0 0 14 14"
        >
          <g fill="none" fill-rule="evenodd">
            <path d="M-1-1h16v16H-1z" />
            <g
              className="smart-city-input__close"
              stroke="#3EB5E5"
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
            >
              <path d="M12.6 1.4L1.4 12.6M1.4 1.4l11.2 11.2" />
            </g>
          </g>
        </svg>
      </span>
    </div>
  </div>
);
