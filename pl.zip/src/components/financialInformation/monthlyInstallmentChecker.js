import React from 'react'

export default function MonthlyInstallmentChecker ({className, selectedValue, onCheck, error}) {
  return (
    <div className={`form-group ${error && 'has-error has-danger'} ${className}`}>
      <label htmlFor='monthlyInstallmentRadio' className='title'>Apakah saat ini Anda memiliki angsuran
        per <br/>bulan? <br/>
        <span className='gray-small-text'>(contoh: KPR, KTA, Pinjaman Koperasi dll)</span>
      </label><br/>
      <div className='div-45-percent'>
      <label className='radio-inline'>
        <input
          type='radio'
          name='monthlyInstallment'
          id='monthlyInstallmentRadioYes'
          value=''
          checked={selectedValue === true}
          onClick={() => onCheck(true)}/>
        <span>Ya</span>
      </label>
      </div>
      <div className='div-45-percent'>
      <label className='radio-inline'>
        <input
          type='radio'
          name='monthlyInstallment'
          id='monthlyInstallmentRadioNo'
          checked={selectedValue === false}
          value=''
          onClick={() => onCheck(false)}/>
        <span>Tidak</span>
      </label>
      </div>
      <div className='help-block with-errors'>{error || '\xa0'}</div>
    </div>
  )
}
