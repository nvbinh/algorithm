import React from "react";
import PinInput from "react-pin-input";
import { connect } from "react-redux";
import { formatSecurityPhone } from "../../utils/formatUtils";
import { withRouter } from "react-router";
import { validateOtp, getOtp, getDecisionStatus } from "../../actions/actionCreator";
import AppPageURL from "../../common/appPageURL";
import { Otp, OtpAction, OtpStatus, ErrorStatus, PLStatus } from "../../common/constants";
import ButtonResendOtp from "./buttonCountDownResendOtp";
import LoadingModal from "./../widget/loadingModal";
import Modal from "react-modal";
import AnalyticUtils from '../../utils/AnalyticUtils';
import { ScreenName, FacebookTrackingEvent } from "../../common/constants";

export class OtpValidation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isValidOtp: false,
      isSubmitted: false,
      otpCode: "",
      errorInfo: "",
      otpStatus: void 0
    };
    this.pin = void 0;
  }

  componentWillMount() {
    Modal.setAppElement("body");
  }

  componentWillReceiveProps(nextProps) {
    const {
      action,
      validate: { attempted: submittedAttempt, status },
      getOtp,
      getOtp: { attempted: resendAttempt }
    } = nextProps.otpStatus;

    const {
      gTagID: gTagId,
      fbPixelID: fbPixelId,
      gTagConversionLabel
    } = nextProps.tracking;

    const isException =
      status === OtpStatus.EXCEPTION ||
      status === OtpStatus.BLOCK ||
      status === OtpStatus.NOT_EXIST ||
      status === ErrorStatus.NETWORK;

    if (status === PLStatus.SUCCESS) {
      this.props.getDecisionStatus();
      fbPixelId
        && AnalyticUtils.activeFacebookTrackingEvent(FacebookTrackingEvent.SUBMIT_APPLICATION);
      gTagId
        && gTagConversionLabel
        && AnalyticUtils.activeGtagTrackingEvent(gTagConversionLabel,ScreenName.OTP);
      this.goToLoadingPage();
    }

    if ((action === OtpAction.GET && getOtp.status === PLStatus.FAILED) || isException) {
      this.gotoOtpExceptionPage();
    }

    if ((resendAttempt === Otp.MAX_RESEND && status === OtpStatus.EXPIRED) || status === OtpStatus.MAX_ATTEMPT) {
      this.gotoMaxAttemptErrorPage();
    }

    if (
      resendAttempt !== this.props.otpStatus.getOtp.attempted ||
      submittedAttempt !== this.props.otpStatus.validate.attempted
    ) {
      this.pin.clear();
      this.setState({
        otpCode: "",
        errorInfo: void 0
      });
    }
    if (submittedAttempt !== this.props.otpStatus.validate.attempted) {
      const invalidMessage = `Kode yang Anda masukkan salah (${submittedAttempt} dari ${Otp.MAX_ATTEMPT} percobaan)`;
      const expiredMessage = `Kode telah kadaluarsa. Mohon tekan kirim ulang untuk mendapatkan kode baru`;

      const errorInfo =
        action === OtpAction.VALIDATION &&
        ((status === OtpStatus.INVALID && invalidMessage) || (status === OtpStatus.EXPIRED && expiredMessage));

      this.setState({
        errorInfo,
        isSubmitted: false,
        otpStatus: status
      });
    }
  }

  goToLoadingPage() {
    this.props.history.push(AppPageURL.LOADING_PAGE);
  }

  gotoMaxAttemptErrorPage() {
    this.props.history.push(AppPageURL.OTP_ERROR_PAGE);
  }

  gotoOtpExceptionPage = () => this.props.history.push(AppPageURL.OTP_EXCEPTION_PAGE);

  onChangedOtp(otpCode) {
    this.setState({
      otpCode,
      isValidOtp: this.isValidOtpCode(otpCode)
    });
  }

  onSubmittedOtp() {
    const { otpCode } = this.state;
    const isValidOtp = this.isValidOtpCode(otpCode);
    this.setState({
      isSubmitted: true,
      isValidOtp
    });
    isValidOtp && this.props.validateOtp(otpCode);
  }

  onResendOtp() {
    this.setState({ isSubmitted: false,otpStatus: void 0 });
    this.props.resendOtp();
  }

  isValidOtpCode(otpCode) {
    return !!otpCode && otpCode.length === Otp.PIN_LENGTH;
  }

  componentDidMount() {
    this.pin.elements.forEach(item => {
      item.input.onfocus = () => this.setState({ errorInfo: void 0 });
    });
    window.scrollTo(0, 0);
  }

  getSelectorStatus(isDisable) {
    return isDisable ? "disabled" : "actived";
  }

  showDisabledPin(){
      const renderComponents = [];
      for (let i=0;i<Otp.PIN_LENGTH;i++){
          renderComponents.push(<input type="tel" key={i} className="pincode-input-text" disabled/>);
      }

      return (
          <div className="pincode-input-container">
              {renderComponents}
          </div>
      )
  }

  render() {
    const {
      phoneNumber,
      otpStatus: {
        action,
        validate: { status },
        getOtp: { attempted: resendAttempt }
      }
    } = this.props;

    const { isValidOtp, isSubmitted, errorInfo, otpStatus } = this.state;

    const notifyInfo =
      !isSubmitted &&
      action === OtpAction.GET &&
      resendAttempt !== 0 &&
      `Kami telah mengirim kode verifikasi (${resendAttempt} dari ${Otp.MAX_ATTEMPT} permintaan)`;
    const otpInputValidation = !isValidOtp && isSubmitted && "Masukkan kode verifikasi Anda";

    const isExpired = otpStatus === OtpStatus.EXPIRED;

    return (
      <div className="otp container-fluid">
        <div className="otp-message__container row">
          <div className="col-12 otp-message__top">
            <p>
              Mohon masukkan kode untuk verifikasi yang kami kirimkan ke&nbsp;
              <span>{formatSecurityPhone(phoneNumber)}</span>
            </p>
          </div>
          <div className="col-12 otp-message__input-container">
            <div id="otp" className={((errorInfo || otpInputValidation) && "has-error") || ""}>
              {isExpired
                ? this.showDisabledPin()
                : <PinInput
                      type="numeric"
                      length={Otp.PIN_LENGTH}
                      onChange={(value, index) => this.onChangedOtp(value)}
                      secret={false}
                      ref={p => (this.pin = p)}
                  />
              }
            </div>
          </div>
          <div className="col-12 otp-message__bottom ">
            {otpInputValidation && <p className="otp-message__bottom-error">{otpInputValidation}</p>}
            {!otpInputValidation && notifyInfo && <p className="otp-message__bottom-info">{notifyInfo}</p>}
            {!otpInputValidation && errorInfo && <p className="otp-message__bottom-error">{errorInfo}</p>}
          </div>
        </div>
        <div className="row-button row" >
          <ButtonResendOtp
            limitResend={Otp.MAX_RESEND}
            initCountDown={Otp.DURATION_COUNTDOWN}
            autoStart
            onClickResend={() => this.onResendOtp()}
            isDisable={resendAttempt >= Otp.MAX_ATTEMPT}
          />
          <button
            type="button"
            className={`btn btn-blue ${this.getSelectorStatus(isExpired)}`}
            onClick={() => this.onSubmittedOtp()}
            disabled={isExpired}
          >
            LANJUT
          </button>
        </div>
        <LoadingModal isOpen={status === "processing"} />
      </div>
    );
  }
}

const mapStateToProp = ({
  otpStatus,
  form: {
    customerPersonalInformation: {
      values: { phoneNumber }
    }
  },
  getConfigurationsAPIResponse: { configurations,tracking }
}) => ({
  otpStatus,
  phoneNumber,
  tracking
});

const mapDispatchToProp = dispatch => ({
  validateOtp: otpCode => dispatch(validateOtp({ otpCode })),
  resendOtp: () => dispatch(getOtp()),
  getDecisionStatus: () => dispatch(getDecisionStatus())
});

export default withRouter(
  connect(
    mapStateToProp,
    mapDispatchToProp
  )(OtpValidation)
);
