import React from 'react'

export default class ButtonResendOtp extends React.Component {
  constructor (props) {
    super(props)
    this.initCountDown = props.initCountDown || 0
    this.state = {timeCountDown: this.initCountDown}
  }

  processCountDown (currentTime) {
    let newTime = currentTime - 1
    if (newTime === 0) {
      clearInterval(this.interval)
    }
    this.setState({timeCountDown: newTime})
  }

  startCountdown () {
    this.setState({timeCountDown: this.initCountDown})
    this.interval = setInterval(() => this.processCountDown(this.state.timeCountDown), 1000)
  }

  componentDidMount () {
    this.props.autoStart && this.startCountdown()
  }

  componentWillUnmount () {
    clearInterval(this.interval)
  }

  onResendEvent () {
    this.startCountdown()
    this.props.onClickResend && this.props.onClickResend()
  }

  render () {
    const {timeCountDown} = this.state
    const {isDisable} = this.props
    const isActive = timeCountDown > 0 || isDisable
    return (
      <div
        style={{pointerEvents: isActive ? 'none' : 'auto'}}>
        <a className={`btn btn-noborder ${isActive ? 'blur' : ''}`}
          onClick={() => this.onResendEvent()}>
          KIRIM ULANG {(timeCountDown > 0 && !isDisable) ? `(${timeCountDown})` : ''}
        </a>
      </div>
    )
  }
}
