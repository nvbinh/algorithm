import React from "react";
export const EmergencyContact = ({ name, relationship, phone }) => (
  <div className="emergency-contact col-12 col-md-9">
    <div className="emergency-contact__container-inner">
      <h4>Kontak Darurat</h4>
      <div className="row">
        <div className="data__item col-12">
          <label>Nama Lengkap</label>
          <label>{name}</label>
        </div>
        <div className="data__item col-12 col-md-6">
          <label>Hubungan</label>
          <label>{relationship}</label>
        </div>
        <div className="data__item col-12 col-md-6">
          <label>Nomor Ponsel</label>
          <label>{phone}</label>
        </div>
      </div>
    </div>
  </div>
);
