import React from "react";

export const PersonalData = ({
    name,
    dob,
    nik,
    phone,
    email,
    status,
    children,
    address,
    city,
    district,
    kelurahan,
    sameAddress
})=>(
    <div className="personal-data col-12 col-md-9"><h4>Data Pribadi Anda</h4>
        <div className="row">
            <div className="data__item col-12 order-0"><label>Nama Lengkap</label><label>{name}</label></div>
            <div className="data__item col-12 col-md-6 order-1"><label>Tanggal Lahir</label><label>{dob}</label></div>
            <div className="data__item col-12 col-md-6 order-2 order-md-3"><label>Nomor
                KTP</label><label>{nik}</label></div>
            <div className="data__item col-12 col-md-6 order-3 order-md-2"><label>Nomor
                Ponsel</label><label>{phone}</label></div>
            <div className="data__item col-12 col-md-6 order-4"><label>Alamat
                Email</label><label>{email}</label></div>
            <div className="data__item col-6 order-4"><label>Status</label><label>{status}</label></div>
            <div className="data__item col-6 order-4"><label>Jumlah Anak</label><label>{children}</label></div>
            {sameAddress ? (
                        <div className="data__item col-12 order-4"><label>Alamat</label><label>Sama dengan alamat pada KTP</label></div>
                    ) : (
                        [
                            <div className="data__item col-12 order-4" key="Alamat"><label>Alamat</label><label>{address}</label></div>,
                            <div className="data__item col-12 col-md-6 order-4" key="Kota"><label>Kota</label><label>{city}</label></div>,
                            <div className="data__item col-12 col-md-6 order-4" key="Kecamatan"><label>Kecamatan</label><label>{district}</label></div>,
                            <div className="data__item col-12 order-4" key="Kelurahan"><label>Kelurahan</label><label>{kelurahan}</label></div>
                        ]
                    )}
        </div>
    </div>
);
