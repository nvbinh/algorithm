import React from "react";

export const SubmissionDetail = ({
    loanAmount,
    tenor,
    monthlyInstallment,
    interestRate
}) => (
    <div className="submission-detail col-12 col-md-9"><h4>Rincian Pengajuan</h4>
        <div className="submission-detail__list">
            <div className="submission-detail__item">
                <div className="submission-detail__item-container"><label>Jumlah
                    Pinjaman</label><label>Rp{loanAmount}</label>
                </div>
            </div>
            <div className="submission-detail__item">
                <div className="submission-detail__item-container"><label>Tenor</label>
                    <label>{tenor} Bulan</label>
                </div>
            </div>
            <div className="submission-detail__item">
                <div className="submission-detail__item-container"><label>Angsuran Per
                    Bulan</label><label>Rp{monthlyInstallment}</label>
                </div>
            </div>
            <div className="submission-detail__item">
                <div className="submission-detail__item-container"><label>Suku Bunga</label>
                    <label>{interestRate}% flat/bulan</label>
                </div>
            </div>
        </div>
    </div>

);
