import React from "react";

export const FinanceInfo = ({
    purpose,
    earningPerMonth,
    totalInstallmentPerMonth
})=>(
    <div className="about-finance col-12 col-md-9">
        <div className="about-finance__container-inner">
            <div className="row">
                <div className="data__item col-12"><label>Tujuan Pinjaman</label><label>{purpose}</label></div>
            </div>
            <div className="row">
                <div className="col-12"><h4>Tentang Keuangan Anda</h4></div>
                <div className="data__item col-12 col-md-6"><label>Penghasilan Per
                    Bulan</label><label>Rp{earningPerMonth}</label></div>
                { totalInstallmentPerMonth && <div className="data__item col-12 col-md-6"><label>Total Angsuran Per
                    Bulan</label><label>Rp{totalInstallmentPerMonth}</label></div> }
            </div>
        </div>
    </div>
);
