import React from "react";

export const WorkInfo = ({
    companyName,
    work,
    department,
    industry,
    business
})=>(
    <div className="about-work col-12 col-md-9"><h4>Tentang Pekerjaan / Usaha Anda</h4>
        <div className="row">
            <div className="data__item col-12"><label>Nama Perusahaan / Usaha Anda</label><label>{companyName}</label></div>
            <div className="data__item col-12"><label>Pekerjaan</label><label>{work}</label></div>
            {
                department &&
                <div className="data__item col-12 col-md-6">
                    <label>Jabatan</label><label>{department}</label>
                </div>
            }
            {
                industry &&
                business &&
                <div className="data__item col-12 col-md-6">
                    <label>Jenis Bidang/Industri</label><label>{industry}-{business}</label>
                </div>
            }
        </div>
    </div>
);
