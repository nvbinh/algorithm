import React from "react";
import Modal from "react-modal";
import iconLoading from "../../assets/images/loading_nobg.gif";

const customStyles = {
  content: {
    width: "75%",
    top: "50%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    border: "none",
    transform: "translate(-50%, -50%)",
    color: "#231F20",
    fontSize: "20px",
    textAlign: "center",
    background: "transparent"
  }
};

export default props => (
  <Modal {...props} style={customStyles} portalClassName="progress">
    <div className="align-center">
      <img src={iconLoading} alt="loading" />
      <div>
        <span className="loading-text">Mohon tunggu sebentar</span>
      </div>
    </div>
  </Modal>
);
