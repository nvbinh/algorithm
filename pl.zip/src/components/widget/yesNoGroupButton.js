import React from 'react'
import ActionButtonGroup from './actionButtonGroup'

export default function YesNoGroupButton (props) {
  return <ActionButtonGroup {...props} positiveLabel='SETUJU' negativeLabel='TIDAK SETUJU' onPositiveButtonClick={props.onYesClick} onNegativeButtonClick={props.onNoClick}/>
}
