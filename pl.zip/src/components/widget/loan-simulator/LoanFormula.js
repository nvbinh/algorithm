export const monthlyInstallment = interestRate => amount => tenure => (
  (amount + (interestRate * tenure * amount))/tenure
);
