import React from "react";
import { AmountSlider, TenureOption, InterestInstallment } from "./";
import { monthlyInstallment } from "./LoanFormula";
import {
  compose,
  withState,
  withHandlers,
  lifecycle,
  withProps
} from "recompose";

export const enhanceLoanSimulation = compose(
  withState("amount", "_setAmount", ({ amount }) => amount),
  withState("tenure", "_setTenure", ({ tenure }) => tenure),
  withHandlers({
    onAmountChange: ({ _setAmount }) => amount => _setAmount(amount),
    onTenureChange: ({ _setTenure }) => tenure => _setTenure(tenure)
  }),
  withProps(({ interestRate, amount, tenure }) => ({
    interestInstallment: Math.round(
      monthlyInstallment(interestRate)(amount)(tenure)
    )
  })),
  lifecycle({
    componentWillUnmount() {
      const {
        amount,
        tenure,
        interestInstallment: monthlyInstallmentAmount,
        onLoanInformationChange
      } = this.props;

      onLoanInformationChange({
        amount,
        tenure,
        monthlyInstallmentAmount
      });
    },
    componentWillReceiveProps({ maxTenure }) {
      maxTenure !== this.props.maxTenure && this.props._setTenure(maxTenure);
    }
  })
);

export const LoanSimulation = enhanceLoanSimulation(
  ({
    maxAmount,
    amount,
    minAmount,
    stepAmount,
    onAmountChange,
    minTenure,
    maxTenure,
    tenure,
    onTenureChange,
    interestRate,
    interestInstallment
  }) => (
    <div className="calculator">
      <div className="slider-container">
        <AmountSlider
          name="amount"
          className="slide-value"
          min={minAmount}
          max={maxAmount}
          step={stepAmount}
          onChange={onAmountChange}
          amount={amount}
        />
      </div>

      <TenureOption
        name="tenure"
        min={minTenure}
        max={maxTenure}
        tenure={tenure}
        onChange={onTenureChange}
      />

      <InterestInstallment value={interestInstallment} />
    </div>
  )
);
