import React from 'react'
import { formatCurrency } from '../../../utils/formatUtils'
import Slider from 'rc-slider'
import { compose, withState, withHandlers } from 'recompose'

const amountChange = compose(
  withState('amount', '_amountChange', ({min, amount}) => amount || min),
  withHandlers({
    onChange: ({ _amountChange, onChange }) => (value) => {
      _amountChange(value)
      onChange(value)
    },
  })
);

export const AmountSlider = amountChange(
  ({amount, min, max, step, onChange}) => (
    <div className='slide-value has-error'>
      <label>Jumlah Pinjaman</label>
      <span className='false'>
        {`Rp${formatCurrency(amount)}`}
      </span>
      <div className={'slider'}>
        <Slider
          min={min}
          max={max}
          step={step}
          defaultValue={amount}
          onChange={onChange}
        />
      </div>
      <div className={`min-value`}>{formatCurrency(min)}</div>
      <div className={`max-value`}>{formatCurrency(max)}</div>
    </div>
  )
);
