import React from 'react'
import { formatCurrency } from '../../../utils/formatUtils'

export const InterestInstallment = ({value}) => (
  <div className={'summary d-flex justify-content-between'}>
    <p >Angsuran per Bulan</p>
    <p className='font-weight-bold'>
      {`Rp${formatCurrency(value)}`}
    </p>
  </div>
)
