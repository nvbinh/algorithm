import React from "react";
import PropTypes from "prop-types";
import { compose, withState, withHandlers, lifecycle } from "recompose";

const tenureChange = compose(
  withState("tenure", "_setTenure", ({ max }) => max),
  withHandlers({
    onChange: ({ _setTenure, onChange }) => tenure => {
      _setTenure(tenure);
      onChange(tenure);
    }
  }),
  lifecycle({
    componentWillReceiveProps({ max }) {
      max !== this.props.max && this.props._setTenure(max);
    }
  })
);

export const TenureOption = tenureChange(({ min, max, tenure, onChange }) => (
  <div className={"tenor d-flex flex-column"}>
    <label className={"tenure-label"}>Tenor (bulan)</label>
    <div className="tenor__button-container">
      <a
        className={`circle-btn ${min === tenure && "active"}`}
        onClick={() => onChange(min)}
      >
        {min}
      </a>
      <a
        className={`circle-btn ${max === tenure && "active"}`}
        onClick={() => onChange(max)}
      >
        {max}
      </a>
    </div>
  </div>
));

TenureOption.prototypes = {
  minTenure: PropTypes.number.isRequired,
  maxTenure: PropTypes.number.isRequired,
  onChange: PropTypes.func
};
