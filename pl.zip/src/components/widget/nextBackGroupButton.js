import React from 'react'
import ActionButtonGroup from './actionButtonGroup'

export default function NextBackGroupButton ({onNextClick, onBackClick, ...restProps}) {
  return (
    <ActionButtonGroup
      positiveLabel='LANJUT'
      negativeLabel='KEMBALI'
      onPositiveButtonClick={onNextClick}
      onNegativeButtonClick={onBackClick}
      {...restProps}
    />
  )
}
