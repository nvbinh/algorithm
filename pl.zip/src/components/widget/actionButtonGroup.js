import React from 'react'

export default function ActionButtonGroup ({id, className, onPositiveButtonClick, onNegativeButtonClick, positiveLabel, negativeLabel}) {
    return (
        <div className={`row-button row ${className}`} id={id}>
      <span
          className='btn btn-blue'
          onClick={onPositiveButtonClick}>{positiveLabel}</span>
            <span
                className='btn btn-noborder'
                onClick={onNegativeButtonClick}>{negativeLabel}</span>
        </div>
    )
}
