import React from "react";
import { connect } from "react-redux";
import { Redirect, Route, Switch } from "react-router-dom";
import { withRouter } from "react-router";
import GoogleAnalytics from "react-ga";

import Header from "./app.header.component";
import ActionType from "../../actions/actionType";
import AppPageURL from "../../common/appPageURL";
import ActionFactory from "../../actions/actionFactory";
import StringUtils from "../../utils/stringUtils";
import withTracker from "./withTracker";
import withGtagTracker from "./withGtagTracker";
import withPageTimeLogger from "./withPageTimeLogger";
import { PageNameTracking } from "../../common/constants";
import OtpValidation from "../otp/otpValidation";
import { mapTrackedPageToScreenName } from "../../common/constants";
import {
  PersonalInformation,
  WorkingInformation,
  FinancialInformation,
  Review,
  Landing,
  TermAndCondition,
  Approval,
  OtpError,
  OtpException
} from "../../pages";
import { Pending, Rejected, RejectedDuplication, Loading } from "../../containers";
import { Error, NotEligibleDedup } from "../../components";

class App extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    const { getLOV, getLOVMapping, getLoanConfig } = this.props;
    getLOV();
    getLOVMapping();
    getLoanConfig();
  }

  componentWillReceiveProps(nextprops) {
    const { gaTrackingId } = nextprops.tracking;
    const { gaTrackingId: gaTrackingIdCurrent } = this.props.tracking;

    if (gaTrackingId !== gaTrackingIdCurrent && !StringUtils.isEmpty(gaTrackingId)) {
      GoogleAnalytics.initialize(gaTrackingId, {
        debug: process.env.NODE_ENV !== "production"
      });
      const page = this.props.location.pathname;
      const screen = mapTrackedPageToScreenName(page);
      GoogleAnalytics.set({ page: page, title: screen });
      GoogleAnalytics.pageview(page);
    }

  }

  shouldComponentUpdate({ location: { pathname } }) {
    return this.props.location.pathname !== pathname;
  }

  render() {

    const {tracking} = this.props;

    return (
      <div id="wrapper" className="App">
        <Header />
        <div id="mainContent">
          <div className="customerInformation">
            <Switch>
              <Route exact path={AppPageURL.HOME} component={withPageTimeLogger(Landing, PageNameTracking.LANDING)} />
              <Route
                exact
                path={AppPageURL.CUSTOMER_INFORMATION_PERSONAL_INFO}
                component={withTracker(withPageTimeLogger(PersonalInformation, PageNameTracking.PERSONAL))}
              />
              <Route
                exact
                path={AppPageURL.CUSTOMER_INFORMATION_FINANCIAL_INFO}
                component={withTracker(withPageTimeLogger(FinancialInformation, PageNameTracking.FINANCIAL))}
              />
              <Route
                exact
                path={AppPageURL.CUSTOMER_INFORMATION_WORKING_INFO}
                component={withTracker(withPageTimeLogger(WorkingInformation, PageNameTracking.WORKING))}
              />
              <Route
                exact
                path={AppPageURL.CUSTOMER_INFORMATION_REVIEW}
                component={withTracker(withPageTimeLogger(Review, PageNameTracking.REVIEW))}
              />
              <Route
                exact
                path={AppPageURL.TnC_PAGE}
                component={withTracker(withPageTimeLogger(TermAndCondition, PageNameTracking.TNC))}
              />
              <Route path={AppPageURL.LOADING_PAGE} component={withTracker(Loading)} />
              <Route path={AppPageURL.REJECTED_PAGE} component={withTracker(withGtagTracker(Rejected,tracking))} />
              <Route path={AppPageURL.NOT_ELIGIBLE_DEDUP_PAGE} component={withTracker(withGtagTracker(NotEligibleDedup,tracking))} />
              <Route path={AppPageURL.LOAN_APPROVAL_PAGE} component={withTracker(withGtagTracker(Approval,tracking))} />
              <Route path={AppPageURL.PENDING_PAGE} component={withTracker(withGtagTracker(Pending,tracking))} />
              <Route path={AppPageURL.ERROR_PAGE} component={withTracker(Error)} />
              <Route path={AppPageURL.OTP_PAGE} component={withTracker(withPageTimeLogger(OtpValidation, PageNameTracking.OTP))} />
              <Route path={AppPageURL.OTP_ERROR_PAGE} component={withTracker(OtpError)} />
              <Route path={AppPageURL.OTP_EXCEPTION_PAGE} component={withTracker(OtpException)} />
              <Route path={AppPageURL.DUPLICATION_REJECTED_PAGE} component={withTracker(withGtagTracker(RejectedDuplication,tracking))} />
              <Redirect to={AppPageURL.PAGE_NOT_FOUND} />
            </Switch>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({
  getConfigurationsAPIResponse: { configurations,tracking }
}) => ({
  tracking: {
    gaTrackingId: configurations.gaTrackingId,
    ...tracking
  }
});

const mapDispatchToProps = dispatch => ({
  getLOV: () => dispatch(ActionFactory.ofType(ActionType.GET_LOV)),
  getLOVMapping: () => dispatch(ActionFactory.ofType(ActionType.GET_LOV_MAPPING)),
  getLoanConfig: () => dispatch(ActionFactory.ofType(ActionType.GET_LOAN_CONFIG))
});

export default withRouter(
  connect(
    mapStateToProps,
    mapDispatchToProps
  )(App)
);
