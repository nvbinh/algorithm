import React from 'react'
import logo from '../../assets/images/logo.svg'

const Header = () => (
  <div id="header">
    <div className="container-fluid">
      <a href="/" className="Logo"><img src={logo} alt="Logo"/></a>
    </div>
  </div>
)

export default Header
