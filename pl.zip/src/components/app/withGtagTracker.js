import React, { Component } from 'react';
import {mapTrackedPageToScreenName} from '../../common/constants';
import AnalyticUtils from '../../utils/AnalyticUtils';

const withGtagTracker = (WrappedComponent, options = {}) => {

    const trackPage = (pathname, gTagConversionLabel) => {
        let pageName = mapTrackedPageToScreenName(pathname);
        AnalyticUtils.activeGtagTrackingEvent(gTagConversionLabel,pageName)
    }

    const HOC = class extends Component {
        componentDidMount () {
            const {pathname} = this.props.location;
            const {gTagConversionLabel} = options;
            trackPage(pathname,gTagConversionLabel);
        }

        componentWillReceiveProps (nextProps) {
            const {pathname: currentPage} = this.props.location
            const {pathname: nextPage} = nextProps.location
            const {gTagConversionLabel} = options;
            if (currentPage !== nextPage) {
                trackPage(nextPage, gTagConversionLabel)
            }
        }

        render () {
            return <WrappedComponent {...this.props} />
        }
    }

    return HOC
}

export default withGtagTracker