import React from 'react'
import { connect } from 'react-redux'
import { Route, Switch, withRouter, Redirect } from 'react-router-dom'
import ReactModal from 'react-modal'

import ActionFactory from '../../actions/actionFactory'
import ActionType from '../../actions/actionType'

import App from './app.component'
import AppPageURL from '../../common/appPageURL'
import withError from './error/withError'
import asyncComponent from '../common/async.component'
import InternalServerError from './error/internalServerError.component'
import PageNotFound from './error/pageNotFound.component'

import {getTrackingId, saveDataInSessionStorage} from '../../actions/actionCreator'
import StringUtils from '../../utils/stringUtils'
import AnalyticUtils from '../../utils/AnalyticUtils'
import { PL_KEY } from '../../common/constants'

const AsyncUnauthorized = asyncComponent(() => import('./error/unauthorized.component'))
const AsyncForbidden = asyncComponent(() => import('./error/forbidden.component'))
const AsyncAutomationSupportingHome = asyncComponent(() => import('../auto/automation-supporting-home'))

ReactModal.setAppElement('#root');

class Root extends React.Component {
  constructor(props){
    super(props)
    this.paths = [];
    this.initedGtag = false;
  }
  componentDidMount () {
    this.redirect()

    this.props.saveQueryParams({
      key: PL_KEY.UTM_CAMPAIN_SESSION_STORAGE,
      data: StringUtils.getQueryParamsAllowingUndefinedUtmSource(this.props.location.search)
    })
  }

  componentDidUpdate () {
    this.redirect()
  }

  redirect () {
    const {urlToRedirect, clearUrlToRedirect, history} = this.props
    if (urlToRedirect) {
      history.push(urlToRedirect)
      clearUrlToRedirect()
    }
  }

  componentWillReceiveProps(nextprops) {
    const {
      tracking: {
        gTagId,
        fbPixelId,
        utmParameterTracking
      }, location } = nextprops;
    const {
      tracking: {
        gTagId: currentGTagId,
        fbPixelId: fbPixelIdCurrent,
        utmParameterTracking: utmParameterTrackingCurrent
      }
    } = this.props;

    const utmParamTrackingValue =  AnalyticUtils.getTracking(utmParameterTracking);
    utmParameterTracking !== utmParameterTrackingCurrent && utmParamTrackingValue && this.props.getTrackingId(utmParamTrackingValue);

    fbPixelId && fbPixelId !== fbPixelIdCurrent && AnalyticUtils.activeFacebookTracking(fbPixelId);

    if(gTagId && gTagId !== currentGTagId && !this.initedGtag) {
      this.initedGtag = true;
      AnalyticUtils.initGtag(gTagId);
    }
    if (this.initedGtag && gTagId && !this.paths.includes(location.pathname)){
      AnalyticUtils.runGtag('config', gTagId, {'page_path': location.pathname});
      this.paths.push(location.pathname)
    }
  }

  render () {
    const {history: {action, location}} = this.props

    return (
      <div>
        <Switch>
          <Route exact path={AppPageURL.INTERNAL_SERVER_ERROR} render={() => withError(<InternalServerError/>)}/>
          <Route exact path={AppPageURL.UNAUTHORIZED} render={() => withError(<AsyncUnauthorized/>)}/>
          <Route exact path={AppPageURL.FORBIDDEN} render={() => withError(<AsyncForbidden/>)}/>
          <Route exact path={AppPageURL.PAGE_NOT_FOUND} render={() => withError(<PageNotFound/>)}/>
          <Route exact path={AppPageURL.AUTOMATION_SUPPORTING} component={AsyncAutomationSupportingHome}/>
          <Route path={AppPageURL.HOME}
                 render={() => !(action !== 'PUSH' && location.pathname !== AppPageURL.HOME)
                   ? <App/>
                   : <Redirect to={{pathname: AppPageURL.HOME}}/>
                 }/>
        </Switch>
      </div>
    )
  }
}

const mapStateToProps = ({
  getConfigurationsAPIResponse: { configurations, tracking }, app
}) => ({
  tracking: {
    gTagId: tracking.gTagID,
    fbPixelId: tracking.fbPixelID,
    gTagConversionLabel: tracking.gTagConversionLabel,
    utmParameterTracking: configurations.utmParameterTracking
  },
  ...app
});

const mapDispatchToProps = (dispatch) => ({
  clearUrlToRedirect: () => dispatch(ActionFactory.ofType(ActionType.PAGE_REDIRECTED)),
  saveQueryParams: (data) => dispatch(saveDataInSessionStorage(data)),
  getTrackingId: (utmParamValue) => dispatch(getTrackingId(utmParamValue))
})

export default Root = withRouter(connect(
  mapStateToProps,
  mapDispatchToProps)(Root))
