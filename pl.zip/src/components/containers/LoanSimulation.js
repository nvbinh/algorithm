import { updateLoanInformation } from "../../actions/actionCreator";
import { connect } from "react-redux";
import { LoanSimulation } from "../widget/loan-simulator";

const mapStateToProps = ({
  getConfigurationsAPIResponse: { configurations }
}) => ({
  ...configurations,
  amount: configurations.minAmount,
  tenure: configurations.maxTenure
});

const mapDispatchToProps = dispatch => ({
  onLoanInformationChange: data => dispatch(updateLoanInformation(data))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LoanSimulation);
