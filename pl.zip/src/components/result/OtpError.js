import React from "react";
import { InformationContainer } from "../views";

import { icOops } from "../../resources";

import { Otp } from "../../common/constants";

export const OtpError = ({ history }) => (
  <InformationContainer>
      <div className="otp-error container-fluid">
          <div className="row">
              <div className="otp-error__container col-12">
                  <div className="img-container">
                      <img src={icOops} alt="symbol" />
                  </div>
              </div>
              <div className="message-container">
                  <h1>Oops!</h1>
                  <p>{`Anda telah memasukkan kode yang salah sebanyak ${
                      Otp.MAX_ATTEMPT
                      } kali. Mohon ulangi proses dari awal kembali.`}</p>
              </div>
          </div>
          <div className="row-button row">
              <button
                  type="button"
                  className="btn btn-blue"
                  onClick={() => history.push("/")}
              >
                  KEMBALI KE HALAMAN AWAL
              </button>
          </div>
      </div>
  </InformationContainer>
);
