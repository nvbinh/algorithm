import React from "react";
import { InformationContainer } from "../views";

import { icSorry } from "../../resources";

export const Rejected = ({ name }) => (
  <InformationContainer className="reject container-fluid">
    <div className="row">
        <div className="reject__container col-12">
            <div className="img-container">
                <img src={icSorry} alt="symbol"/>
            </div>
            <div>
                <h1>Maaf {name}</h1>
                <p>Saat ini pengajuan pinjaman Anda belum dapat kami setujui</p>
            </div>
        </div>

    </div>
  </InformationContainer>
);
