import React from "react";
import { InformationContainer } from "../views";

import { icOops } from "../../resources";

export const Error = () => (
  <InformationContainer className="otp-error container-fluid">
    <div className="row">
      <div className="otp-error__container col-12">
          <div className="img-container">
              <img src={icOops} alt="symbol"/>
          </div>
          <div>
              <h1>Oops!</h1>
              <p>
                  Maaf telah terjadi kendala teknis. Mohon untuk mencoba kembali besok
              </p>
          </div>
      </div>
    </div>
  </InformationContainer>
);
