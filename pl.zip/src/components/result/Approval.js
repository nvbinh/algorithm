import React from "react";
import { InformationContainer } from "../views";

import { imgArtHappyguy, icCalendar, icAtmCard, icMap } from "../../resources";

export const Approval = ({
  totalLoan,
  tenor,
  monthlyInstallment,
  interestRate,
  expireDate,
  requireSalaryValidation,
  kioskLocationUrl
}) => (
  <InformationContainer>
    <div className="thankyou">
      <div className="container">
        <div className="row happyguy">
          <div className="happyguy__img-container">
            <img src={imgArtHappyguy} alt="symbol" />
          </div>
        </div>
        <div className="row congratulation">
          <div className="col-12 col-md-6 offset-md-1 congratulation__info">
            <h1>Selamat! Pengajuan KTA Anda tinggal selangkah lagi</h1>
            <h3>Segera kunjungi TymeDigital Kiosk terdekat sebelum tanggal:</h3>
            <div className="date-box">
              <img src={icCalendar} alt="calendar" />
              {expireDate}
            </div>
            <p>Serta membawa dokumen-dokumen sebagai berikut:</p>
            <div className="row mb-2">
              <div className="col-5 col-md-4 col-lg-3 congratulation__info-image-container">
                <img src={icAtmCard} alt="atm card" />
              </div>
              <div className="col-7 col-md-7 col-lg-9 congratulation__info-steps__container">
                <div className="congratulation__info-steps">
                  <div className="steps__item">e-KTP</div>
                  {requireSalaryValidation && <div className="steps__item">Slip gaji bulan terakhir</div>}
                </div>
              </div>
            </div>
            <div className="row row-button margin-top-15">
              <a href={kioskLocationUrl} target="_blank" rel="noopener noreferrer">
                <button className="btn btn-blue" type="button">
                  <img src={icMap} alt="map" />Lihat lokasi TymeDigital Kiosk
                </button>
              </a>
            </div>
          </div>
          <div className="col-12 col-md-5 congratulation__info-table">
            <div className="congratulation__info-table__container card shadow">
              <div className="congratulation__info-table-title">
                <p>Rincian Pengajuan</p>
              </div>
              <div className="congratulation__info-table-body">
                <div className="congratulation__info-table__item">
                  <p>Jumlah Pinjaman</p>
                  <p>Rp{totalLoan}</p>
                </div>
                <div className="congratulation__info-table__item">
                  <p>Tenor</p>
                  <p>{tenor} Bulan</p>
                </div>
                <div className="congratulation__info-table__item">
                  <p>Angsuran Per Bulan</p>
                  <p>Rp{monthlyInstallment}</p>
                </div>
                <div className="congratulation__info-table__item">
                  <p>Suku Bunga</p>
                  <p>
                    {`${interestRate}% `}
                    <span className="italic">flat</span>/bulan
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row disclamer">
          <div className="col-12 col-md-11 offset-md-1">
            <p>DISCLAIMER</p>
            <p>
              Persetujuan pinjaman sebagaimana disebutkan di atas wajib melalui tahap verifikasi terlebih dahulu oleh
              Staff TymeDigital Kiosk
            </p>
          </div>
        </div>
      </div>
    </div>
  </InformationContainer>
);
