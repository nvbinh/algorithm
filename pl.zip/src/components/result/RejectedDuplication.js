import React from "react";
import { InformationContainer } from "../views";
import { icSorry, icAttention } from "../../resources";

const style = {
    color: '#231f20'
};

export const RejectedDuplication = ({ name }) => (
  <InformationContainer className="reject container-fluid">
    <div className="row">
        <div className="reject__container col-12">
            <div className="img-container">
                <img src={icSorry} alt="symbol" />
            </div>
            <div className="message-container">
                <h1 style={style}>Hi {name}, Anda sudah pernah melakukan pengajuan pinjaman sebelumnya</h1>
                <p style={style}>
                    Saat ini kami tidak dapat memproses pengajuan Anda.
                </p>
            </div>
        </div>
    </div>
  </InformationContainer>
);
