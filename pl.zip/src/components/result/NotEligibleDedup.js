import React from "react";
import { InformationContainer } from "../views";

import { icCallCenter } from "../../resources";

export const NotEligibleDedup = () => (
  <InformationContainer>
    <div className="not-eligibile-dedup container-fluid">
        <div className="row">
            <div className="not-eligibile-dedup__container col-12">
                <div className="img-container">
                    <img src={icCallCenter} alt="symbol" className="submit-image" />
                </div>
                <div>
                    <h1>Terima Kasih</h1>
                    <p>
                        Aplikasi Anda telah kami terima. Pihak kami akan menghubungi Anda untuk
                        proses lebih lanjut.
                    </p>
                </div>
            </div>
        </div>
    </div>
  </InformationContainer>
);
