import React from "react";
import { InformationContainer } from "../views";

import { icEmail, icAttention } from "../../resources";

export const Pending = ({ email }) => (
  <InformationContainer className="pending container-fluid">
    <div className="row">
      <div className="pending__container col-12">
          <div className="img-container">
              <img src={icEmail} alt="symbol"/>
          </div>

        <h1>Terima Kasih</h1>
        <p>
          Kami akan mengirimkan status pengajuan Anda ke alamat email{" "}
          <span>{email}</span>
        </p>
        <div className="alert-box">
          <img src={icAttention} alt="alert icon" />
          <span>
            Jika Anda tidak menerima email dalam 24 jam, silahkan mengajukan
            permohonan pinjaman kembali.
          </span>
        </div>
      </div>
    </div>
  </InformationContainer>
);
