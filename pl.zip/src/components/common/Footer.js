import React from "react";
import {
  ic_facebook,
  ic_twitter,
  ic_instagram,
  ic_call_centre,
  ic_3p,
  ic_lps,
  ic_ayo,
  ic_ik,
  img_logo
} from "../../resources";

const contextMenuCusor = { cursor: "default" };

export const Footer = () => (
  <div id="footer">
    <div className="footer-logos">
      <div className="footer-logos__container">
        <ul className="social">
          <li>
            <h6 className="follow-us">follow us</h6>
          </li>
          <li>
            <a href="https://www.facebook.com/CommbankID" target="_blank" rel="noopener noreferrer">
              <img src={ic_facebook} alt="facebook" />
              <span>CommBankID</span>
            </a>
          </li>
          <li>
            <a href="https://twitter.com/CommBank_ID" target="_blank" rel="noopener noreferrer">
              <img src={ic_twitter} alt="twitter" />
              <span>CommBank_ID</span>
            </a>
          </li>
          <li>
            <a href="https://www.instagram.com/commbank_id" target="_blank" rel="noopener noreferrer">
              <img src={ic_instagram} alt="instagram" />
              <span>commbank_id</span>
            </a>
          </li>
        </ul>
        <ul className="logo">
          <li className="call">
            <a href="https://www.commbank.co.id/upublic/mod_home/default_content.aspx?code=contact" target="_blank" rel="noopener noreferrer">
              <img className="img-fluid" src={ic_call_centre} alt="call center" />
            </a>
          </li>
          <li>
            <a onClick={e => e.preventDefault()} style={contextMenuCusor}>
              <img className="img-fluid" src={ic_3p} alt="3p" />
            </a>
          </li>
          <li>
            <a onClick={e => e.preventDefault()} style={contextMenuCusor}>
              <img className="img-fluid" src={ic_lps} alt="lps" />
            </a>
          </li>
          <li>
            <a onClick={e => e.preventDefault()} style={contextMenuCusor}>
              <img className="img-fluid" src={ic_ayo} alt="ayo" />
            </a>
          </li>
          <li>
            <a onClick={e => e.preventDefault()} style={contextMenuCusor}>
              <img className="img-fluid" src={ic_ik} alt="ik" />
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div className="footer-information">
      <a>
        <img className="margin-bottom-10" src={img_logo} alt="Logo" width="200" />
      </a>
      <p>
        PT. Bank Commonwealth adalah Bank yang terdaftar dan diawasi oleh Otoritas Jasa Keuangan.<br /> © 2017 PT. Bank
        Commonwealth
      </p>
      <p>
      <a style={{color: '#231f20'}} href="https://www.commbank.co.id/upublic/mod_home/default_content.aspx?code=disclaimer" target="_blank" rel="noopener noreferrer">
        Disclaimer
      </a>
        &nbsp;-&nbsp;
      <a style={{color: '#231f20'}} href="https://www.commbank.co.id/upublic/mod_home/default_content.aspx?code=privacy" target="_blank" rel="noopener noreferrer">
          Privacy Statement
      </a>
      </p>

    </div>
  </div>
);
