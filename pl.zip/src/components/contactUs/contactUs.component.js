import React from 'react'

const ContactUs = () => (
  <div className="App-header">
    <h2>I am the ContactUs.</h2>
  </div>
)

export default ContactUs