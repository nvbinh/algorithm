import React from "react";
import icon_mengajukan from "./../../assets/images/icon-mengajukan.svg";
import icon_ajukan from "./../../assets/images/icon-ajukan.svg";
import icon_bullet from "./../../assets/images/icon-bullet.svg";
import icon_instant from "./../../assets/images/icon-instant.svg";
import icon_card from "./../../assets/images/icon-card.svg";
import icon_pencairan from "./../../assets/images/icon-pencairan.svg";
import { NAVIGATOR_ITEM } from "../";

export const HowToApply = ({ isMobile, isActive, onTabChange }) => (
    <div className={`tab-pane ${isActive && "active"}`} id="TabHowToApply">
      <div className="container">
        <div
          className={`tab-pane__mobile ${isMobile &&
            ((isActive && "active") || " ")}`}
          onClick={e => {
            e.preventDefault();
            onTabChange(NAVIGATOR_ITEM[0].key);
          }}
        >
          <a href="/#">
            <img src={icon_mengajukan} alt="" width="52" /> Cara Mengajukan
          </a>
        </div>
          <div className="tab-pane__content row">
            <h2 className="align-center">
              Pengajuan KTA hanya dengan 4 langkah mudah
            </h2>

            <div className="step-container">
              <div className="step col-12 col-lg-3">
                <img src={icon_ajukan} alt="" />
                <br />
                <img src={icon_bullet} alt="" className="break-point" />
                <span className="break-line" />
                <h3>Pengajuan Pinjaman</h3>
                <p>
                  Pilih jumlah dan tenor pinjaman, kemudian lengkapi data Anda. Semua
                  hanya dalam waktu 3 menit
                </p>
              </div>
              <div className="step col-12 col-lg-3">
                <img src={icon_instant} alt="" />
                <br />
                <img src={icon_bullet} alt="" className="break-point" />
                <span className="break-line" />
                <h3>Persetujuan <span className="font-italic">Real-time</span></h3>
                <p>Dapatkan persetujuan pinjaman Anda secara <span className="font-italic">real-time online</span></p>
              </div>
              <div className="step col-12 col-lg-3">
                <img src={icon_card} alt="" />
                <br />
                <img src={icon_bullet} alt="" className="break-point" />
                <span className="break-line" />
                <h3>Kelengkapan Pengajuan Pinjaman</h3>
                <p>
                  Kunjungi TymeDigital Kiosk terdekat untuk verifikasi dan pembukaan
                  rekening tabungan
                </p>
              </div>
              <div className="step col-12 col-lg-3">
                <img src={icon_pencairan} alt="" />
                <br />
                <img src={icon_bullet} alt="" className="break-point" />
                <h3>Pencairan</h3>
                <p>Dana akan dicairkan ke rekening tabungan di hari yang sama</p>
              </div>
            </div>
          </div>
      </div>
    </div>

);
