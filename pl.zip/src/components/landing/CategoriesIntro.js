import React from "react";
import { compose, withState, withHandlers } from "recompose";
import {
  NavigationMenu,
  HowToApply,
  FeaturesAndBenefits,
  InterestAndFees,
  TermsOfSubmission,
  NAVIGATOR_ITEM
} from "../";

const CategoriesIntroWithTabNameState = compose(
  withState("previousTab", "_setPreviousTab", ""),
  withState(
    "selectedTab",
    "_setSelectedTab",
    ({ isMobile }) => (isMobile ? "-" : NAVIGATOR_ITEM[0].key)
  ),
  withHandlers({
    onTabChange: ({ previousTab, selectedTab, ...props }) => tabName => {
      props._setPreviousTab(
        (previousTab === selectedTab && "-") || selectedTab
      );
      props._setSelectedTab(tabName);
    }
  })
);

export const CategoriesIntro = CategoriesIntroWithTabNameState(
  ({
    configurations: {
      minAmount,
      maxAmount,
      minTenure,
      maxTenure,
      interestRate,
      penaltyFee,
      minAge,
      minIncome,
      kioskLocationUrl
    },
    onTabChange,
    previousTab,
    selectedTab,
    isMobile
  }) => {
    const isDifferenceTab = isMobile ? previousTab !== selectedTab : true;
    const [howToApply, features, interest, termsOfSubmission] = NAVIGATOR_ITEM;
    return (
      <div>
        <div className="tab-header">
          <div className="col-12 col-md-10 m-md-auto d-block d-lg-none">
            <h1>Informasi Lebih Lanjut</h1>
          </div>
        </div>
        <div className="tab-region">
          <div className="col-12 col-md-10 m-md-auto col-lg-12 p-lg-0">
            <NavigationMenu onTabChange={onTabChange} tabName={selectedTab} />
            <div className="tab-region__content">
              <HowToApply
                {...{ isMobile, onTabChange }}
                isActive={selectedTab === howToApply.key && isDifferenceTab}
              />
              <FeaturesAndBenefits
                isActive={selectedTab === features.key && isDifferenceTab}
                {...{
                  minAmount,
                  maxAmount,
                  minTenure,
                  maxTenure,
                  isMobile,
                  onTabChange
                }}
              />
              <InterestAndFees
                isActive={selectedTab === interest.key && isDifferenceTab}
                {...{ interestRate, penaltyFee, isMobile, onTabChange }}
              />
              <TermsOfSubmission
                isActive={
                  selectedTab === termsOfSubmission.key && isDifferenceTab
                }
                {...{
                  minAge,
                  minIncome,
                  isMobile,
                  onTabChange,
                  kioskLocationUrl
                }}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }
);
