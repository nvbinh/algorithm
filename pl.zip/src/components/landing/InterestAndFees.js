import React from "react";
import icon_biaya from "./../../assets/images/icon-biaya.svg";
import { NAVIGATOR_ITEM } from "../";

export const InterestAndFees = ({ interestRate = "", penaltyFee, isMobile, isActive, onTabChange }) => (
  <div className={`tab-pane ${isActive && "active"}`} id="TabInterest">
    <div className="container">
      <div
        className={`tab-pane__mobile ${isMobile && ((isActive && "active") || " ")}`}
        onClick={e => {
          e.preventDefault();
          onTabChange(NAVIGATOR_ITEM[2].key);
        }}
      >
        <a href="/#">
          <img src={icon_biaya} alt="" width="52" /> Biaya dan Bunga
        </a>
      </div>
      <div className="row tab-pane__content">
        <div className="col-12 col-lg-2 d-none d-md-block">
          <img src={icon_biaya} alt="" className="top-icon" />
        </div>
        <div className="col-12 col-lg-5">
          <h2 className="d-none d-md-block">Biaya dan Bunga</h2>
          <p>
            Dapatkan KTA TymeDigital dengan <strong>bebas biaya provisi dan biaya administrasi.</strong>
          </p>
        </div>
        <div className="col-12 col-lg-5 mb-5">
          <div className="table-style">
            <div className="header">Biaya &amp; Bunga</div>
            <ul>
              <li>
                  <p>Suku Bunga</p>
                <strong>
                  {`${interestRate.toString().replace(/\./g, ",")}% `}
                  <div style={{ fontStyle: "italic", display: "inline" }}>flat</div>/bulan
                </strong>
              </li>
              <li>
                <p>Biaya Provisi dan Administrasi</p>
                <strong>Gratis</strong>
              </li>
              <li>
                <p>Biaya Pelunasan Dipercepat</p>
                <strong>5% dari pokok pinjaman</strong>
              </li>
              <li>
                <p>Biaya Keterlambatan</p>
                <strong>{`${penaltyFee.toString().replace(/\./g, ",")}% `}dari angsuran/bulan</strong>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
);
