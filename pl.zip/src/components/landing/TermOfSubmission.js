import React from "react";
import icon_syarat from "./../../assets/images/icon-syarat.svg";
import icon_checked_yellow from "./../../assets/images/icon-checked-yellow.svg";
import { NAVIGATOR_ITEM } from "../";

export const TermsOfSubmission = ({
  minAge,
  minIncome,
  isMobile,
  isActive,
  onTabChange,
  kioskLocationUrl
}) => (
  <div className={`tab-pane ${isActive && "active"}`} id="TabTermsOfSubmission">
    <div className="container">
      <div
        className={`tab-pane__mobile ${isMobile &&
          ((isActive && "active") || " ")}`}
        onClick={e => {
          e.preventDefault();
          onTabChange(NAVIGATOR_ITEM[3].key);
        }}
      >
        <a href="/#">
          <img src={icon_syarat} alt="" width="52" />Syarat dan Ketentuan
        </a>
      </div>
      <div className="tab-pane__content row">
        <div className="col-12 col-lg-2 d-none d-md-block">
          <img src={icon_syarat} alt="" className="top-icon" />
        </div>
        <div className="col-12 col-lg-5">
          <h2 className="d-none d-lg-block">Syarat dan Ketentuan</h2>
          <p>
            Nikmati proses sederhana tanpa harus khawatir dengan riwayat kredit
          </p>
        </div>
        <div className="col-12">
          <div className="row">
            <div className="col-12 offset-lg-2 col-lg-4 mb-5">
              <div className="table-style">
                <div className="header">Syarat & Ketentuan</div>
                <ul>
                  <li>
                      <p>Usia Anda Saat Ini</p>
                      <strong>Min. berusia {minAge} tahun</strong>
                  </li>
                  <li>
                      <p>Domisili</p>
                      <strong>Di kota-kota yang terdaftar</strong>
                      <br />
                      <a
                        style={{
                          textDecoration: "underline",
                          color: "#3eb5e5",
                          fontWeight: "bold"
                        }}
                        href={kioskLocationUrl}
                        target="_blank" rel="noopener noreferrer"
                      >
                        Lihat disini
                      </a>
                  </li>
                  <li>
                      <p>Pekerjaan</p>
                      <strong>Karyawan atau Wirausaha</strong>
                  </li>
                  <li>
                      <p>Penghasilan Bersih per Bulan</p>
                      <strong>Minimum Rp{minIncome}</strong>
                  </li>
                  <li>
                      <p>Kewarganegaraan</p>
                      <strong>WNI yang memiliki e-KTP</strong>
                  </li>
                  <li>
                      <p>Penambahan Nilai Pinjaman<i>(Top-up)</i></p>
                      <strong>Tidak terdapat fasilitas penambahan nilai pinjaman</strong>
                  </li>
                  <li>
                      <p>Pelunasan Dipercepat</p>
                      <strong>5% dari pokok pinjaman</strong>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-12 col-lg-4 mb-5 pl-lg-4">
              <div className="table-style">
                <div className="header">Dokumen yang Dibutuhkan</div>
                <ul className="no-line">
                  <li>
                    <div>
                      <img
                        src={icon_checked_yellow}
                        alt=""
                      />
                      <strong>Fotokopi e-KTP</strong>
                    </div>
                  </li>
                  <li>
                    <div>
                      <img
                        src={icon_checked_yellow}
                        alt=""
                      />
                      <strong>Fotokopi NPWP </strong>{" "}
                    </div>
                    <span style={{color: "#78838c"}}>(Jika Anda memiliki)</span>
                  </li>
                  <li>
                    <div>
                      <img
                        src={icon_checked_yellow}
                        alt=""
                      />
                      <strong>Fotokopi Slip Gaji </strong>
                    </div>
                    <span style={{color: "#78838c"}}>(Jika Anda karyawan dan tidak memiliki riwayat pinjaman)</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);
