import React from "react";
import {
  Footer,
  LandingHeader,
  LandingMobileIntro,
  LandingLoanIntro,
  CategoriesIntro
} from "../";

import { ScreenDimension } from "../views";
import { WIDTH_MOBILE } from "../../common/constants";

export const Landing = ({ history, configurations }) => (
  <div id="mainContent">
    <div className="explore-product-info">
      <div className="container">
        <LandingHeader history={history} />
        <LandingMobileIntro />
        <LandingLoanIntro minAge={configurations.minAge} />
      </div>
      <ScreenDimension>
        {({ width }) => (
          <CategoriesIntro
            configurations={configurations}
            isMobile={width < WIDTH_MOBILE}
          />
        )}
      </ScreenDimension>
    </div>
    <Footer />
  </div>
);
