import React from "react";
import { img_art_human } from "../../resources";
import LoanSimulation from "../containers/LoanSimulation";
import AppPageURL from "../../common/appPageURL";

export const LandingHeader = ({ resetApp, history }) => (
  <div className="row human">
    <div className="human__image">
      <img src={img_art_human} alt="art human" />
    </div>
    <div className="human__promo-text">
      <h6>#1 di Indonesia</h6>
      <h1>Pinjaman dengan Keputusan Instan</h1>
      <p>Dapatkan pinjaman tanpa Kartu Kredit</p>
    </div>
    <div className="human__promo-card">
      <div className="human__promo-card__container">
        <div className="human__promo-card__title">
          <h1>Pengajuan Pinjaman</h1>
        </div>
        <div className="human__promo-card__body">
          <LoanSimulation />
        </div>
        <div className="human__promo-card__button-submit">
          <button
            className="btn btn-blue"
            onClick={() => {
              history.push(AppPageURL.CUSTOMER_INFORMATION_PERSONAL_INFO);
            }}
          >
            AJUKAN SEKARANG
          </button>
        </div>
      </div>
    </div>
  </div>
);
