import React from "react";

export const NAVIGATOR_ITEM = [
  { key: "TabHowToApply", value: "Cara Mengajukan" },
  { key: "TabFeatures", value: "Fitur Produk" },
  { key: "TabInterest", value: "Bunga dan Biaya" },
  { key: "TabTermsOfSubmission", value: "Syarat dan Ketentuan" }
];

export const TabItem = ({ tab: key, value, onClick }) => (
  <a
    href={`#${key}`}
    onClick={e => {
      e.preventDefault();
      onClick(key);
    }}
  >
    {value}
  </a>
);

export const NavigationMenu = ({ onTabChange, tabName }) => (
  <div className="tab-region__menu d-none d-lg-block">
      <ul>
        {NAVIGATOR_ITEM.map(({ key, value }) => (
          <li key={key} className={`${tabName === key && "active"}`}>
            <TabItem
              {...{ tab: key, value }}
              onClick={() => onTabChange(key)}
            />
          </li>
        ))}
      </ul>
  </div>
);
