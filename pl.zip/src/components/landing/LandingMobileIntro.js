import React from "react";
import { img_art_hand, ic_instan, ic_easy, ic_free } from "../../resources";
export const LandingMobileIntro = () => (
  <div className="row mobile">
    <div className="col-md-10 m-md-auto">
      <div className="row">
        <div className="col-md-12 mobile__text">
          <h1>
            Keunggulan <span>KTA TymeDigital</span>
          </h1>
        </div>
        <div className="col-md-12 mobile__benefit-container">
          <div className="mobile__benefit-item">
            <div className="mobile__benefit-icon">
              <img src={ic_instan} alt="instan" />
            </div>
            <div className="mobile__benefit-text">
              <h3>Keputusan Instan</h3>
              <p>Tidak ada biaya yang tersembunyi</p>
            </div>
          </div>
          <div className="mobile__benefit-item">
            <div className="mobile__benefit-icon">
              <img src={ic_easy} alt="easy" />
            </div>
            <div className="mobile__benefit-text">
              <h3>Proses Mudah</h3>
              <p>Hanya 3 menit untuk mengajukan pinjaman</p>
            </div>
          </div>
          <div className="mobile__benefit-item">
            <div className="mobile__benefit-icon">
              <img src={ic_free} alt="free" />
            </div>
            <div className="mobile__benefit-text">
              <h3>Bebas Biaya</h3>
              <p>Pinjaman ringan tanpa biaya provisi &amp; biaya administrasi</p>
            </div>
          </div>
        </div>
        <div className="mobile__img-container">
          <img className="d-none d-md-block" src={img_art_hand} alt="art hand" />
        </div>
      </div>
    </div>
  </div>
);
