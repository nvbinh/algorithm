import React from "react";
import { img_art_people, img_art_ektp, img_art_income } from "../../resources";

export const LandingLoanIntro = ({ minAge }) => (
  <div className="row avartar">
    <div className="col-12 col-md-10 m-md-auto avartar__container">
      <div className="avartar__text">
        <h1>Mau dapatkan pinjaman?</h1>
        <h4>Anda cukup memenuhi 3 persyaratan berikut</h4>
      </div>
      <div className="avartar__icon-container">
        <div className="avartar__icon-item">
          <div className="avartar__icon">
            <img src={img_art_people} alt="art people" />
          </div>
          <h3>Min. berusia {minAge} tahun</h3>
        </div>
        <div className="avartar__icon-item">
          <div className="avartar__icon">
            <img src={img_art_ektp} alt="art ektp" />
          </div>
          <h3>
            {" "}
            Memiliki<br />e-KTP
          </h3>
        </div>
        <div className="avartar__icon-item">
          <div className="avartar__icon">
            <img src={img_art_income} alt="art income" />
          </div>
          <h3>
            Karyawan atau Wirausaha{" "}
          </h3>
        </div>
      </div>
    </div>
  </div>
);
