import React from "react";
import icon_fitur from "./../../assets/images/icon-fitur.svg";
import { NAVIGATOR_ITEM } from "../";

export const FeaturesAndBenefits = ({
  minAmount,
  maxAmount,
  minTenure,
  maxTenure,
  isMobile,
  isActive,
  onTabChange
}) => (
  <div className={`tab-pane ${isActive && "active"}`} id="TabFeatures">
    <div className="container">
      <div
        className={`tab-pane__mobile ${isMobile &&
          ((isActive && "active") || " ")}`}
        onClick={e => {
          e.preventDefault();
          onTabChange(NAVIGATOR_ITEM[1].key);
        }}
      >
        <a href="/#">
          <img src={icon_fitur} alt="" /> Fitur Produk
        </a>
      </div>
      <div className="tab-pane__content row">
        <div className="col-12 col-lg-2 d-none d-lg-block">
          <img src={icon_fitur} alt="" className="top-icon" />
        </div>
        <div className="col-12 col-lg-5">
          <h2 className="d-none d-lg-block">Fitur Produk</h2>
          <p>
            KTA TymeDigital adalah produk pinjaman tanpa agunan dari{" "}
            <strong>PT Bank Commonwealth</strong> untuk kebutuhan nasabah
            perorangan
          </p>
        </div>
        <div className="col-12 col-lg-5 mb-5">
          <div className="table-style">
            <div className="header">Fitur Produk</div>
            <ul>
              <li>
                  <p>Jumlah Pinjaman</p>
                <strong>
                  Rp{minAmount} - {maxAmount} juta
                </strong>
              </li>
              <li>
                  <p>Sistem Pembayaran</p>
                <strong>
                  Auto debit dari rekening tabungan Commonwealth Bank Anda
                </strong>
              </li>
              <li>
                  <p>Tenor</p>
                <strong>
                  {minTenure} atau {maxTenure} bulan
                </strong>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
);
