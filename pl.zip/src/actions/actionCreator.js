import ActionType from "../actions/actionType";
import ActionFactory from "../actions/actionFactory";

export const getConfigurations = () =>
  ActionFactory.ofType(ActionType.GET_LOAN_CONFIG);

export const getConfigurationsSuccess = apiResponse =>
  ActionFactory.create(ActionType.GET_LOAN_CONFIG_SUCCESS, apiResponse);

export const getCompanyName = value =>
  ActionFactory.create(ActionType.GET_COMPANY_NAME, value);

export const getCompanyNameDone = companyNameList =>
  ActionFactory.create(ActionType.GET_COMPANY_NAME_DONE, companyNameList);

export const clearCompanyName = () =>
  ActionFactory.create(ActionType.CLEAR_COMPANY_NAME);

export const resetApp = () => ActionFactory.create(ActionType.RESET_APP);

export const createCustomer = reCaptchaToken =>
  ActionFactory.create(ActionType.CUSTOMER_SUBMIT_LOAN, reCaptchaToken);

export const createCustomerSuccess = response =>
  ActionFactory.create(ActionType.CUSTOMER_SUBMIT_LOAN_SUCCESS, response);

export const createCustomerFail = error =>
  ActionFactory.create(ActionType.CUSTOMER_SUBMIT_LOAN_FAILED, error);

export const getOtp = (payload, meta) =>
  ActionFactory.create(ActionType.GET_OTP, payload, meta);

export const getOtpSuccess = (data, meta) =>
  ActionFactory.create(ActionType.GET_OTP_SUCCESS, data, meta);

export const getOtpFail = (data, meta) =>
  ActionFactory.create(ActionType.GET_OTP_FAIL, data, meta);

export const validateOtp = payload =>
  ActionFactory.create(ActionType.VALIDATE_OTP, payload);

export const validateOtpSuccess = data =>
  ActionFactory.create(ActionType.VALIDATE_OTP_SUCCESS, data);

export const validateOtpFail = data =>
  ActionFactory.create(ActionType.VALIDATE_OTP_FAIL, data);

export const getDecisionStatus = () =>
  ActionFactory.ofType(ActionType.GET_DECISION_STATUS);

export const getDecisionStatusSuccess = apiResponse =>
  ActionFactory.create(ActionType.GET_DECISION_STATUS_SUCCESS, apiResponse);

export const getDecisionStatusFailed = apiResponse =>
  ActionFactory.create(ActionType.GET_DECISION_STATUS_FAILED, apiResponse);

export const logTime = ({ pageName, duration }) =>
  ActionFactory.create(ActionType.LOG_TIME, { pageName, duration });

export const logDurationTimeToServer = () =>
  ActionFactory.create(ActionType.LOG_TIME_TO_SERVER);

export const saveDataInSessionStorage = data =>
  ActionFactory.create(ActionType.SAVE_DATA_IN_SESSION_STORAGE, data);

export const logCampaignAnalytic = () =>
  ActionFactory.create(ActionType.LOG_CAMPAIGN_ANALYTICS);

export const revokeCustomerSession = () =>
  ActionFactory.create(ActionType.REVOKE_CUSTOMER_SESSION);

export const getWorkingInfo = meta =>
  ActionFactory.create(ActionType.GET_WORKING_DATA_INFO, void 0, meta);

export const getWorkingInfoSuccess = (data, meta) =>
  ActionFactory.create(ActionType.GET_WORKING_DATA_INFO_SUCCESS, data, meta);

export const updateLoanInformation = loanInformation =>
  ActionFactory.create(ActionType.UPDATE_LOAN_INFORMATION, loanInformation);

export const getTrackingId = utmParamValue =>
  ActionFactory.create(ActionType.GET_TRACKING_ID, utmParamValue);

export const getTrackingIdSuccess = data =>
  ActionFactory.create(ActionType.GET_TRACKING_ID_SUCCESS, data);
