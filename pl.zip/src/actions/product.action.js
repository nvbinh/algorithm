import ActionFactory from './actionFactory'
import ActionType from './actionType'

export const initCustomerSessionBegin = () => ActionFactory.ofType(
  ActionType.INIT_CUSTOMER_SESSION_REQUEST_BEGIN)

export const initCustomerSessionSuccess = apiResponse => ActionFactory.create(
  ActionType.INIT_CUSTOMER_SESSION_REQUEST_SUCCESS, apiResponse)

export const initCustomerSessionFailed = apiResponse => ActionFactory.create(
  ActionType.INIT_CUSTOMER_SESSION_REQUEST_FAILED, apiResponse)

export const getProductInfo = () => ActionFactory.ofType(ActionType.GET_PRODUCT_INFO)

export const getProductInfoSuccess = apiResponse => ActionFactory.create(
  ActionType.GET_PRODUCT_INFO_REQUEST_SUCCESS, apiResponse)

export const getProductInfoFailed = apiResponse => ActionFactory.create(
  ActionType.GET_PRODUCT_INFO_REQUEST_FAILED, apiResponse)
