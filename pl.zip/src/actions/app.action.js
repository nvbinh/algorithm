import ActionType from '../actions/actionType'
import ActionFactory from '../actions/actionFactory'

export const setRedirectUrl = redirectUrl => ActionFactory.create(
  ActionType.SET_REDIRECT_URL, redirectUrl)

export const getLOVBegin = () => ActionFactory.ofType(
  ActionType.GET_LOV_REQUEST_BEGIN)

export const getLOVSuccess = apiResponse => ActionFactory.create(
  ActionType.GET_LOV_REQUEST_SUCCESS, apiResponse)

export const getLOVFailed = apiResponse => ActionFactory.create(
  ActionType.GET_LOV_REQUEST_FAILED, apiResponse)