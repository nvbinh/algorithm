import AppService from '../services/app.service'
import { logDurationTimeToServer } from '../actions/actionCreator'
import CacheUtils from '../utils/cacheUtils'

const logDurationTimeEpic = (action$, store) => action$
  .ofType(logDurationTimeToServer().type)
  .mergeMap(action => {
    const {
      customerSubmitLoanResponse: {customerId, customerSession: {accessToken}}
    } = store.getState()
    const timeTracking = CacheUtils.loadCachedData(CacheUtils.SESSION_STORAGE_TRACKING_TIME)

    return new AppService(store.dispatch)
      .logDurationTime({
        auth: {customerId, accessToken},
        durationTimeRequest: {...timeTracking}
      })
  })
  .ignoreElements()

export default logDurationTimeEpic
