import { getConfigurationsSuccess } from './../actions/actionCreator'
import ActionType from './../actions/actionType'
import getConfigurations from './getConfigurations'

const getConfigurationsEpic = (action$, store) =>
  action$
    .ofType(ActionType.GET_LOAN_CONFIG)
    .mergeMap(() => getConfigurations(store))
    .map(data => getConfigurationsSuccess(data))

export default getConfigurationsEpic
