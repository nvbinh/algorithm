import AppService from '../services/app.service'
import ActionType from './../actions/actionType'
import CacheUtils from '../utils/cacheUtils'
import { getLOVSuccess } from '../actions/app.action'
import DataConvertUtils from '../utils/dataConvertUtils'

const getLOVEpic = (action$, store) =>
  action$.ofType(ActionType.GET_LOV)
    .mergeMap(action =>
      CacheUtils.handleRequest(
        new AppService(store.dispatch).getLOV(),
        CacheUtils.LOCAL_STORAGE_KEY_GET_LOV)
    )
    .map(okResp => getLOVSuccess({
      data: {
        ...okResp.data,
        emergencyRelationship: DataConvertUtils.convertLOVToListOfEmergencyContactRelationship(okResp && okResp.data ? okResp.data : [])
      }
    }))

export default getLOVEpic
