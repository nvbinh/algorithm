import Rx from "rxjs/Rx";
import CacheUtils from "../utils/cacheUtils";
import CustomerService from "../services/customer.service";
import { formatPhoneNumber } from "../utils/formatUtils";
import { getSourceChannel } from "../utils/sourceChannelUtils";
import { MarriageStatus, PL_KEY, PL_KEY_SOURCE } from "./../common/constants";
import {
  createCustomer as createCustomerAction,
  createCustomerSuccess,
  createCustomerFail,
  getOtp,
  logCampaignAnalytic
} from "../actions/actionCreator";

export const createCustomer = (action$, store) =>
  action$.ofType(createCustomerAction().type).mergeMap(({ payload: { reCaptchaToken } }) => {
    const customerInfo = createLoanSubmissionRequestBody(store.getState());

    return new CustomerService(store.dispatch)
      .createCustomer(reCaptchaToken, customerInfo)
      .flatMap(
        ({ data, errors, success }) =>
          success
            ? Rx.Observable.concat(
                Rx.Observable.of(createCustomerSuccess(data)),
                Rx.Observable.of(getOtp()),
                Rx.Observable.of(logCampaignAnalytic())
              )
            : Rx.Observable.of(createCustomerFail(errors[0]))
      )
      .catch(throwable => Rx.Observable.of(createCustomerFail(throwable)));
  });

  const createLoanSubmissionRequestBody = ({
    form,
    getConfigurationsAPIResponse,
    loanInformation,
    getLOVAPIResponse
  }) => {
    const personalInfo = form.customerPersonalInformation.values;
    const workingInfo = form.customerWorkingInformation.values;
    const financialInfo = form.customerFinancialInformation.values;
    const configurations = getConfigurationsAPIResponse && getConfigurationsAPIResponse.configurations;
    const maritalStatus = personalInfo.marriageStatus === MarriageStatus.MARRIED ? "K" : "B";
    const numberOfChildren = personalInfo.numberOfKids || 0;
    const occupationCode = getOccupationCode(
      getLOVAPIResponse.data.occupations,
      workingInfo.occupation.value,
      workingInfo.jobTitle.key
    );
    const {day, month, year} = personalInfo.birthday;
    return {
      customer: {
        title: null,
        name: personalInfo.fullName,
        dateOfBirth: `${day}-${month.id}-${year}`,
        gender: null,
        maritalStatus: maritalStatus,
        phoneNumber: formatPhoneNumber(personalInfo.phoneNumber),
        email: personalInfo.email,
        motherMaidenName: null,
        numberOfChildren: numberOfChildren,
        nik: personalInfo.nik,
        address1: personalInfo.sameAddress ? null : personalInfo.address,
        address2: null,
        town: personalInfo.sameAddress ? null : personalInfo.city.key,
        district: personalInfo.sameAddress ? null : personalInfo.district,
        village: personalInfo.sameAddress ? null : personalInfo.ward,
        ownerStatus: "OWNER",
        placeOfBirth: null,
        sameWithKtpAddress: personalInfo.sameAddress
      },
      emergencyContact: {
        name: personalInfo.emergencyFullName,
        phoneNumber: formatPhoneNumber(personalInfo.emergencyPhoneNumber),
        relationship: personalInfo.relationship.key
      },
      customerOption: {},
      loanInformation: {
        purposeName: financialInfo.loanStatus.key,
        amount: loanInformation.amount,
        installmentIndicator: financialInfo.haveMonthlyInstallment,
        interest: configurations.interestRate,
        tenure: loanInformation.tenure,
        installmentAmount: loanInformation.monthlyInstallmentAmount,
        otherInstallmentAmount: financialInfo.haveMonthlyInstallment
          ? Number.parseInt(financialInfo.totalInstallment, 10)
          : 0
      },
      employment: {
        employerName: workingInfo.companyName,
        occupation: occupationCode,
        jobTitle: workingInfo.jobTitle.key,
        lineOfBusinessGroup: workingInfo.lineOfBusinessGroup.key,
        lineOfBusiness: workingInfo.lineOfBusiness.key,
        monthlyIncome: financialInfo.declaredIncome
      },
      salesChannel: {
        sourceChannel: getSourceChannel({
          source: CacheUtils.loadCachedData(PL_KEY.UTM_CAMPAIN_SESSION_STORAGE)[PL_KEY_SOURCE]
        })
      }
    };
  };

  const getOccupationCode = (occupations = [], occupationName, jobTitleCode) =>
    occupations
      .filter(({ name }) => occupationName === name)
      .find(({ jobTitles }) => jobTitles.find(({ code }) => code === jobTitleCode)).code;
