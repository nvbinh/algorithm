import Rx from "rxjs/Rx";
import { filter, map } from "rxjs/operators";
import { getWorkingInfoSuccess, getWorkingInfo } from "../actions/actionCreator";
import { ReduxForm } from "../common/constants";

export const workingInformation = (action$, store) =>
  action$.pipe(
    filter(
      ({ type, meta: { form, field } = {} }) =>
        type === getWorkingInfo().type ||
        (type === "@@redux-form/CHANGE" &&
          form === ReduxForm.FORM_CUSTOMER_WORKING_INFORMATION &&
          ["occupation", "jobTitle", "lineOfBusinessGroup"].includes(field))
    ),
    map(({ meta, payload = {} }) => {
      const { type, field } = meta;

      const {
        getLOVAPIResponse: { data: lov },
        getLovMappingResponse: lovMapping,
        form
      } = store.getState();

      const { values: workingInformation } = form[ReduxForm.FORM_CUSTOMER_WORKING_INFORMATION];

      return Rx.Observable.of(
        {
          get_occupation: () => ({
            occupation: {
              data: dataConvert.getOccupationGroupByName(lov.occupations)
            }
          }),
          occupation: ({ value: occupationName }) => ({
            jobTitle: {
              data: dataConvert.getJobTitle(lov.occupations, occupationName),
              isEnable: !!occupationName
            }
          }),
          jobTitle: ({ key: jobTitleCode }) => {
            const isDefaultJobTitle = dataConvert.isDefaultJobTitle(
              lov.occupations,
              workingInformation.occupation.value,
              jobTitleCode
            );

            return !isDefaultJobTitle
              ? {
                  lineOfBusinessGroup: {
                    data: dataConvert.getLineOfBusinessGroup(lov.lineOfBusinessGroups),
                    isEnable: !isDefaultJobTitle
                  }
                }
              : {
                  lineOfBusinessGroup: {
                    isEnable: false,
                    value: dataConvert
                      .getLobGroupDefault(lovMapping.data.jobTitles, jobTitleCode)
                      .map(({ code, name }) => ({ key: code, value: name }))[0]
                  },
                  lineOfBusiness: {
                    isEnable: false,
                    value: dataConvert
                      .getLobDefault(lovMapping.data.jobTitles, jobTitleCode)
                      .map(({ code, name }) => ({ key: code, value: name }))[0]
                  }
                };
          },
          lineOfBusinessGroup: ({ value: lineOfBusinessGroup }) => ({
            lineOfBusiness: {
              data: dataConvert.getLinesOfBusiness(lov.lineOfBusinessGroups, lineOfBusinessGroup),
              isEnable: !!workingInformation.lineOfBusinessGroup.value
            }
          })
        }[type || field](payload)
      );
    }),
    map(({ value }) => getWorkingInfoSuccess(value))
  );

const dataConvert = (() => {
  const getOccupationGroupByName = (occupations = []) =>
    occupations.groupBy(occupation => occupation.name).map(({ key }) => ({
      key,
      value: key
    }));

  const getJobTitle = (occupations = [], occupationName) =>
    occupations
      .filter(({ name }) => name === occupationName)
      .flatMap(({ jobTitles }) => jobTitles.map(({ code, name }) => ({ key: code, value: name })));

  const getLineOfBusinessGroup = (lineOfBusinessGroups = []) =>
    lineOfBusinessGroups.map(({ code, name }) => ({ key: code, value: name }));

  const getLinesOfBusiness = (lineOfBusinessGroups = [], lineOfBusinessGroup) =>
    lineOfBusinessGroups
      .filter(({ name }) => name === lineOfBusinessGroup)
      .slice(0, 1)
      .flatMap(({ linesOfBusiness = [] }) => linesOfBusiness)
      .map(({ code, name }) => ({ key: code, value: name }));

  const getOccupationCode = (occupations = [], occupationName, jobTitleCode) =>
    occupations
      .filter(({ name }) => occupationName === name)
      .find(({ jobTitles }) => jobTitles.find(({ code }) => code === jobTitleCode)).code;

  const isDefaultJobTitle = (occupations = [], occupationName, jobTitleCode) =>
    occupations
      .filter(({ name }) => occupationName === name)
      .find(({ jobTitles }) => jobTitles.find(jobTitle => jobTitle.code === jobTitleCode))
      .jobTitles.find(({ code }) => code === jobTitleCode).isDefault;

  const getLobGroupDefault = (listJobTitleDefault = [], jobTitleCode) =>
    listJobTitleDefault
      .filter(({ code }) => code === jobTitleCode)
      .slice(0, 1)
      .map(({ lineOfBusinessGroups = [] }) => lineOfBusinessGroups[0]);

  const getLobDefault = (listJobTitleDefault = [], jobTitleCode) =>
    listJobTitleDefault
      .filter(({ code }) => code === jobTitleCode)
      .slice(0, 1)
      .map(({ lineOfBusinessGroups = [] }) => lineOfBusinessGroups[0])
      .map(({ linesOfBusiness = [] }) => linesOfBusiness[0]);

  return {
    getOccupationGroupByName,
    getJobTitle,
    getLineOfBusinessGroup,
    getLinesOfBusiness,
    getOccupationCode,
    isDefaultJobTitle,
    getLobGroupDefault,
    getLobDefault
  };
})();
