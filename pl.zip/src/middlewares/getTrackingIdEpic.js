import { getTrackingId, getTrackingIdSuccess } from './../actions/actionCreator'
import TrackingService from './../services/trackingService';

const getTrackingIdEpic = (action$, store) =>
    action$
        .ofType(getTrackingId().type)
        .switchMap(action =>
            new TrackingService(store.dispatch)
                .getTrackingId(action.payload)
                .map(({data}) => getTrackingIdSuccess({data}))
        );

export default getTrackingIdEpic
