import AppService from '../services/app.service'
import ActionType from './../actions/actionType'
import CacheUtils from '../utils/cacheUtils'
import ActionFactory from "../actions/actionFactory";

const getLOVMappingEpic = (action$, store) =>
  action$.ofType(ActionType.GET_LOV_MAPPING)
    .mergeMap(() =>
      CacheUtils.handleRequest(
        new AppService(store.dispatch).getLOVMapping(),
        CacheUtils.LOCAL_STORAGE_KEY_GET_LOV_MAPPING)
    )
    .map(okResp => ActionFactory.create(ActionType.GET_LOV_MAPPING_REQUEST_SUCCESS, okResp))

export default getLOVMappingEpic
