import Rx from 'rxjs'
import { getDecisionStatus, getDecisionStatusSuccess, getDecisionStatusFailed } from '../actions/actionCreator'
import DecisionService from './../services/decision.service'
import { DecisionStatus } from '../common/constants'

const timeoutObject = {
  data: {
    jobStatus: DecisionStatus.TIME_OUT
  }
}

const getDecisionStatusEpic = (action$, store) =>
  action$.ofType(getDecisionStatus().type)
    .mergeMap(() => {
      const {
        getConfigurationsAPIResponse: {configurations: {desisionStatusInterval, desisionStatusMaxInterval}},
        customerSubmitLoanResponse: {customerSession: {accessToken}},
        otpStatus: {validate: {jobId}}
      } = store.getState()
      return Rx.Observable.of({
        payload: {
          accessToken,
          jobId,
          timeInterval: (desisionStatusInterval * 1000),
          maxInterval: (desisionStatusMaxInterval * 1000)
        }
      })
    })
    .flatMap(dataRequest => {
      const {accessToken, jobId, timeInterval, maxInterval} = dataRequest.payload
      const maxCounter = maxInterval / timeInterval
      const apiStream = new DecisionService(store.dispatch).getDecisionStatus(accessToken, jobId)
        .map((resp) => {
          const {data: {jobStatus}} = resp
          if (jobStatus === DecisionStatus.RUNNING) {
            throw resp
          }
          return resp
        })
        .retryWhen(errors => errors
          .zip(Rx.Observable.range(1, maxCounter))
          .flatMap(val => val[1] === maxCounter
            ? Rx.Observable.throw(maxCounter)
            : Rx.Observable.timer(timeInterval)))
        .catch(() => Rx.Observable.of(timeoutObject))

      const timeoutStream = Rx.Observable.timer(maxInterval)
        .map(() => timeoutObject)

      return Rx.Observable.merge(apiStream, timeoutStream)
    })
    .first()
    .map(resp => resp.data)
    .map(data => getDecisionStatusSuccess(data))
    .catch(error => Rx.Observable.of(getDecisionStatusFailed(error)))



export default getDecisionStatusEpic
