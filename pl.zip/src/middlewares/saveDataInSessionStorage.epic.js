import { saveDataInSessionStorage } from '../actions/actionCreator'
import CacheUtils from '../utils/cacheUtils'

const saveDataInSessionStorageEpic = (action$, store) => action$
  .ofType(saveDataInSessionStorage().type)
  .do(({payload: {key, data}}) => {
    CacheUtils.saveDataToCache(key, {
      ...CacheUtils.loadCachedData(key),
      ...data
    })
  })
  .ignoreElements()

export default saveDataInSessionStorageEpic
