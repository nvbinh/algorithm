import SessionService from './../services/session.service'
import { revokeCustomerSession } from '../actions/actionCreator'

const revokeCustomerSessionEpic = (action$, store) =>
  action$.ofType(revokeCustomerSession().type)
    .mergeMap(() => {
      const {customerSubmitLoanResponse: {customerSession: {accessToken}}} = store.getState()

      return new SessionService(store.dispatch)
        .revokeCustomerSession({
          method: 'WEB',
          sessionKey: accessToken
        })
    })
    .ignoreElements()

export default revokeCustomerSessionEpic
