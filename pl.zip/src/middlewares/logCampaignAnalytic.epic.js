import Rx from "rxjs";
import AppService from "../services/app.service";
import { logCampaignAnalytic } from "../actions/actionCreator";
import CacheUtils from "../utils/cacheUtils";
import { PL_KEY } from "../common/constants";

const logCampaignAnalyticEpic = (action$, store) =>
  action$
    .ofType(logCampaignAnalytic().type)
    .mergeMap(action => {
      const {
        customerSubmitLoanResponse: {
          customerId,
          customerSession: { accessToken }
        }
      } = store.getState();
      const campaignAnalytic = CacheUtils.loadCachedData(PL_KEY.UTM_CAMPAIN_SESSION_STORAGE);

      return (
        (Object.keys(campaignAnalytic).length !== 0 &&
          new AppService(store.dispatch).logCampaignAnalytic({
            auth: { accessToken },
            analyticRequest: {
              customerId,
              data: { ...campaignAnalytic }
            }
          })) ||
        Rx.Observable.empty()
      );
    })
    .ignoreElements();

export default logCampaignAnalyticEpic;
