import ConfigurationsService from './../services/configurations.service'
import CacheUtils from '../utils/cacheUtils'

export default function getConfigurations({dispatch}) {
    const fetchConfig = new ConfigurationsService(dispatch)
        .getConfigurations()
        .map(resp => resp.data)
        .map(({configurations}) =>
            (configurations &&
                configurations.reduce((acc, cur) => ({...acc, ...{[cur.key]: cur.value}}), {})) ||
            {})
        .map(config => mapObjectResponseToLoanConfig(config))
        .map(configurations => ({data: {configurations: configurations}}))

    return CacheUtils.handleRequest(fetchConfig, CacheUtils.LOCAL_STORAGE_KEY_GET_LOAN_CONFIG)
}

const mapObjectResponseToLoanConfig = (config) => ({
    interestRate: Number(config['personalloan.interest.month']),
    minAmount: Number(config['personalloan.min_amount']),
    maxAmount: Number(config['personalloan.max_amount']),
    stepAmount: Number(config['personalloan.step_amount']),
    minTenure: Number(config['personalloan.min_tenure']),
    maxTenure: Number(config['personalloan.max_tenure']),
    penaltyFee: Number(config['personalloan.penalty_fee']),
    minIncome: Number(config['personalloan.min_income']),
    minAge: Number(config['personalloan.min_age']),
    timeCaching: Number(config['personalloan.time.caching']),
    timeCarousel: Number(config['personalloan.time.carousel']),
    clientRecaptchaGoogle: config['personalloan.client.recaptcha.google'],
    validityPeriod: Number(config['personalloan.application.validityperiod']),
    limitedRecordSearchingCompany: Number(config['personalloan.company.searching.max_record']),
    gaTrackingId: config['personalloan.google.analytics.id'],
    desisionStatusInterval: Number(config['personalloan.decision.status.time.interval']),
    desisionStatusMaxInterval: Number(config['personalloan.decision.status.max.interval']),
    otpTemplate: config['personalloan.otp.verification.template.name'],
    kioskLocationUrl: "https://www.commbank.co.id/upublic/mod_home/default_content.aspx?code=TymeDigital#tymedigital",
    companySearchFreeText: config['personalloan.company.search.freetext'],
    debtBurdenRatio: Number(config['personalloan.debt.burden.ratio']),
    proxyExpensePercent: {
        single: Number(config['personalloan.proxy.expense.percent.single']),
        single_parent: Number(config['personalloan.proxy.expense.percent.single_parents']),
        married: Number(config['personalloan.proxy.expense.percent.married_with_single_income'])
    },
    proxyExpenseOnNumberOfChildren: Number(config['personalloan.proxy.expense.onnumberofchildren']),
    utmParameterTracking: String(config['pixel_gtag_utm_parameter'])
})
