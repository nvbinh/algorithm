import ActionType from './../actions/actionType'
import CacheUtils from '../utils/cacheUtils'

const logDurationTime = ({trackingTime = {}, payload = {}}) => {
  return !!Object.keys(payload).length
    ? {
      ...trackingTime,
      [payload.pageName]: (trackingTime[payload.pageName] || 0) + payload.duration
    }
    : {...trackingTime}
}

export const timeLoggerEpic = (action$, store) =>
  action$.ofType(ActionType.LOG_TIME)
    .do(({payload: {pageName, duration}}) => {
      const trackingTimeSessionStorage = CacheUtils.loadCachedData(CacheUtils.SESSION_STORAGE_TRACKING_TIME)
      const trackingTimeCurrent = logDurationTime({
        trackingTime: {...trackingTimeSessionStorage},
        payload: {pageName, duration}
      })

      CacheUtils.saveDataToCache(CacheUtils.SESSION_STORAGE_TRACKING_TIME, trackingTimeCurrent)
    })
    .ignoreElements()

export default timeLoggerEpic
