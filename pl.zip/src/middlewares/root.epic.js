import { combineEpics } from "redux-observable";
import getLOVEpic from "./lov.epic";
import getConfigurationsEpic from "./configurations.epic";
import { createCustomer } from "./createCustomer";
import getLOVMappingEpic from "./lovMapping.epic";
import getDecisionStatusEpic from "./decision.epic";
import getAutomationConfigurationsEpic from "./automationConfigurationsEpic";
import revokeCustomerSessionEpic from "./session.epic";
import getCompanyNameEpic from "./getCompanyNameEpic";
import { generateOtpEpic, validateOtpEpic } from "./otp";
import { timeLoggerEpic } from "./timeLogger.epic";
import logDurationTimeEpic from "./logDurationTime.epic";
import saveDataInSessionStorageEpic from "./saveDataInSessionStorage.epic";
import logCampaignAnalyticEpic from "./logCampaignAnalytic.epic";
import { workingInformation } from "./workingInformation";
import getTrackingIdEpic from "./getTrackingIdEpic";

const rootEpic = combineEpics(
    getLOVEpic,
    getLOVMappingEpic,
    getConfigurationsEpic,
    createCustomer,
    getDecisionStatusEpic,
    getAutomationConfigurationsEpic,
    revokeCustomerSessionEpic,
    getCompanyNameEpic,
    generateOtpEpic,
    validateOtpEpic,
    timeLoggerEpic,
    logDurationTimeEpic,
    saveDataInSessionStorageEpic,
    logCampaignAnalyticEpic,
    workingInformation,
    getTrackingIdEpic
);

export default rootEpic;
