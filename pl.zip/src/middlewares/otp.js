import Rx from 'rxjs/Rx'
import OtpService from '../services/otp'
import {
  getOtp,
  getOtpSuccess,
  getOtpFail,
  validateOtp,
  validateOtpSuccess,
  validateOtpFail
} from '../actions/actionCreator'
import { OtpStatus, ErrorStatus } from '../common/constants'
import { formatPhoneNumber } from '../utils/formatUtils'

const OtpStatusMapping = {
  'IC00601': OtpStatus.EXPIRED,
  'IC00602': OtpStatus.INVALID,
  'IC00600': OtpStatus.BLOCK,
  'IC00500': OtpStatus.EXCEPTION,
  'IC00400': OtpStatus.NOT_EXIST,
  '0000000': OtpStatus.UNDEFINED
}

const getOtpErrorType = ({code} = {code: '0000000', message: 'unknown'}) => {
  return {status: OtpStatusMapping[code] || OtpStatus.UNDEFINED}
}

export const generateOtpEpic = (action$, store) => {
  return action$.ofType(getOtp().type)
    .mergeMap(action => {
      const {
        customerSubmitLoanResponse: {customerId, customerSession},
        getConfigurationsAPIResponse: {configurations},
        form: {customerPersonalInformation}
      } = store.getState()
      const requestBody = {
        phoneNumber: formatPhoneNumber(customerPersonalInformation.values.phoneNumber),
        applicationNumber: customerSession.applicationNumber,
        accessToken: customerSession.accessToken,
        otpTemplate: configurations.otpTemplate,
        channel: 'PL'
      }

      return new OtpService(store.dispatch)
        .generateOtp(customerId, requestBody)
        .map(({data, errors, success}) => success
          ? getOtpSuccess(data, action.meta)
          : getOtpFail(errors[0], action.meta)
        )
        .catch(throwable => Rx.Observable.of(getOtpFail(throwable, action.meta)))
    })
}

export const validateOtpEpic = (action$, store) => {
  return action$.ofType(validateOtp().type)
    .mergeMap(action => {
      const {
        customerSubmitLoanResponse: {customerId, customerSession: {accessToken}}
      } = store.getState()
      const {otpCode} = action.payload
      const requestBody = {
        customerId,
        accessToken,
        otpCode,
        channel: 'PL'
      }

      return new OtpService(store.dispatch)
        .validateOtp(requestBody)
        .map(({data, errors, success}) => success
          ? validateOtpSuccess({jobId: data.jobId})
          : validateOtpFail(getOtpErrorType(errors[0]))
        )
        .catch(() => Rx.Observable.of(validateOtpFail({status: ErrorStatus.NETWORK})))
    })
}



export default {generateOtpEpic, validateOtpEpic}
