import { connect } from "react-redux";
import { Pending as PurePending } from "../components";

import { maskEmailAddress } from "../utils/formatUtils";

export const Pending = connect(({ form: { customerPersonalInformation: { values: { email } } } }) => ({
  email: maskEmailAddress(email)
}))(PurePending);
