import { connect } from "react-redux";
import { Loading as PureLoading } from "../components";
import { logDurationTimeToServer, revokeCustomerSession } from "../actions/actionCreator";

export const Loading = connect(
  ({ decisionStatus }) => ({ decisionStatus }),
  dispatch => ({
    revokeCustomerSession: () => dispatch(revokeCustomerSession()),
    logDurationTimeToServer: () => dispatch(logDurationTimeToServer())
  })
)(PureLoading);
