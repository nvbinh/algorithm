import React from "react";
import { connect } from "react-redux";
import { Field, reduxForm, resetSection } from "redux-form";

import AppPageURL from "../common/appPageURL";
import { MaxLength, ReduxForm } from "../common/constants";
import { minRequired, required } from "../common/validator";
import NextBackGroupButton from "../components/widget/nextBackGroupButton";
import { LoanPurpose, CurrencyInput, YesNoGroup } from "../components/views";

import { ic_biaya } from "../resources";

const monthlyIncomeEmptyValidation = required("Masukkan penghasilan bersih per bulan Anda");
const monthlyInterestEmptyValidation = required("Masukkan total angsuran per bulan Anda");
const monthlyInterestCheckerValidation = required("Anda harus menjawab pertanyaan ini");
const loanPurposeEmptyValidation = required("Pilih tujuan pinjaman Anda");

const renderMonthlyInterestChecker = field => (
  <YesNoGroup
    {...field}
    error={field.meta.touched && field.meta.error}
    value={field.haveMonthlyInstallment}
    onCheck={field.input.onChange}
  />
);

const renderLoanStatus = field => (
  <LoanPurpose
    {...field}
    value={field.input.value}
    onChange={field.input.onChange}
    error={field.meta.touched && field.meta.error}
    id={field.input.name}
  />
);

const renderCurrencyInput = field => (
  <CurrencyInput
    {...field}
    value={field.input.value}
    onChange={field.input.onChange}
    onBlur={field.input.onBlur}
    error={field.meta.touched && field.meta.error}
  />
);

export const FinancialInformation = connect(
  (
    {
      getConfigurationsAPIResponse: {
        configurations: { minIncome }
      },
      form: { customerFinancialInformation: { values } = { values: {} } },
      getLOVAPIResponse: {
        data: { loanPurpose = [] }
      }
    },
    ownProps
  ) => ({
    ...ownProps,
    ...values,
    loanPurposes: loanPurpose.map(({ name }) => ({
      key: name,
      value: name
    })),
    minIncome
  }),
  dispatch => ({
    resetMonthlyInstallment: () =>
      dispatch(resetSection(ReduxForm.FORM_CUSTOMER_FINANCIAL_INFORMATION, ["totalInstallment"]))
  })
)(
  reduxForm({
    form: ReduxForm.FORM_CUSTOMER_FINANCIAL_INFORMATION,
    destroyOnUnmount: false,
    forceUnregisterOnUnmount: true
  })(
    ({
      handleSubmit,
      history,
      declaredIncome,
      haveMonthlyInstallment,
      totalInstallment,
      minIncome,
      loanPurposes = [],
      resetMonthlyInstallment
    }) => (
      <form onSubmit={handleSubmit(()=>{})}>
        <div className="step-content" id="stepFinancial">
          <div className="container">
            <Field
              name="loanStatus"
              component={renderLoanStatus}
              loanPurposes={loanPurposes.slice(0, 5)}
              validate={loanPurposeEmptyValidation}
            />
            <div className="row contoh">
              <div className="col-12">
                <h3>Tentang Keuangan Anda</h3>
                <Field
                  className="declaredIncomeField net-income__container"
                  component={renderCurrencyInput}
                  name="declaredIncome"
                  label="Penghasilan Bersih per Bulan"
                  value={declaredIncome}
                  maxLength={MaxLength.INPUT_DECLARED_INCOME}
                  validate={[
                    monthlyIncomeEmptyValidation,
                    minRequired(minIncome)("Penghasilan bersih per bulan minimum")
                  ]}
                />
                <div className="installment row">
                  <div className="col left-icon">
                    <img className="img-fluid" src={ic_biaya} alt="biaya" />
                  </div>
                  <div className="col right-content">
                    <div className="form-group d-flex flex-column">
                      <div className="right-content__top">
                        <label className="title" htmlFor="monthlyInstallmentRadio">
                          Apakah saat ini Anda memiliki angsuran per bulan?<span className="gray-small-text d-block">
                            (contoh: KPR, KTA, Pinjaman Koperasi dll)
                          </span>
                        </label>
                      </div>
                      <Field
                        className="right-content__bottom"
                        name="haveMonthlyInstallment"
                        haveMonthlyInstallment={haveMonthlyInstallment}
                        component={renderMonthlyInterestChecker}
                        validate={monthlyInterestCheckerValidation}
                        onChange={resetMonthlyInstallment}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="row total">
              <div className="total__container col-12">
                {haveMonthlyInstallment && (
                  <Field
                    component={renderCurrencyInput}
                    name="totalInstallment"
                    label="Total Angsuran per Bulan"
                    maxLength={MaxLength.INPUT_TOTAL_INSTALLMENT}
                    validate={monthlyInterestEmptyValidation}
                  />
                )}
              </div>
            </div>
            <NextBackGroupButton
              id="step-financial-group-button"
              onNextClick={handleSubmit(() => history.push(AppPageURL.CUSTOMER_INFORMATION_WORKING_INFO))}
              onBackClick={() => history.push(AppPageURL.CUSTOMER_INFORMATION_PERSONAL_INFO)}
            />
          </div>
        </div>
      </form>
    )
  )
);
