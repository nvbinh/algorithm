import React from "react";
import { connect } from "react-redux";
import { lifecycle } from "recompose";
import Modal from "react-modal";

import { TermAndConditionEnhance as PureTermAndCondition } from "../components/views";
import LoadingModal from "../components/widget/loadingModal";

import AppPageURL from "../common/appPageURL";
import { PLStatus } from "../common/constants";
import { createCustomer } from "../actions/actionCreator";

import iconOop from "../assets/images/icon-oops.png";

const preloadOopImage = () => (new Image().src = iconOop);

export const TermAndConditionEnhance = lifecycle({
  componentWillReceiveProps({ createCustomerStatus, otpStatus, history }) {
    (createCustomerStatus === PLStatus.FAILED || otpStatus === PLStatus.FAILED) &&
      history.push(AppPageURL.OTP_EXCEPTION_PAGE);

    otpStatus === PLStatus.SUCCESS && history.push(AppPageURL.OTP_PAGE);
  },

  componentWillMount() {
    Modal.setAppElement("body");
  },

  componentDidMount() {
    window.scrollTo(0, 0);
    preloadOopImage();
  }
})(({ reCaptchaSiteKey, createCustomerStatus, otpStatus, createCustomer, history }) => (
  <div>
    <PureTermAndCondition
      reCaptchar={{ sitekey: reCaptchaSiteKey }}
      onSubmit={({ selectionStatus, reCaptchaToken }) => {
        selectionStatus && reCaptchaToken && createCustomer(reCaptchaToken);

        !selectionStatus && history.push(AppPageURL.CUSTOMER_INFORMATION_REVIEW);
      }}
    />
    <LoadingModal isOpen={createCustomerStatus === PLStatus.PROCCESSING || otpStatus === PLStatus.PROCCESSING} />
  </div>
));

const mapStateToProps = ({
  getConfigurationsAPIResponse: {
    configurations: { clientRecaptchaGoogle }
  },
  customerSubmitLoanResponse: createCustomerInfo,
  otpStatus: { getOtp }
}) => ({
  reCaptchaSiteKey: clientRecaptchaGoogle,
  createCustomerStatus: createCustomerInfo.status,
  otpStatus: getOtp.status
});

const mapDispatchToProps = dispatch => ({
  createCustomer: reCaptchaToken => dispatch(createCustomer({ reCaptchaToken }))
});

export const TermAndCondition = connect(
  mapStateToProps,
  mapDispatchToProps
)(TermAndConditionEnhance);
