import React from "react";
import { lifecycle, compose, withState } from "recompose";
import { connect } from "react-redux";
import { Field, reduxForm } from "redux-form";

import { OptionList } from "../components/views";

import { checkCompanyNameValid, required } from "./../common/validator";

import {
  MaxLength,
  ReduxForm,
  CompanyNameLengthValidator
} from "../common/constants";

import AppPageURL from "../common/appPageURL";
import { AutosuggestionInput } from "./";
import NextBackGroupButton from "../components/widget/nextBackGroupButton";
import {
  getWorkingInfo,
  getCompanyName,
  clearCompanyName
} from "../actions/actionCreator";

const occupationValidation = required("Pilih pekerjaan Anda");
const jobTitleValidation = required("Pilih jabatan Anda");
const lobGroupValidation = required("Pilih jenis bidang/industri Anda");
const lobValidation = required("Pilih jenis bidang/industri Anda");

const companyNameEmptyValidate = required("Cari nama perusahaan Anda");
const companyNameInvalidValidate = checkCompanyNameValid(
  "Format yang Anda masukkan tidak valid"
);
const companyNameInvalidWithLengthFollowFreeTextValidate = companyNameInvalidValidate(
  {
    minLength: CompanyNameLengthValidator.MIN_LENGTH - 1,
    alphabetMinLength: CompanyNameLengthValidator.ALPHABET_MIN_LENGTH
  }
);
const getCompanyNameValidation = isFreeText => [
  companyNameEmptyValidate,
  ...(isFreeText ? [companyNameInvalidWithLengthFollowFreeTextValidate] : [])
];

const renderOptionList = props => (
  <OptionList
    {...props}
    id={props.input.name}
    newValue={props.input.value}
    value={props.input.value}
    onChange={props.input.onChange}
    error={(props.meta.touched && props.meta.error) || void 0}
  />
);

const renderCompanyNameInput = props => (
  <AutosuggestionInput
    {...props}
    selectedValue={props.input.value}
    onChange={props.input.onChange}
  />
);

const optionListValueformat = ({ value } = { value: void 0 }) => value;

const working_field = [
  "companyName",
  "occupation",
  "jobTitle",
  "lineOfBusinessGroup",
  "lineOfBusiness"
];

export const WorkingInformation = compose(
  lifecycle({
    componentDidMount() {
      this.props.getOccupationWorkingInfo();
    }
  }),
  withState("isFormValid", "setFormValid", false)
)(
  ({
    history,
    handleSubmit,
    untouch,
    companyName = {},
    occupation = {},
    jobTitle = {},
    lineOfBusiness = {},
    lineOfBusinessGroup = {},
    isFormValid,
    setFormValid,
    ...props
  }) => {
    return (
      <form>
        <div className="step-content" id="stepWorkingInformation">
          <div className="container">
            <div className="row">
              <div className="col-12">
                <h3>Tentang Pekerjaan / Usaha Anda</h3>
              </div>
              <Field
                component={renderCompanyNameInput}
                className="company__container col-12 form-group"
                name="companyName"
                id="companyName"
                maxLength={MaxLength.INPUT_COMPANY_NAME}
                label="Nama Perusahaan / Usaha Anda"
                suggestions={companyName.searchList}
                minimalSearchingLength={4}
                notFoundErrorMessage="Cari nama perusahaan Anda"
                emptySearchResultMessage="Maaf, perusahaan Anda belum terdaftar pada list perusahaan kami"
                validate={getCompanyNameValidation(companyName.isFreeText)}
                {...{ ...props, ...companyName }}
                isQueryIncludeSearchData={value => setFormValid(value)}
              />
              <Field
                component={renderOptionList}
                className="work__container col-12 form-group"
                dialogTitle="Pilih Pekerjaan"
                dataList={occupation.data}
                name="occupation"
                hint="Pilih pekerjaan"
                label="Pekerjaan"
                format={optionListValueformat}
                validate={occupationValidation}
              />
              <Field
                component={renderOptionList}
                className={`position__container col-12 form-group`}
                dialogTitle="Pilih Jabatan"
                dataList={jobTitle.data}
                hint="Pilih jabatan"
                name="jobTitle"
                label="Jabatan"
                format={optionListValueformat}
                enable={jobTitle.isEnable}
                validate={jobTitleValidation}
              />
            </div>
            <div className="row">
              <Field
                component={renderOptionList}
                className={"industry-one__container col-12 col-sm-6 form-group"}
                dialogTitle="Pilih Jenis Bidang/Industri"
                dataList={lineOfBusinessGroup.data}
                name="lineOfBusinessGroup"
                hint="Pilih jenis bidang/industri"
                enable={lineOfBusinessGroup.isEnable}
                format={optionListValueformat}
                label="Jenis Bidang/Industri"
                validate={lobGroupValidation}
              />
              <Field
                component={renderOptionList}
                className={
                  "industry-two__container col-12 col-sm-6 form-group hidden-label"
                }
                dialogTitle="Pilih Bidang/Industri"
                dataList={lineOfBusiness.data}
                hint="Pilih jenis bidang/industri"
                name="lineOfBusiness"
                format={optionListValueformat}
                enable={lineOfBusiness.isEnable}
                label="&nbsp;"
                validate={lobValidation}
              />
            </div>

            <NextBackGroupButton
              id="step-working-group-button"
              className="row-button"
              onNextClick={handleSubmit(data => {
                companyName.isFreeText
                  ? history.push(AppPageURL.CUSTOMER_INFORMATION_REVIEW)
                  : isFormValid &&
                    history.push(AppPageURL.CUSTOMER_INFORMATION_REVIEW);
              })}
              onBackClick={() => {
                untouch(...working_field);
                history.push(AppPageURL.CUSTOMER_INFORMATION_FINANCIAL_INFO);
              }}
            />
          </div>
        </div>
      </form>
    );
  }
);

export const mapStateToProps = (
  {
    getConfigurationsAPIResponse: { configurations },
    workingInformation,
    companyNames,
    ...state
  },
  ownProps
) => {
  return {
    companyName: {
      isFreeText: configurations.companySearchFreeText === "Y",
      ...companyNames
    },
    ...workingInformation,
    ...ownProps
  };
};

export const WorkingInformationContainer = connect(
  mapStateToProps,
  dispatch => ({
    getOccupationWorkingInfo: () =>
      dispatch(getWorkingInfo({ type: "get_occupation" })),
    onSuggestionsFetchRequested: ({ value }) => dispatch(getCompanyName(value)),
    onSuggestionsClearRequested: () => dispatch(clearCompanyName())
  })
)(
  reduxForm({
    form: ReduxForm.FORM_CUSTOMER_WORKING_INFORMATION,
    touchOnBlur: true,
    touchOnChange: false,
    destroyOnUnmount: false
  })(WorkingInformation)
);
