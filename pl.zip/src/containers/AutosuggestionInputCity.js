import React from "react";
import Autosuggest from "react-autosuggest";
import match from "autosuggest-highlight/match";
import parse from "autosuggest-highlight/parse";

import { CityInput } from "../components/views/";

export class AutosuggestionInputCity extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      value: props.selectedValue || "",
      suggestions: props.suggestions
    };
  }

  // Use your imagination to render suggestions.
  renderSuggestion = (suggestion, { query }) => {
    const matches = match(suggestion.value, query);
    const parts = parse(suggestion.value, matches);
    return (
      <span className={"suggestion-content city-suggestion-content"}>
        {parts.map((part, index) => (
          <span className={part.highlight ? "react-autosuggest__suggestion-match" : null} key={index}>
            {part.text}
          </span>
        ))}
      </span>
    );
  };

  onChange = (event, { newValue: value }) => {
    this.setState({ value });
  };

  onSuggestionSelected = (event, { suggestion }) => {
    this.props.onCitySelected(suggestion);
  };

  renderInputComponent = inputProps => <CityInput {...inputProps} />;

  renderSuggestionsContainer = ({ containerProps, children, query }) => {
    const { emptySearchResultMessage } = this.props;

    return children ? (
      <div {...containerProps}>{children}</div>
    ) : (
      <div className={`no-result-container`}>
        <div {...containerProps} className={`information-message`}>
          {emptySearchResultMessage}
        </div>
      </div>
    );
  };

  onSuggestionsFetchRequested = ({ value }) => {
    this.setState({
      suggestions: this.props.suggestions.filter(item => item.value.toLowerCase().includes(value.toLowerCase())) || []
    });
  };

  onSuggestionsClearRequested() {
    this.setState({ suggestions: this.props.suggestions });
  }

  render() {
    let { value, suggestions } = this.state;
    let { className, hint, label, maxLength, isShowModal } = this.props;
    // Autosuggest will pass through all these props to the input.
    let inputProps = {
      placeholder: hint,
      value,
      onChange: this.onChange,
      label,
      maxLength,
      isShowModal
    };

    return (
      <div className={`${className}`}>
        <Autosuggest
          suggestions={suggestions}
          focusInputOnSuggestionClick={false}
          onSuggestionsClearRequested={() => this.onSuggestionsClearRequested}
          onSuggestionsFetchRequested={data => this.onSuggestionsFetchRequested(data)}
          getSuggestionValue={({ value = "" }) => value}
          renderSuggestion={this.renderSuggestion}
          renderInputComponent={this.renderInputComponent}
          renderSuggestionsContainer={this.renderSuggestionsContainer}
          onSuggestionSelected={this.onSuggestionSelected}
          inputProps={inputProps}
          alwaysRenderSuggestions={true}
          highlightFirstSuggestion={true}
        />
      </div>
    );
  }
}
