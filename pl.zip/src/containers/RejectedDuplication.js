import { connect } from "react-redux";

import { RejectedDuplication as PureRejectedDuplication } from "../components";

export const RejectedDuplication = connect(({ form: { customerPersonalInformation: { values: { fullName } } } }) => ({
  name: fullName
    .split(" ")
    .slice(0, 1)
    .toString()
}))(PureRejectedDuplication);
