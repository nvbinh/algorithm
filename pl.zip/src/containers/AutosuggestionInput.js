import React from "react";
import Autosuggest from "react-autosuggest";
import match from "autosuggest-highlight/match";
import parse from "autosuggest-highlight/parse";
import { Field } from "redux-form";
import { connect } from "react-redux";
import { getCompanyName, clearCompanyName } from "../actions/actionCreator";
import { CompanyNameInput } from "../components/views";

import { required, isCompanyNameExisted } from "./../common/validator";

const companyNameExistValidate = isCompanyNameExisted(
  "Maaf, perusahaan Anda belum terdaftar pada list perusahaan kami"
);

const companyNameEmptyValidate = required("Cari nama perusahaan Anda");

export class AutosuggestionInput extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      value: props.selectedValue || "",
      isQueryIncludeSearchData: this._isQueryIncludeSearchData(
        props.suggestions
      )(props.selectedValue),
      suggestions: props.suggestions,
      isInputFocus: void 0,
      isFetching: false
    };
  }

  // Use your imagination to render suggestions.
  renderSuggestion = (suggestion, { query }) => {
    const matches = match(suggestion.value, query);
    const parts = parse(suggestion.value, matches);
    return (
      <span className={"suggestion-content " + suggestion.twitter}>
        <span>
          {parts.map((part, index) => (
            <span
              className={
                part.highlight ? "react-autosuggest__suggestion-match" : null
              }
              key={index}
            >
              {part.text}
            </span>
          ))}
        </span>
      </span>
    );
  };

  onChange = (event, { newValue }) => {
    const isQueryIncludeSearchData = this._isQueryIncludeSearchData(
      this.state.suggestions
    )(newValue);
    this.props.input.onChange(event);
    this.setState({
      value: newValue,
      isQueryIncludeSearchData
    });

    this.props.isQueryIncludeSearchData(isQueryIncludeSearchData);
  };

  onBlur = ({ target: { value } }) => {
    this.props.input.onBlur(value);
    this.setState({ value, isInputFocus: false });

    this.props.isQueryIncludeSearchData &&
      this.props.isQueryIncludeSearchData(this.state.isQueryIncludeSearchData);
  };

  _onFocus = event => {
    this.setState({ isInputFocus: true });
  };

  onSuggestionSelected = (event, { suggestionValue, method }) => {
    this.props.input.onChange(method === "click" ? suggestionValue : event);
  };

  _isQueryIncludeSearchData = (searchList = []) => (query = "") =>
    !!searchList.find(
      ({ value }) => value.toLowerCase() === query.trim().toLowerCase()
    );

  renderInputComponent = props => {
    const {
      value,
      isFetching,
      isInputFocus,
      isQueryIncludeSearchData
    } = this.state;
    const {
      meta: { touched, error },
      emptySearchResultMessage,
      isFreeText
    } = this.props;

    const hasError = touched && (error || !isQueryIncludeSearchData);

    return (
      <div
        className={`${hasError &&
          ((!isQueryIncludeSearchData &&
            !isFetching &&
            !isInputFocus &&
            !isFreeText) ||
            error) &&
          "has-error has-danger"}`}
      >
        <CompanyNameInput {...props} value={value} inputRef={props.ref} />
        {hasError && (
          <span className="help-block with-errors">
            {error ||
              (!isQueryIncludeSearchData &&
                !isFetching &&
                emptySearchResultMessage)}
          </span>
        )}
      </div>
    );
  };

  renderSuggestionsContainer = ({ containerProps, children, query }) => {
    const {
      emptySearchResultMessage,
      minimalSearchingLength,
      isFreeText
    } = this.props;
    const { isInputFocus, isFetching, isQueryIncludeSearchData } = this.state;

    return children ? (
      <div {...containerProps}>{children}</div>
    ) : (
      query.length >= minimalSearchingLength &&
        !isQueryIncludeSearchData &&
        !isFetching &&
        isInputFocus &&
        !isFreeText && (
          <div {...containerProps} className={`information-message`}>
            {emptySearchResultMessage}
          </div>
        )
    );
  };

  shouldRenderSuggestions = value => {
    return value.trim().length >= this.props.minimalSearchingLength;
  };

  onSuggestionsFetchRequested = ({ value }) => {
    value.trim().length >= this.props.minimalSearchingLength &&
      this.props.onSuggestionsFetchRequested({ value });
  };

  onSuggestionsClearRequested() {
    this.setState({ suggestions: [] });
    this.props.onSuggestionsClearRequested();
  }

  componentWillReceiveProps({ suggestions, isFetching }) {
    suggestions !== this.props.suggestions &&
      isFetching !== this.props.isFetching &&
      this.setState({
        suggestions,
        isFetching
      });
  }

  componentDidMount() {
    this.props.isQueryIncludeSearchData &&
      this.props.isQueryIncludeSearchData(this.state.isQueryIncludeSearchData);
  }

  render() {
    let { value, suggestions } = this.state;
    let { className, hint, label, maxLength } = this.props;
    // Autosuggest will pass through all these props to the input.
    let inputProps = {
      placeholder: hint,
      value,
      onChange: this.onChange,
      onBlur: this.onBlur,
      onFocus: this._onFocus,
      label,
      maxLength
    };

    // Finally, render it!
    return (
      <div className={`${className}`}>
        <label htmlFor="companyName" className="gray-small-text">
          {label}
        </label>
        <Autosuggest
          suggestions={suggestions}
          onSuggestionsClearRequested={() => this.onSuggestionsClearRequested}
          onSuggestionsFetchRequested={data =>
            this.onSuggestionsFetchRequested(data)
          }
          getSuggestionValue={({ value = "" }) => value}
          renderSuggestion={this.renderSuggestion}
          renderInputComponent={this.renderInputComponent}
          renderSuggestionsContainer={this.renderSuggestionsContainer}
          shouldRenderSuggestions={this.shouldRenderSuggestions}
          onSuggestionSelected={this.onSuggestionSelected}
          inputProps={inputProps}
          highlightFirstSuggestion={true}
        />
      </div>
    );
  }
}

const renderAutosuggestionInput = props => {
  const { isFreeText, validate } = props;
  const validationList = (isFreeText && validate) || [
    companyNameEmptyValidate,
    companyNameExistValidate(props.suggestions)
  ];
  return (
    <Field
      {...props}
      component={AutosuggestionInput}
      validate={validationList}
    />
  );
};

export const Autosuggestion = connect(
  ({ companyNames }) => ({
    ...companyNames,
    suggestions: companyNames.searchList
  }),
  dispatch => ({
    onSuggestionsFetchRequested: ({ value }) => dispatch(getCompanyName(value)),
    onSuggestionsClearRequested: () => dispatch(clearCompanyName())
  })
)(renderAutosuggestionInput);
