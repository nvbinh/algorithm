import { connect } from "react-redux";
import { lifecycle } from "recompose";

import { resetApp } from "../actions/actionCreator";
import { Landing as LandingComponent } from "../components";

import { formatCurrency, roundFloatingIssue } from "./../utils/formatUtils";

const mapStateToProps = ({
  getConfigurationsAPIResponse: {
    configurations,
    configurations: { interestRate, minAmount, maxAmount, penaltyFee, minIncome }
  }
}) => ({
  configurations: {
    ...configurations,
    interestRate: roundFloatingIssue(interestRate),
    minAmount: formatCurrency(minAmount / 1000000),
    maxAmount: formatCurrency(maxAmount / 1000000),
    minIncome: formatCurrency(minIncome),
    penaltyFee: roundFloatingIssue(penaltyFee)
  }
});

const mapDispatchToProps = dispatch => ({
  resetApp: () => dispatch(resetApp())
});

export const Landing = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  lifecycle({
    componentDidMount() {
      this.props.resetApp();
    }
  })(LandingComponent)
);
