import { connect } from "react-redux";

import { Rejected as PureRejected } from "../components";

export const Rejected = connect(({ form: { customerPersonalInformation: { values: { fullName } } } }) => ({
  name: fullName
    .split(" ")
    .slice(0, 1)
    .toString()
}))(PureRejected);
