import React from "react";
import { Field } from "redux-form";

import { Counter, MaritalStatus, CalendarEnhancer as Calendar } from "../../components/views";
import { renderInput } from "./renderFields";

import validation from "../../utils/validationUtils";
import { MaxLength } from "../../common/constants";

const {
  nameValidation,
  dobValidation,
  nikValidation,
  phoneNumberValidation,
  emailValidation
} = validation.customerPersonalInformation;

const renderMaritalStatus = field => (
  <MaritalStatus {...field} onStatus={field.input.onChange} selectedValue={field.input.value} />
);

const renderCounter = field => <Counter {...field} onValue={field.input.onChange} initialCounter={field.input.value} />;
const renderCalendar = field => (
  <Calendar
    {...field}
    value={field.input.value}
    newValue={field.input.value}
    onChange={field.input.onChange}
    onBlur={field.input.onBlur}
    error={field.meta.touched && field.meta.error}
  />
);

export const IndividualInformation = props => (
  <div>
    <div className="row">
      <div className="col-12">
        <h3>Data Pribadi Anda</h3>
      </div>
      <div className="fullname__container col-12 col-sm-6">
        <Field
          component={renderInput}
          name="fullName"
          label="Nama Lengkap"
          maxLength={MaxLength.INPUT_FULL_NAME}
          validate={nameValidation}
          type="text"
        />
      </div>
    </div>
    <div className="row">
      <div className="datetime__container col-12 col-sm-6 order-1">
        <Field
          component={renderCalendar}
          name="birthday"
          label="Tanggal Lahir"
          validate={dobValidation}
        />
      </div>
      <div className="ktp__container col-12 col-sm-6 order-2 order-md-3">
        <Field
          component={renderInput}
          name="nik"
          label="Nomor KTP"
          maxLength={MaxLength.INPUT_KTP}
          validate={nikValidation}
          type="tel"
          max="9999999999999999"
        />
      </div>
      <div className="mobile__container col-12 col-sm-6 order-3 order-md-2">
        <Field
          component={renderInput}
          name="phoneNumber"
          label="Nomor Ponsel"
          assistiveText="Contoh 08123456780"
          maxLength={MaxLength.INPUT_PHONE_NUMBER}
          validate={phoneNumberValidation}
          type="tel"
        />
      </div>
      <div className="email__container col-12 col-sm-6 order-4">
        <Field
          component={renderInput}
          name="email"
          label="Alamat Email"
          maxLength={MaxLength.INPUT_EMAIL}
          validate={emailValidation}
          type="email"
        />
      </div>
    </div>
    <div className="row">
      <div className="married-status__container col-12 col-sm-6">
        <Field className="form-group married-status" name="marriageStatus" component={renderMaritalStatus} />
      </div>
      <div className="children-number__container col-12 col-sm-6">
        <Field component={renderCounter} name="numberOfKids" className="form-group children-number" />
      </div>
    </div>
  </div>
);
