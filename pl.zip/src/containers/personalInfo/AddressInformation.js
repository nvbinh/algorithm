import React from "react";
import { Field } from "redux-form";
import { TextArea } from "../../components/views";
import {renderInput, renderSearchList} from "./renderFields";

import validation from "../../utils/validationUtils";
import { MaxLength } from "../../common/constants";

const {
  cityValidation,
  districtValidation,
  wardValidation,
  addressValidation
} = validation.customerPersonalInformation;

const renderTextArea = field => (
  <TextArea
    {...field}
    onChange={field.input.onChange}
    onBlur={field.input.onBlur}
    value={field.input.value}
    error={field.meta.touched && field.meta.error}
  />
);

export const AddressInformation = ({ isDisplay, cities }) =>
  isDisplay && (
    <div className="row">
      <div className="address__container col-12">
        <Field
          component={renderTextArea}
          style={{ paddingLeft: 0, marginBottom: 15 }}
          name="address"
          label="Alamat"
          maxLength={MaxLength.INPUT_ADDRESS}
          validate={value => addressValidation(value, MaxLength.INPUT_ADDRESS)}
          type="text"
        />
      </div>
      <div className="city__container col-12">
        <Field
          component={renderSearchList}
          dialogTitle="Pilih Kota"
          dataList={cities}
          name="city"
          hint="Pilih kota"
          format={({ value } = { value: "" }) => value}
          label="Kota"
          validate={cityValidation}
          className="form-group"
        />
      </div>

      <div className="district__container col-12 col-sm-6">
        <Field
          component={renderInput}
          name="district"
          label="Kecamatan"
          maxLength={MaxLength.INPUT_DISTRICT}
          validate={districtValidation}
          type="text"
        />
      </div>
      <div className="village__container col-12 col-sm-6">
        <Field
          component={renderInput}
          name="ward"
          label="Kelurahan"
          maxLength={MaxLength.INPUT_WARD}
          validate={wardValidation}
          type="text"
        />
      </div>
    </div>
  );
