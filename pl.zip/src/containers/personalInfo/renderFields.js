import React from "react";
import { OptionList, Input } from "../../components/views";
import { SearchList } from "../../components/views/SearchList";

export const renderOptionList = field => (
  <OptionList
    {...field}
    value={field.input.value}
    newValue={field.input.value}
    onChange={field.input.onChange}
    onBlur={field.input.onBlur}
    error={(field.meta.touched && field.meta.error) || void 0}
  />
);
export const renderInput = field => (
  <Input
    {...field}
    onChange={field.input.onChange}
    onBlur={field.input.onBlur}
    value={field.input.value}
    error={(field.meta.touched && field.meta.error) || void 0}
  />
);

export const renderSearchList = field => (
  <SearchList
    {...field}
    dataList={field.dataList}
    id={field.input.name}
    value={field.input.value}
    newValue={field.input.value}
    onChange={field.input.onChange}
    error={field.meta.touched && field.meta.error}
  />
);
