import React from "react";
import { Field } from "redux-form";
import { renderOptionList, renderInput } from "./renderFields";

import { MaxLength } from "../../common/constants";
import ValidationUtils from "../../utils/validationUtils";

const {
  emergencyContactNameValidation,
  emergencyPhoneNumberValidation,
  relationshipValidation
} = ValidationUtils.customerPersonalInformation;

export const EmergencyContact = ({ relationships }) => (
  <div className="row">
    <div className="col-12">
      <h3>Kontak Darurat</h3>
    </div>
    <div className="emergency-contact-fullname__container col-12 col-sm-6">
      <Field
        component={renderInput}
        name="emergencyFullName"
        label="Nama Lengkap"
        type="text"
        maxLength={MaxLength.INPUT_FULL_NAME}
        validate={emergencyContactNameValidation}
      />
    </div>
    <div className="emergency-contact-phone__container col-12 col-sm-6">
      <Field
        component={renderInput}
        name="emergencyPhoneNumber"
        label="Nomor Ponsel"
        type="tel"
        assistiveText="Contoh 0819878910"
        maxLength={MaxLength.INPUT_PHONE_NUMBER}
        validate={emergencyPhoneNumberValidation}
      />
    </div>
    <div className="emergency-contact-relationship__container col-12">
      <div className="form-group">
        <Field
          component={renderOptionList}
          dialogTitle="Pilih Hubungan"
          dataList={relationships}
          name="relationship"
          hint="Pilih Hubungan"
          label="Hubungan"
          format={({ value } = { value: "" }) => value}
          validate={relationshipValidation}
        />
      </div>
    </div>
  </div>
);
