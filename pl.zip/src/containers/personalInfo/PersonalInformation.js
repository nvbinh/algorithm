import React from "react";
import { reduxForm, untouch, Field, resetSection } from "redux-form";
import { connect } from "react-redux";

import NextBackGroupButton from "../../components/widget/nextBackGroupButton";
import { AddressInformation } from "./AddressInformation";
import { EmergencyContact } from "./EmergencyContact";
import { IndividualInformation } from "./IndividualInformation";

import { MarriageStatus } from "../../common/constants";
import AppPageURL from "../../common/appPageURL";
import { ReduxForm } from "../../common/constants";

import DataConvertUtils from "../../utils/dataConvertUtils";

const renderSameAddress = field => (
  <div className="same-address__container">
    <h3>Di mana tempat tinggal Anda?</h3>
    <div className="same-address">
      <label className="checkbox-inline">
        <input
          type="checkbox"
          className="checkbox"
          checked={field.input.value}
          onChange={e => field.input.onChange(e.target.checked)}
        />
        <span />
      </label>
      <p>Sama dengan Alamat pada KTP</p>
    </div>
  </div>
);

const address_info = ["address", "city", "ward", "district"];

const mapStateToProps = ({
  form: { customerPersonalInformation: { values } = { values: {} } },
  getLOVAPIResponse: lov
}) => ({
  cities: DataConvertUtils.convertLOVToListOfCity(lov.data.province),
  relationships: lov.data.emergencyRelationship || [],
  ...values
});

const mapDispatchToProps = dispatch => ({
  onCheckSameAddress: () => {
    dispatch(resetSection(ReduxForm.FORM_CUSTOMER_PERSONAL_INFORMATION, ...address_info));
    dispatch(untouch(ReduxForm.FORM_CUSTOMER_PERSONAL_INFORMATION, ...address_info));
  }
});

export const PersonalInformation = connect(
  mapStateToProps,
  mapDispatchToProps
)(
  reduxForm({
    form: ReduxForm.FORM_CUSTOMER_PERSONAL_INFORMATION,
    initialValues: {
      marriageStatus: MarriageStatus.SINGLE,
      numberOfKids: 0,
      sameAddress: false
    },
    touchOnBlur: true,
    touchOnChange: false,
    destroyOnUnmount: false
  })(({ history, handleSubmit, sameAddress, cities, relationships, onCheckSameAddress }) => (
    <form onSubmit={handleSubmit}>
      <div className="step-content" id="stepPersonalInformation">
        <div className="container">
            <IndividualInformation />
            <Field component={renderSameAddress} name="sameAddress" onChange={onCheckSameAddress} />
        </div>
        <div className="container">
          <AddressInformation isDisplay={!sameAddress} cities={cities} />
        </div>

        <div className="container">
          <EmergencyContact relationships={relationships} />
        </div>
        <div className="container">
          <NextBackGroupButton
            id="step-personal-group-button"
            className="margin-top-30"
            negativeLabel="BATALKAN PENGAJUAN"
            onNextClick={handleSubmit(data => {
              history.push(AppPageURL.CUSTOMER_INFORMATION_FINANCIAL_INFO);
            })}
            onBackClick={() => {
              history.push(AppPageURL.HOME);
            }}
          />
        </div>
      </div>
    </form>
  ))
);
