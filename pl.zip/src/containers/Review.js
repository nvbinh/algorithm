import React from "react";
import { connect } from "react-redux";
import { SubmissionDetail } from "../components/reviewInfo/SubmissionDetail";
import { PersonalData } from "../components/reviewInfo/PersonalData";
import { EmergencyContact } from "../components/reviewInfo/EmergencyContact";
import { FinanceInfo } from "../components/reviewInfo/FinanceInfo";
import { WorkInfo } from "../components/reviewInfo/WorkInfo";
import NextBackGroupButton from "../components/widget/nextBackGroupButton";
import iconPeriksa from "./../assets/images/ic-periksa.svg";
import { MarriageStatus } from "./../common/constants";
import AppPageURL from "../common/appPageURL";
import { formatCurrency, roundFloatingIssue } from "../utils/formatUtils";

const hasMonthlyInstallment = totalInstallmentPerMonth => {
  return totalInstallmentPerMonth && parseInt(totalInstallmentPerMonth, 10) > 0;
};

const Review = ({ history, submissionDetail, personalData, emergencyContact, aboutFinance, aboutWork }) => (
  <div id="mainContent">
    <div className="review">
      <div className="container">
        <div className="row review__header">
          <div className="col-12 col-md-9 review__header-container">
            <div className="review__header-container-inner">
              <div className="img-container">
                <img src={iconPeriksa} alt="Ceritakan Tentang Diri Anda" />
              </div>
              <h1>Periksa Kembali Data Anda</h1>
            </div>
          </div>
        </div>
        <div className="row review__content">
          <SubmissionDetail {...submissionDetail} />
          <PersonalData {...personalData} />
          <EmergencyContact {...emergencyContact} />
          <FinanceInfo {...aboutFinance} />
          <WorkInfo {...aboutWork} />
          <div className="col-12 col-md-9">
            <NextBackGroupButton
              className="row row-button"
              onNextClick={() => history.push(AppPageURL.TnC_PAGE)}
              onBackClick={() => history.push(AppPageURL.CUSTOMER_INFORMATION_WORKING_INFO)}
            />
          </div>
        </div>
      </div>
    </div>
  </div>
);

const getMarriageStatusString = status => {
  switch (status) {
    case MarriageStatus.SINGLE:
      return "Lajang";
    case MarriageStatus.MARRIED:
      return "Menikah";
    default:
      return "";
  }
};

const mapStateToProps = ({
  form: {
    customerPersonalInformation: {
      values: {
        fullName,
        birthday: { day, month, year },
        phoneNumber,
        nik,
        email,
        address,
        city,
        district,
        ward,
        marriageStatus,
        numberOfKids,
        emergencyPhoneNumber,
        emergencyFullName,
        relationship,
        sameAddress
      }
    },
    customerFinancialInformation: {
      values: { loanStatus, declaredIncome, totalInstallment }
    },
    customerWorkingInformation: {
      values: { companyName, occupation, jobTitle, lineOfBusinessGroup, lineOfBusiness }
    }
  },
  getConfigurationsAPIResponse: {
    configurations: { interestRate }
  },
  loanInformation: { amount, tenure, monthlyInstallmentAmount }
}) => ({
  submissionDetail: {
    loanAmount: formatCurrency(amount),
    tenor: tenure,
    monthlyInstallment: formatCurrency(monthlyInstallmentAmount),
    interestRate: roundFloatingIssue(interestRate)
  },
  personalData: {
    name: fullName,
    dob: `${day} ${month.value} ${year}`,
    nik,
    phone: phoneNumber,
    email,
    status: getMarriageStatusString(marriageStatus),
    children: numberOfKids,
    address,
    city: city && city.value,
    district,
    kelurahan: ward,
    sameAddress
  },
  emergencyContact: {
    name: emergencyFullName,
    relationship: relationship.value,
    phone: emergencyPhoneNumber
  },
  aboutFinance: {
    purpose: loanStatus.value,
    earningPerMonth: formatCurrency(declaredIncome),
    totalInstallmentPerMonth: hasMonthlyInstallment(totalInstallment) && formatCurrency(totalInstallment)
  },
  aboutWork: {
    companyName,
    work: occupation.value,
    department: jobTitle && jobTitle.value,
    industry: lineOfBusinessGroup && lineOfBusinessGroup.value,
    business: lineOfBusiness && lineOfBusiness.value
  }
});

export const ReviewContainer = connect(mapStateToProps)(Review);
