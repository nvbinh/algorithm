import React from "react";
import { connect } from "react-redux";
import { Approval as PureApproval } from "../components";

import { formatCurrency, formatLoanExpireDate, roundFloatingIssue } from "../utils/formatUtils";
import { calculateLoanExpireDate } from "../utils/decisionUtils";

const mapStateToProps = ({
  getConfigurationsAPIResponse: { configurations },
  decisionStatus: {
    loanInfo: { detail = {} }
  }
}) => {
  const {
    approvedAmount,
    approvedTenure,
    approvedInstallmentAmount,
    approvedInterest
  } = detail.approvedLoanInformation;
  const expireDate = calculateLoanExpireDate(
    detail.decisionDate,
    configurations.validityPeriod
  );

  return {
    totalLoan: formatCurrency(approvedAmount),
    tenor: approvedTenure,
    monthlyInstallment: formatCurrency(approvedInstallmentAmount),
    interestRate: (roundFloatingIssue(approvedInterest)).toString().replace(/\./g, ","),
    expireDate: formatLoanExpireDate(expireDate),
    requireSalaryValidation:
      detail.additionalInformation.requireSalaryValidation,
    kioskLocationUrl: configurations.kioskLocationUrl
  };
};

export const Approval = connect(mapStateToProps)(props => (
  <PureApproval {...props} />
));
