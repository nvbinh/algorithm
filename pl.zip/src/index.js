import "babel-polyfill";

import React from "react";
import { render } from "react-dom";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";

import "./rxjs.config";
import Root from "./components/app/root.component";
import { ScrollToTopRouter } from "./components/views";
import { store } from "./store";
import "./assets/styles.css";
import "./assets/react-custom-style.css";

render(
  <Provider store={store}>
    <BrowserRouter>
      <ScrollToTopRouter>
        <Root />
      </ScrollToTopRouter>
    </BrowserRouter>
  </Provider>,
  document.getElementById("root")
);
