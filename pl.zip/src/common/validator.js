import {formatCurrency} from './../utils/formatUtils'
import StringUtils from './../utils/stringUtils'

export const required = errorMessage => value =>
  !StringUtils.isEmpty(value) ? undefined : errorMessage

export const minRequired = minValue => errorMessage => value =>
  value >= minValue ? undefined : `${errorMessage} Rp${formatCurrency(minValue)}`;

export const checkCompanyNameValid = errorMessage => ({ minLength, alphabetMinLength }) => value => {
  const regrexString = new RegExp(`(^[A-Za-z]+([A-Za-z0-9 \\x2e\\x2d\\x2c\\x2f\\x28\\x29\\x26\\x5b\\x5d]){${minLength},})+$`);
  return value && regrexString.test(value) && value.match(/[A-Za-z]/g).length >= alphabetMinLength ? void 0 : errorMessage;
};

export const isCompanyNameExisted = errorMessage => suggestions => query =>
   suggestions
    .filter(({value}) => value.toLowerCase().includes(query.trim().toLowerCase()))
    .length > 0
      ? undefined
      : errorMessage
