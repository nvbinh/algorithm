const EnvironmentVariables = {
  SVC_BASE_URL: process.env.REACT_APP_SVC_BASE_URL
}

export default EnvironmentVariables