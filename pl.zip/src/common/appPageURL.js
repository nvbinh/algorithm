export default class AppPageURL {
  static get HOME () {
    return '/'
  }

  static get FAQ () {
    return '/faq'
  }

  static get CONTACT_US () {
    return '/contactUs'
  }

  static get CUSTOMER_INFORMATION () {
    return '/customerInformation'
  }

  static get CUSTOMER_INFORMATION_PERSONAL_INFO () {
    return '/customer/personal-information'
  }

  static get CUSTOMER_INFORMATION_WORKING_INFO () {
    return '/customer/working-information'
  }

  static get CUSTOMER_INFORMATION_FINANCIAL_INFO () {
    return '/customer/financial-information'
  }

  static get CUSTOMER_INFORMATION_REVIEW () {
    return '/customer/information-review'
  }

  static get INTERNAL_SERVER_ERROR () {
    return '/internalServerError'
  }

  static get PAGE_NOT_FOUND () {
    return '/pageNotFound'
  }

  static get UNAUTHORIZED () {
    return '/unauthorized'
  }

  static get FORBIDDEN () {
    return '/forbidden'
  }

  static get LOADING_PAGE () {
    return '/loading'
  }

  static get LOAN_APPROVAL_PAGE () {
    return '/approval'
  }

  static get REJECTED_PAGE () {
    return '/rejected'
  }

  static get NOT_ELIGIBLE_DEDUP_PAGE () {
    return '/notEligible'
  }

  static get PENDING_PAGE () {
    return '/pending'
  }

  static get THANKYOU_PAGE () {
    return '/thankyou'
  }

  static get AUTOMATION_SUPPORTING () {
    return '/auto'
  }

  static get ERROR_PAGE () {
    return '/oops'
  }

  static get OTP_PAGE () {
    return '/otp'
  }

  static get OTP_ERROR_PAGE () {
    return '/otpError'
  }

  static get OTP_EXCEPTION_PAGE () {
    return '/otpException'
  }

  static get TnC_PAGE () {
    return '/termAndCondition'
  }

  static get DUPLICATION_REJECTED_PAGE () {
    return '/duplication'
  }
}
