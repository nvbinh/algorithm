import AppPageURL from "./appPageURL";

export const HttpMethod = {
  GET: 'GET',
  POST: 'POST',
  PUT: 'PUT',
  DELETE: 'DELETE'
}

export const ContentType = {
  FORM_URL_ENCODED: 'application/x-www-form-urlencoded',
  JSON_TEXT: 'application/json'
}

export const RequestHeader = {
  CONTENT_TYPE: 'Content-Type',
  AUTHORIZATION: 'Authorization'
}

export const AuthenticationFlow = {
  CLIENT_CREDENTIALS: 'client_credentials',
  PASSWORD: 'password'
}

export const ReduxForm = {
  FORM_CUSTOMER_WORKING_INFORMATION: 'customerWorkingInformation',
  FORM_CUSTOMER_PERSONAL_INFORMATION: 'customerPersonalInformation',
  FORM_CUSTOMER_FINANCIAL_INFORMATION: 'customerFinancialInformation',
  REVIEW_CUSTOMER_INFORMAION: {
    name: 'review customer information form',
    items: {
      isTnCAgree: 'isTnCAgree'
    }
  }
}

export const Defines = {
  MIN_MONTHLY_INCOME_IN_RUPIAH: 5000000,
  MIN_AGE_LOAN_CUSTOMER: 21,
  MAX_AGE_LOAN_CUSTOMER: 55,
  MIN_YEAR_LOAN_CUSTOMER: 1900,
  LOAN_AMOUNT_MAX_LENGTH: 15,
  CURRENCY_FORMAT: /\./g
}

export const MarriageStatus = {
  SINGLE: 'single',
  MARRIED: 'married',
  SINGLE_PARENT: 'single_parent'
}

export const defaultConfig = {
  interestRate: 0.0167,
  minAmount: 10000000,
  maxAmount: 30000000,
  stepAmount: 1000000,
  minTenure: 12,
  maxTenure: 18,
  timeCaching: 3600000,
  timeCarousel: 5,
  penaltyFee: 0.06,
  minIncome: 3500000,
  minAge: 21,
  desisionStatusInterval: 10,
  desisionStatusMaxInterval: 120,
  validityPeriod: 7,
  limitedRecordSearchingCompany: 10,
  otpTemplate: 'otp_template.sms.verification',
  companySearchFreeText: true,
  debtBurdenRatio: 0.4
}

export const DecisionStatus = {
  RUNNING: 'RUNNING',
  COMPLETED: 'COMPLETED',
  FAILED: 'FAILED',
  TIME_OUT: 'TIME_OUT'
}

export const DecisionCompletedLoanStatus = {
  APPROVED: 'IN_PRINCIPLE_APPROVED',
  REJECTED: 'IN_PRINCIPLE_REJECTED',
  SUBMITTED: 'SUBMITTED'
}

export const DecisionRejectedReasonCode = {
  DEDUPCHECK: 'DD00500',
  QUOTALIMIT: 'QT00500',
  DUPLICATION: 'DA00500'
}

export const KeyCode = {
  BACKSPACE: 8,
  DELETE: 46
}

export const MaxLength = {
  INPUT_DECLARED_INCOME: 9,
  INPUT_TOTAL_INSTALLMENT: 9,
  INPUT_ADDRESS: 255,
  INPUT_COMPANY_NAME: 100,
  INPUT_DISTRICT: 50,
  INPUT_WARD: 50,
  INPUT_PHONE_NUMBER: 15,
  INPUT_KTP: 16,
  INPUT_FULL_NAME: 100,
  INPUT_EMAIL: 100
}

export const Otp = {
  MAX_RESEND: 3,
  MAX_ATTEMPT: 3,
  DURATION_COUNTDOWN: 30,
  ERR_TYPE_OTP_INVALID: 1,
  ERR_TYPE_OTP_EXPIRED: 2,
  PIN_LENGTH: 6
}

export const OtpAction = {
  GET: 'GET',
  VALIDATION: 'VALIDATION'
}

export const OtpStatus = {
  EXPIRED: 'expired',
  INVALID: 'invalid',
  BLOCK: 'block',
  EXCEPTION: 'exception',
  NOT_EXIST: 'not_exist',
  UNDEFINED: 'undefined',
  MAX_ATTEMPT: 'max_attempt'
}

export const ErrorStatus = {
  NETWORK: 'network_error'
}

export const LoanSimulation = {
  DEPENDS_AMOUNT: 1500000,
  MAX_ELIGIBLE_LOAN_AMOUNT: 30000000,
  PERCENTAGE_SINGLE: 0.1,
  PERCENTAGE_MARRIED: 0.1
}

export const PageNameTracking = {
  LANDING: 'landing_page',
  FINANCIAL: 'financial_information_page',
  PERSONAL: 'personal_information_page',
  WORKING: 'working_information_page',
  REVIEW: 'information_review_page',
  OTP: 'otp_page',
  TNC: 'term_and_condition'
}

export const AppConfig = {
  API_TIMEOUT: 1000 * 60 * 3
}

export const PLStatus = {
  PROCCESSING: 'processing',
  SUCCESS: 'success',
  FAILED: 'failed'
}

export const PL_KEY = {
  UTM_CAMPAIN_SESSION_STORAGE: 'UTM_CAMPAIN_SESSION_STORAGE'
}

export const PL_KEY_SOURCE = 'utm_source'

export const PL_SOURCE = {
  TS : 'TS',
  EC : 'EC',
  AC : 'AC'
}

export const CompanyNameLengthValidator = {
  MIN_LENGTH: 5,
  ALPHABET_MIN_LENGTH: 3
}

export const FacebookTrackingEvent = {
  SUBMIT_APPLICATION: 'SubmitApplication'
}

export const WIDTH_MOBILE = 769;

export const ScreenName = {
    HOME: 'Home Page',
    FINANCIAL_INFO: 'Financial Info',
    PERSONAL_INFO: 'Personal Info',
    WORKING_INFO: 'Working Info',
    REVIEW_PAGE: 'Review Page',
    T_C: 'T & C',
    OTP: 'Otp',
    REJECTED: 'Rejected',
    APPROVAL: 'Approval',
    NOT_ELIGIBLE: 'Not Eligible',
    PENDING: 'Pending',
    DUPLICATION: 'Duplication',
    OTP_ERROR: 'Otp Error',
    OTP_EXCEPTION: 'Otp Exception',
    LOADING: 'Loading',
    ERROR_PAGE: 'Error Page',
    INTERNAL_SERVER_ERROR: 'Page 500',
    UNAUTHORIZED: 'Page 401',
    FORBIDDEN: 'Page 403',
    PAGE_NOT_FOUND: 'Page 404'
}

export const mapTrackedPageToScreenName = page => {
    switch (page) {
        case AppPageURL.HOME:
            return ScreenName.HOME
        case AppPageURL.CUSTOMER_INFORMATION_FINANCIAL_INFO:
            return ScreenName.FINANCIAL_INFO
        case AppPageURL.CUSTOMER_INFORMATION_PERSONAL_INFO:
            return ScreenName.PERSONAL_INFO
        case AppPageURL.CUSTOMER_INFORMATION_WORKING_INFO:
            return ScreenName.WORKING_INFO
        case AppPageURL.CUSTOMER_INFORMATION_REVIEW:
            return ScreenName.REVIEW_PAGE
        case AppPageURL.OTP_PAGE:
            return ScreenName.OTP
        case AppPageURL.REJECTED_PAGE:
            return ScreenName.REJECTED
        case AppPageURL.LOAN_APPROVAL_PAGE:
            return ScreenName.APPROVAL
        case AppPageURL.NOT_ELIGIBLE_DEDUP_PAGE:
            return ScreenName.NOT_ELIGIBLE
        case AppPageURL.PENDING_PAGE:
            return ScreenName.PENDING
        case AppPageURL.DUPLICATION_REJECTED_PAGE:
            return ScreenName.DUPLICATION
        case AppPageURL.OTP_ERROR_PAGE:
            return ScreenName.OTP_ERROR
        case AppPageURL.OTP_EXCEPTION_PAGE:
            return ScreenName.OTP_EXCEPTION
        case AppPageURL.LOADING_PAGE:
            return ScreenName.LOADING
        case AppPageURL.ERROR_PAGE:
            return ScreenName.ERROR_PAGE
        case AppPageURL.INTERNAL_SERVER_ERROR:
            return ScreenName.INTERNAL_SERVER_ERROR
        case AppPageURL.UNAUTHORIZED:
            return ScreenName.UNAUTHORIZED
        case AppPageURL.FORBIDDEN:
            return ScreenName.FORBIDDEN
        case AppPageURL.PAGE_NOT_FOUND:
            return ScreenName.PAGE_NOT_FOUND
        case AppPageURL.TnC_PAGE:
            return ScreenName.T_C
        default:
            return page
    }
}

