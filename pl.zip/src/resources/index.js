import img_art_human from "../assets/images/art-human.svg";
import img_art_hand from "../assets/images/art_hand.svg";
import img_art_people from "../assets/images/art-people.svg";
import img_art_ektp from "../assets/images/art-e-ktp.svg";
import img_art_income from "../assets/images/art-income.svg";
import img_logo from "../assets/images/logo.svg";

import ic_facebook from "../assets/images/facebook.png";
import ic_twitter from "../assets/images/twitter.png";
import ic_instagram from "../assets/images/ic-instagram.png";
import ic_call_centre from "../assets/images/ic-call-centre.png";
import ic_path_11_copy from "../assets/images/path-11-copy.png";
import ic_3p from "../assets/images/ic-3-p.png";
import ic_lps from "../assets/images/ic-lps.png";
import ic_ayo from "../assets/images/ic-ayo.png";
import ic_ik from "../assets/images/ic-ik.png";
import ic_tick_mark from "../assets/images/icon-tick-mark.svg";
import ic_dropdown from "../assets/images/icon-dropdown.svg";
import ic_done from "../assets/images/icon-done.svg";
import ic_biaya from "../assets/images/ic-biaya-copy.svg";
import ic_checked from "../assets/images/icon-checked.svg";
import ic_checked_yellow from "../assets/images/icon-checked-yellow.svg";
import ic_instan from "../assets/images/ic-instan.svg";
import ic_easy from "../assets/images/ic-easy.svg";
import ic_free from "../assets/images/ic-free.svg";
import ic_syarat from "../assets/images/icon-syarat.svg";
import imgArtHappyguy from "../assets/images/art-happyguy.svg";
import icCalendar from "../assets/images/ic-calendar.svg";
import icAtmCard from "../assets/images/ic-atm-card.svg";
import icMap from "../assets/images/icon-map.svg";
import icSorry from "../assets/images/icon-sorry.svg";
import icAttention from "../assets/images/icon-attention.svg";
import icOops from "../assets/images/icon-oops.png";
import icEmail from "../assets/images/icon-email.svg";
import icCallCenter from '../assets/images/icon-callcenter.svg'
import icSubmit from "../assets/images/icon-submit.svg";
import icLoading from "../assets/images/icon-loading.gif";
import ic_close from "../assets/images/ic-close.svg";
import icon_search from "../assets/images/icon-search.svg";

export {
  img_art_human,
  img_art_hand,
  img_art_people,
  img_art_ektp,
  img_art_income,
  img_logo,
  imgArtHappyguy,
  ic_facebook,
  ic_twitter,
  ic_instagram,
  ic_call_centre,
  ic_path_11_copy,
  ic_3p,
  ic_lps,
  ic_ayo,
  ic_ik,
  ic_tick_mark,
  ic_dropdown,
  ic_done,
  ic_biaya,
  ic_checked,
  ic_checked_yellow,
  ic_instan,
  ic_easy,
  ic_free,
  ic_syarat,
  icCalendar,
  icAtmCard,
  icMap,
  icSorry,
  icAttention,
  icOops,
  icEmail,
  icCallCenter,
  icSubmit,
  icLoading,
  ic_close,
  icon_search
};
