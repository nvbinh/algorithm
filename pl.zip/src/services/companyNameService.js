import BaseService from './base.service'

export default class CompanyNameService extends BaseService {
  getCompanyName (queryName, limitedRecord) {
    const authHeader = this.createBearerAuthRequestHeaders()
    return this.httpClient
      .get(this.serviceEndpoint.getCompanyNameEndpoint(encodeURIComponent(queryName), limitedRecord), authHeader)
      .catch(error => this.handleHttpError(error))
  }
}
