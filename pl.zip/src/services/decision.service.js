import AppService from './app.service'

class DecisionService extends AppService {
  getDecisionStatus (accessToken, jobId) {
    let authHeader = this.createBearerAuthRequestHeaders()
    let header = {
      ...authHeader,
      Authorization: `Bearer ${accessToken}`
    }

    return this.httpClient
      .get(this.serviceEndpoint.getDecisionStatusEndpoint(jobId), header)
      .catch(error => this.handleHttpError(error))
  }
}

export default DecisionService