import BaseService from './base.service'

/**
 * Web services for things relevant to app common
 */
class ConfigurationsService extends BaseService {

  createBearerAuthRequestHeaders () {
    return super.createBearerAuthRequestHeaders(process.env.REACT_APP_ACCESS_TOKEN)
  }

  /**
   * get Loan Config
   */
  getConfigurations () {
    const authHeader = this.createBearerAuthRequestHeaders()

    return this.httpClient
      .get(this.serviceEndpoint.getLoanConfigurationEndpoint, authHeader)
      .catch(error => this.handleHttpError(error))
  }
}

export default ConfigurationsService
