import BaseService from './base.service'

export default class TrackingService extends BaseService {

    getTrackingId(utmParamValue) {
        const authHeader = this.createBearerAuthRequestHeaders();
        return this.httpClient
                    .get(this.serviceEndpoint.getTrackingId(utmParamValue), authHeader)
                    .catch(error => this.handleHttpError(error))
    }

}
