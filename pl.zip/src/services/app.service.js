import BaseService from './base.service'

/**
 * Web services for things relevant to app common
 */
class AppService extends BaseService {
  getLOV () {
    const authHeader = this.createBearerAuthRequestHeaders()

    return this.httpClient
      .get(this.serviceEndpoint.getLOVEndpoint, authHeader)
      .catch(error => this.handleHttpError(error))
  }

  getLOVMapping () {
    const authHeader = this.createBearerAuthRequestHeaders()

    return this.httpClient
      .get(this.serviceEndpoint.getLOVMappingEndpoint(), authHeader)
      .catch(error => this.handleHttpError(error))
  }

  logDurationTime ({auth: {customerId, accessToken}, durationTimeRequest}) {
    const authHeader = this.createBearerAuthRequestHeaders(accessToken)

    return this.httpClient
      .putAsJson(
        this.serviceEndpoint.getScreenDurationTime(customerId),
        authHeader,
        durationTimeRequest
      )
  }

  logCampaignAnalytic ({
    auth: {accessToken},
    analyticRequest: {customerId, data}
  }) {
    const authHeader = this.createBearerAuthRequestHeaders(accessToken)

    return this.httpClient
      .postAsJson(
        this.serviceEndpoint.getAnalytics(),
        authHeader,
        {
          customerId,
          data
        }
      )
  }
}

export default AppService
