import EnvironmentVariables from "./../common/environmentVariables";

export const Endpoint = {
  BASE_PATH: "api/personalloan",

  INIT_CUSTOMER_SESSION: "session/init",
  PRODUCT_INFO: "info",
  GET_LOV: "settings/lovs",
  GET_LOV_MAPPING: "settings/defaultvalues",
  CREATE_CUSTOMER: "customers/createinformation",
  LOAN_CONFIGURATION: "settings/configurations",
  GET_DECISION_STATUS: "decision/jobs",
  REVOKE_CUSTOMER_SESSION: "session/finalize",
  VALIDATE_OTP: "decision/jobs/execute",
  SCREEN_DURATION: "screenduration",
  ANALYTIC: "analytic",
  OTP_GENERATE: "decision/otp",
  GET_TRACKING_ID: "settings/trackingids"
};
export const GeneralEndpoint = {
  SEARCHING_COMPANY_NAME: "search/company"
};

/**
 * A wrapper of all configuration relevant to web service such as environment, authentication & service endpoint
 */
export default class ServiceEndpoint {
  generalDomain = EnvironmentVariables.SVC_BASE_URL
    ? `${EnvironmentVariables.SVC_BASE_URL}/api`
    : "/api";

  getFullServiceEndpoint(endpoint) {
    if (EnvironmentVariables.SVC_BASE_URL) {
      return `${EnvironmentVariables.SVC_BASE_URL}/${
        Endpoint.BASE_PATH
      }/${endpoint}`;
    } else {
      return `/${Endpoint.BASE_PATH}/${endpoint}`;
    }
  }

  /**
   * API endpoint to init customer session
   */
  get initCustomerSessionEndpoint() {
    return this.getFullServiceEndpoint(Endpoint.INIT_CUSTOMER_SESSION);
  }

  /**
   * API endpoint to get product info
   */
  get productInfoEndpoint() {
    return this.getFullServiceEndpoint(Endpoint.PRODUCT_INFO);
  }

  get createCustomer() {
    return this.getFullServiceEndpoint(Endpoint.CREATE_CUSTOMER);
  }

  /**
   * API endpoint to get LOVs
   */
  get getLOVEndpoint() {
    return this.getFullServiceEndpoint(Endpoint.GET_LOV);
  }

  /**
   * API endpoint to get LOV mapping
   * @returns {*}
   */
  getLOVMappingEndpoint() {
    return this.getFullServiceEndpoint(Endpoint.GET_LOV_MAPPING);
  }

  /**
   * API endpoint to get LOVs
   */
  get getLoanConfigurationEndpoint() {
    return this.getFullServiceEndpoint(Endpoint.LOAN_CONFIGURATION);
  }

  /**
   * API endpoint to retrieve the Iteration Decision Status
   */
  getDecisionStatusEndpoint(jobId) {
    let endpoint = `${Endpoint.GET_DECISION_STATUS}/${jobId}`;
    return this.getFullServiceEndpoint(endpoint);
  }

  get revokeCustomerSession() {
    return this.getFullServiceEndpoint(Endpoint.REVOKE_CUSTOMER_SESSION);
  }

  getCompanyNameEndpoint(queryName, limitedRecord) {
    return `${this.generalDomain}/${
      GeneralEndpoint.SEARCHING_COMPANY_NAME
    }?name=${queryName}&limit=${limitedRecord}`;
  }

  getGenerateOtp(customerId) {
    return this.getFullServiceEndpoint(
      `${Endpoint.OTP_GENERATE}/${customerId}`
    );
  }

  get validateOtp() {
    return this.getFullServiceEndpoint(Endpoint.VALIDATE_OTP);
  }

  getScreenDurationTime(customerId) {
    return this.getFullServiceEndpoint(
      `${Endpoint.SCREEN_DURATION}/${customerId}`
    );
  }

  getAnalytics(customerId) {
    return this.getFullServiceEndpoint(Endpoint.ANALYTIC);
  }

  getTrackingId(paramName) {
      return this.getFullServiceEndpoint(
          `${Endpoint.GET_TRACKING_ID}/${paramName}`
      );
  }

}
