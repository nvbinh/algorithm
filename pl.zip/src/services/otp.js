import BaseService from './base.service'
import { AppConfig } from '../common/constants'

export default class OtpService extends BaseService {
  generateOtp (customerId,
               {accessToken, applicationNumber, phoneNumber, otpTemplate, channel}) {
    const requestBody = {
      'phoneNumber': phoneNumber,
      'onboardingNumber': applicationNumber,
      'customerSessionId': accessToken,
      'template': otpTemplate,
      'channel': channel
    }

    const authHeader = this.createBearerAuthRequestHeaders(accessToken)

    return this.httpClient
      .postAsJson(this.serviceEndpoint.getGenerateOtp(customerId), authHeader, requestBody)
      .catch(this.handleHttpError)
      .timeout(AppConfig.API_TIMEOUT)
  }

  validateOtp ({accessToken, customerId, otpCode, channel, sourceChannel}) {
    const requestBody = {
      customerId,
      otpValue: otpCode,
      channel,
      sourceChannel
    }
    const authHeader = this.createBearerAuthRequestHeaders(accessToken)
    const header = {...authHeader}

    return this.httpClient
      .postAsJson(this.serviceEndpoint.validateOtp, header, requestBody)
      .catch(this.handleHttpError)
      .timeout(AppConfig.API_TIMEOUT)
  }
}
