import BaseService from './base.service'

/**
 * Web services for things relevant to app common
 */
class SessionService extends BaseService {
  /**
   * revoke custom session
   */
  revokeCustomerSession (sessionInfo) {
    const authHeader = this.createBearerAuthRequestHeaders(sessionInfo.sessionKey)
    return this.httpClient
      .postAsJson(this.serviceEndpoint.revokeCustomerSession, authHeader, sessionInfo)
  }
}

export default SessionService
