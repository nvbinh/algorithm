// setup file
import { configure } from 'enzyme'
import Adapter from 'enzyme-adapter-react-15'

configure({ adapter: new Adapter() })

const sessionStorageMock = {
  storage: {},
  getItem: function (k) {
    return this.storage[k]
  },
  setItem: function (k, v) {
    this.storage[k] = v
  },
  clear: function () {
    this.storage = {}
  }
}
global.sessionStorage = sessionStorageMock
