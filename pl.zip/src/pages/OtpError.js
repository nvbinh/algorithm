import React from "react";
import { withRouter } from "react-router-dom";
import { OtpError as PureOtpError } from "../components";

export const OtpError = withRouter(props => <PureOtpError {...props} />);
