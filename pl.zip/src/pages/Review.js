import React from "react";
import { withRouter } from "react-router-dom";
import {ReviewContainer} from "../containers/Review";

export const Review = withRouter(props => (<ReviewContainer {...props} />));
