import React from "react";
import { withRouter } from "react-router-dom";
import { WayFinder } from "../components/views";
import { WorkingInformationContainer } from "../containers";

export const WorkingInformation = withRouter(props => (
  <div className="bg-rectangle" id="mainContent">
    <div className="customerInformation">
      <WayFinder step="3" />
      <WorkingInformationContainer {...props} />
    </div>
  </div>
));
