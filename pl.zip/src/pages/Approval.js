import React from "react";
import { withRouter } from "react-router-dom";
import { Approval as ApprovalContainer } from "../containers";

export const Approval = withRouter(props => <ApprovalContainer {...props} />);
