import React from "react";
import { withRouter } from "react-router-dom";
import { TermAndCondition as TermAndConditionContainer } from "../containers";

export const TermAndCondition = withRouter(props => (
  <div id="mainContent">
    <div className="customerInformation">
      <TermAndConditionContainer {...props} />
    </div>
  </div>
));
