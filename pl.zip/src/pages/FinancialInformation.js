import React from "react";
import { withRouter } from "react-router-dom";
import { WayFinder } from "../components/views";
import { FinancialInformation as FinancialInformationContainer } from "../containers";

export const FinancialInformation = withRouter((props) => (
  <div className="bg-rectangle" id="mainContent">
    <div className="customerInformation">
      <WayFinder step="2" />
      <FinancialInformationContainer {...props}/>
    </div>
  </div>
));
