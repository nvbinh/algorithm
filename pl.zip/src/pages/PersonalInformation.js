import React from "react";
import { withRouter } from "react-router-dom";
import { PersonalInformation as PersonalInformationContainer } from "../containers";
import { WayFinder } from "../components/views";

export const PersonalInformation = withRouter(props => (
  <div className="bg-rectangle">
    <WayFinder step="1" />
    <PersonalInformationContainer {...props} />
  </div>
));
