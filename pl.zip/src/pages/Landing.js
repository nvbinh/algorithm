import React from "react";
import { withRouter } from "react-router-dom";
import { Landing as LandingContainer } from "../containers";

export const Landing = withRouter(props => <LandingContainer {...props} />);
