import React from "react";
import { withRouter } from "react-router-dom";
import { OtpException as PureOtpException } from "../components";

export const OtpException = withRouter(props => <PureOtpException {...props} />);
