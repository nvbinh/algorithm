import '../../utils/arrayUtils'

describe('test groupBy method', () => {
  it("test groupBy (e=>e.key) input array {k,v} output array{k : [{k,v}]} ", () => {
    const array = [{key: 'k1', value: 'v1'}, {key: 'k2', value: 'v2'}, {key: 'k1', value: 'v11'}]
    const mappedArray = [{key: 'k1', values: [{key: 'k1', value: 'v1'}, {key: 'k1', value: 'v11'}]}, {
      key: 'k2',
      values: [{key: 'k2', value: 'v2'}]
    }]
    // Assert
    expect(array.groupBy(e => e.key)).toEqual(mappedArray)
  })
})

describe('test flatMap method', () => {
  it("test flatMap(e=>e) input array int output same array", () => {
    const array = [1, 2, 3, 4, 5, 6, 1]
    // Assert
    expect(array.flatMap(e => e)).toEqual(array)
  })
})
