import { getSourceChannel } from '../../utils/sourceChannelUtils'

describe('get source channel from input', () => {
  it("input '  T S ' - output 'TS'", () => {
    expect(getSourceChannel({source: '  T S '})).toEqual('TS')
  })
  it("input '  E C ' - output 'EC'", () => {
    expect(getSourceChannel({source: '  E C '})).toEqual('EC')
  })
  it("input '  A C ' - output 'AC'", () => {
    expect(getSourceChannel({source: '  A C '})).toEqual('AC')
  })
  it("input undefined - output 'AC'", () => {
    expect(getSourceChannel({source: undefined})).toEqual('AC')
  })
  it("input 'sada' - output 'AC'", () => {
    expect(getSourceChannel({source: 'sada'})).toEqual('AC')
  })
})
