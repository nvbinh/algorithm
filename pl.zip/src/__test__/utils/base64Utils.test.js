import '../../utils/base64Utils'
import Base64 from '../../utils/base64Utils'

describe('test base 64 ', () => {
  it("encode simple", () => {
    expect('QUJD').toEqual(Base64.encode('ABC'))
  })
  it("decode simple", () => {
    expect(Base64.decode('QUJD')).toEqual('ABC')
  })
  it("encode special character", () => {
    expect('5bCP6aO85by+').toEqual(Base64.encode('小飼弾'))
  })
  it("decode special character", () => {
    expect('小飼弾').toEqual(Base64.decode('5bCP6aO85by+'))
  })

  it("encode special character 1", () => {
    expect('euWwj+mjvOW8vsKh').toEqual(Base64.encode('z小飼弾¡'))
  })

  it("decode special character 1 ", () => {
    expect('À').toEqual(Base64.decode('w4A='))
  })

  it("decode special character 2", () => {
    expect('>>>???>>>???=/+').toEqual(Base64.decode('Pj4+Pz8/Pj4+Pz8/PS8r'))
  })

})

