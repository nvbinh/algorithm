import DataConvertUtils from "../../utils/dataConvertUtils";
import CustomerService from "../../services/customer.service";
import Rx from "rxjs/Rx";
import "../../utils/arrayUtils";

describe("convertLOVToListOfCity", () => {
  it("test input lov output array {key: town.code, value: town.name}", () => {
    const province = [
      {
        town: [
          {
            name: "town1",
            code: "t1"
          },
          {
            name: "town2",
            code: "t2"
          },
          {
            name: "town3",
            code: "t3"
          }
        ]
      }
    ];
    const output = [{ key: "t1", value: "Town1" }, { key: "t2", value: "Town2" }, { key: "t3", value: "Town3" }];
    expect(DataConvertUtils.convertLOVToListOfCity(province)).toEqual(output);
  });
  it("test input {} output null", () => {
    const province = [];
    const output = [];
    expect(DataConvertUtils.convertLOVToListOfCity(province)).toEqual(output);
  });
});

describe("convertLOVToListOfEmergencyContactRelationship", () => {
  it("test input lov output array {key : relationship.code, value : relationship.name}", () => {
    const input = {
      relationship: [
        {
          name: "p1",
          code: "p1"
        },
        {
          name: "p2",
          code: "p2"
        },
        {
          name: "p3",
          code: "p3"
        }
      ]
    };
    const output = [{ key: "p1", value: "p1" }, { key: "p2", value: "p2" }, { key: "p3", value: "p3" }];
    expect(DataConvertUtils.convertLOVToListOfEmergencyContactRelationship(input)).toEqual(output);
  });

  it("test input {} output []", () => {
    const input = {};
    const output = [];
    expect(DataConvertUtils.convertLOVToListOfEmergencyContactRelationship(input)).toEqual(output);
  });
});
