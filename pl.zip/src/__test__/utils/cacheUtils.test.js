import CacheUtils from '../../utils/cacheUtils'
import { defaultConfig } from '../../common/constants'
import '../setupTests'

const cachedConfigurationsData = {
  'data': {
    'configurations': [
      {
        'key': 'apim.personalloan.web.validityperiod',
        'value': '3600'
      },
      {
        'key': 'apim.personalloan.kiosk.validityperiod',
        'value': '3600'
      },
      {
        'key': 'personalloan.application.validityperiod',
        'value': '7'
      },
      {
        'key': 'personalloan.contract.penalty',
        'value': '6%'
      },
      {
        'key': 'personalloan.contract.template',
        'value': 'template.html.loan_contract'
      },
      {
        'key': 'usb.camera.payslip.width',
        'value': '1600'
      },
      {
        'key': 'usb.camera.payslip.height',
        'value': '1200'
      },
      {
        'key': 'personalloan.income.amount.difference',
        'value': '500000'
      },
      {
        'key': 'personalloan.income.month.difference',
        'value': '2'
      },
      {
        'key': 'personalloan.time.caching',
        'value': '3000'
      },
      {
        'key': 'personalloan.client.recaptcha.google',
        'value': '6LfljzQUAAAAALQNhxS0pJFGN2yzNwDs6XeqyNjf'
      },
      {
        'key': 'personalloan.interest_month',
        'value': '1.67'
      },
      {
        'key': 'personalloan.min_amount',
        'value': '10000000'
      },
      {
        'key': 'personalloan.max_amount',
        'value': '30000000'
      },
      {
        'key': 'personalloan.step_amount',
        'value': '1000000'
      },
      {
        'key': 'personalloan.min_tenure',
        'value': '12'
      },
      {
        'key': 'personalloan.max_tenure',
        'value': '18'
      },
      {
        'key': 'personalloan.loansubmission.daysfrozenafterapproving',
        'value': '7'
      },
      {
        'key': 'personalloan.loansubmission.daysfrozenafterrejecting',
        'value': '90'
      }
    ]
  },
  'lastFetched': 1508760201559
}

describe('CacheUtils tests for functions', () => {
  it('testing getCachedTimeout: return default defaultConfig.timeCaching when no cachedData is available', () => {
    // Arrange
    let cachedData

    // Act
    let expected = defaultConfig.timeCaching

    // Assert
    expect(CacheUtils.getCachedTimeout(cachedData)).toEqual(expected)
  })

  it('testing getCachedTimeout: return actual timeout from cache when cachedData is available', () => {
    // Arrange
    let cachedData = cachedConfigurationsData

    // Act
    let expected = 3600000

    // Assert
    expect(CacheUtils.getCachedTimeout(cachedData)).toEqual(expected)
  })

  it('testing isCachedDataStale: return true if lastFetched is undefined', () => {
    // Arrange
    let lastFetched

    // Act
    let expected = true

    // Assert
    expect(CacheUtils.isCachedDataStale(lastFetched)).toEqual(expected)
  })

  it('testing save and read cache: return {} if data is undefined', () => {
    // Arrange
    sessionStorage.setItem("key", undefined)
    // Assert
    expect(CacheUtils.loadCachedData('key')).toEqual({})
    sessionStorage.clear()
  })

  it('testing isCachedDataStale: return true if lastFetched is NOT undefined, but less than 1 hour', () => {
    // Arrange
    let lastFetched = Date.now() - (59 * 60 * 1000)

    // Act
    let expected = false

    // Assert
    expect(CacheUtils.isCachedDataStale(lastFetched)).toEqual(expected)
  })

  it('testing isCachedDataStale: return true if lastFetched is NOT undefined, but more than 1 hour', () => {
    // Arrange
    let lastFetched = Date.now() - (2 * 60 * 60 * 1000)

    // Act
    let expected = true

    // Assert
    expect(CacheUtils.isCachedDataStale(lastFetched)).toEqual(expected)
  })

})
