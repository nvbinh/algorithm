import {
  calculateCreditLimit, calculateEligibleLoanAmount, calculateEligibleMonthlyInstallment, calculateMonthlyIncome,
  calculateProxyExpense
} from '../../utils/loanFormulaUtils'
import { MarriageStatus } from '../../common/constants'

const proxyExpensePercentMapping = {
  [MarriageStatus.SINGLE]: 0.1,
  [MarriageStatus.SINGLE_PARENT]: 0.1,
  [MarriageStatus.MARRIED]: 0.1
}

let proxyExpenseOnNumberOfChildren = 1500000

describe('Calculate proxy expense', () => {
  it('Input> declaredIncome:100,000 marriageStatus: single numberOfDependencies: 0 => Output: 10,000', () => {
    expect(calculateProxyExpense(proxyExpensePercentMapping, proxyExpenseOnNumberOfChildren)(MarriageStatus.SINGLE, 0, 100000)).toEqual(10000)
  })

  it('Input> declaredIncome:10,000,000 marriageStatus: single numberOfDependencies: 1 => Output: 2,500,000', () => {
    expect(calculateProxyExpense(proxyExpensePercentMapping, proxyExpenseOnNumberOfChildren)(MarriageStatus.SINGLE, 1, 10000000)).toEqual(2500000)
  })

  it('Input> declaredIncome:10,000,000 marriageStatus: single numberOfDependencies: 2 => Output: 4,000,000', () => {
    expect(calculateProxyExpense(proxyExpensePercentMapping, proxyExpenseOnNumberOfChildren)(MarriageStatus.SINGLE, 2, 10000000)).toEqual(4000000)
  })

  it('Input> declaredIncome:100,000 marriageStatus: single numberOfDependencies: 3 => Output: 4,510,000', () => {
    expect(calculateProxyExpense(proxyExpensePercentMapping, proxyExpenseOnNumberOfChildren)(MarriageStatus.SINGLE, 3, 100000)).toEqual(4510000)
  })

  it('Input> declaredIncome:5,000,000 marriageStatus: single numberOfDependencies: 4 => Output: 6,500,000', () => {
    expect(calculateProxyExpense(proxyExpensePercentMapping, proxyExpenseOnNumberOfChildren)(MarriageStatus.SINGLE, 4, 5000000)).toEqual(6500000)
  })

  it('Input> declaredIncome:5,000,000 marriageStatus: single numberOfDependencies: 5 => Output: 6,500,000', () => {
    expect(calculateProxyExpense(proxyExpensePercentMapping, proxyExpenseOnNumberOfChildren)(MarriageStatus.SINGLE, 5, 5000000)).toEqual(6500000)
  })

  it('Input> declaredIncome:100,000 marriageStatus: married numberOfDependencies: 0 => Output: 10,000', () => {
    expect(calculateProxyExpense(proxyExpensePercentMapping, proxyExpenseOnNumberOfChildren)(MarriageStatus.MARRIED, 0, 100000)).toEqual(10000)
  })

  it('Input> declaredIncome:100,000 marriageStatus: married numberOfDependencies: 1 => Output: 1,510,000', () => {
    expect(calculateProxyExpense(proxyExpensePercentMapping, proxyExpenseOnNumberOfChildren)(MarriageStatus.MARRIED, 1, 100000)).toEqual(1510000)
  })

  it('Input> declaredIncome:10,000,000 marriageStatus: married numberOfDependencies: 2 => Output: 4,000,000', () => {
    expect(calculateProxyExpense(proxyExpensePercentMapping, proxyExpenseOnNumberOfChildren)(MarriageStatus.MARRIED, 2, 10000000)).toEqual(4000000)
  })

  it('Input> declaredIncome:10,000,000 marriageStatus: married numberOfDependencies: 3 => Output: 5,500,000', () => {
    expect(calculateProxyExpense(proxyExpensePercentMapping, proxyExpenseOnNumberOfChildren)(MarriageStatus.MARRIED, 3, 10000000)).toEqual(5500000)
  })

  it('Input> declaredIncome:10,000,000 marriageStatus: married numberOfDependencies: 4 => Output: 7,000,000', () => {
    expect(calculateProxyExpense(proxyExpensePercentMapping, proxyExpenseOnNumberOfChildren)(MarriageStatus.MARRIED, 4, 10000000)).toEqual(7000000)
  })

  it('Input> declaredIncome:10,000,000 marriageStatus: married numberOfDependencies: 5 => Output: 7,000,000', () => {
    expect(calculateProxyExpense(proxyExpensePercentMapping, proxyExpenseOnNumberOfChildren)(MarriageStatus.MARRIED, 5, 10000000)).toEqual(7000000)
  })

  it('Input> declaredIncome:1000 marriageStatus: married numberOfDependencies: 1 => Output: 150100', () => {
    expect(calculateProxyExpense(proxyExpensePercentMapping, 150000)(MarriageStatus.MARRIED, 1, 1000)).toEqual(150100)
  })

  it('Input> declaredIncome:1000 marriageStatus: married numberOfDependencies: 2 => Output: 500', () => {
    expect(calculateProxyExpense(proxyExpensePercentMapping, 200)(MarriageStatus.MARRIED, 2, 1000)).toEqual(500)
  })
})

describe('Calculate monthly income', () => {
  it('Input> declaredIncome:100,000 proxyExpense: 3,050,000 => Output: -2,950,000', () => {
    expect(calculateMonthlyIncome(100000, 3050000)).toEqual(-2950000)
  })

  it('Input> declaredIncome:2,800,000 proxyExpense: 2000,000 => Output: 800,000', () => {
    expect(calculateMonthlyIncome(2800000, 2000000)).toEqual(800000)
  })
})

describe('Calculate first eligible', () => {
  it('Input> monthlyIncome:20,000,000 totalInstallment: 3,050,000 => Output: 17,000,000', () => {
    expect(calculateMonthlyIncome(20000000, 3000000)).toEqual(17000000)
  })
})

describe('Calculate eligible monthly installment', () => {
  it('Input> monthlyIncome: 20,000,000, creditLimit: 50,000,000, eligibleLoanAmount:50,000,000, tenure:18, interest:0.0167, totalInstallment: 5000,000 => Output: 3.612.778', () => {
    expect(calculateEligibleMonthlyInstallment(50000000, 18, 0.0167)).toEqual(3612778)
  })
})

describe('Calculate credit limit', () => {
  it('Input> monthlyIncome:1,500,000 totalInstallment: 60,000 tenor: 18 interest: 0.015 => Output: 7000,000', () => {
    expect(calculateCreditLimit(0.4)(1500000, 60000, 18, 0.015)).toEqual(7000000)
  })

  it('Input> monthlyIncome:680,000 totalInstallment: 60,000 tenor: 12 interest: 0.015 => Output: 2000,000', () => {
    expect(calculateCreditLimit(0.4)(680000, 60000, 12, 0.015)).toEqual(2000000)
  })
})

describe('Calculate eligible loan amount', () => {
  it('Input> monthlyIncome: 20,000,000, creditLimit: 50,000,000 => Output: 30,000,000', () => {
    expect(calculateEligibleLoanAmount(20000000, 50000000, 30000000)).toEqual(30000000)
  })
})

describe('Calculate eligible loan amount', () => {
  it('Input> monthlyIncome: 20,000,000, creditLimit: 44,000,000, maxEligibleLoanAmount: 20,000,000 => Output: 20,000,000', () => {
    expect(calculateEligibleLoanAmount(20000000, 44000000, 20000000)).toEqual(20000000)
  })
})

describe('Calculate eligible loan amount', () => {
  it('Input> monthlyIncome: 20,000,000, creditLimit: 10,000,000 => Output: 10,000,000', () => {
    expect(calculateEligibleLoanAmount(20000000, 10000000, 30000000)).toEqual(10000000)
  })
})
