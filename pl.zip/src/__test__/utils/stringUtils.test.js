import StringUtils from '../../utils/stringUtils'

describe('on capitalizeFirstCharacterOfEachWord on an input string', () => {
  it("should return a new string whose all the worlds' first character are in upper case", () => {
    // Arrange
    const inputString1 = 'ABC DEF'
    const inputString2 = 'abc def'
    const inputString3 = ''

    // Act
    const outputString1 = StringUtils.capitalizeFirstCharacterOfEachWord(inputString1)
    const outputString2 = StringUtils.capitalizeFirstCharacterOfEachWord(inputString2)

    // Assert
    expect(outputString1).toEqual('Abc Def')
    expect(outputString2).toEqual('Abc Def')
    expect(inputString3).toEqual(inputString3)
  })
})

describe('Getting query param object from query string', () => {
  test('Return param object when the query string is correct', () => {
    const inputStr = '?utm_source=summer-mailer&utm_medium=email&utm_campaign=summer-sale'

    const expected = {
      utm_source: 'summer-mailer',
      utm_medium: 'email',
      utm_campaign: 'summer-sale'
    }

    const result = StringUtils.getQueryParams(inputStr, false)

    expect(result).toMatchObject(expected)
  })

  test('Return empty param object when the query string is underfine', () => {
    const inputStr = void 0

    const expected = {}

    const result = StringUtils.getQueryParams(inputStr, false)

    expect(result).toMatchObject(expected)
  })

  test('Return empty param object when the query string format is not correct ', () => {
    const inputStr = 'utm_source:summer-mailer'

    const expected = {}

    const result = StringUtils.getQueryParams(inputStr, false)

    expect(result).toMatchObject(expected)
  })
})

describe('Getting query param object from query string allow undefined value for UTM_SOURCE', () => {
  test('Return param object when the query string is correct', () => {
    const inputStr = '?utm_source=summer-mailer&utm_medium=email&utm_campaign=summer-sale'

    const expected = {
      utm_source: 'summer-mailer',
      utm_medium: 'email',
      utm_campaign: 'summer-sale'
    }

    const result = StringUtils.getQueryParamsAllowingUndefinedUtmSource(inputStr)

    expect(result).toMatchObject(expected)
  })

  test('Return empty param object when the query string is underfine', () => {
    const inputStr = void 0

    const expected = {}

    const result = StringUtils.getQueryParamsAllowingUndefinedUtmSource(inputStr)

    expect(result).toMatchObject(expected)
  })

  test('Return empty param object when the query string format is not correct ', () => {
    const inputStr = 'utm_source:summer-mailer'

    const expected = {}

    const result = StringUtils.getQueryParamsAllowingUndefinedUtmSource(inputStr)

    expect(result).toMatchObject(expected)
  })

  test('Return empty param object when the query string format is not correct ', () => {
    const inputStr = '?utm_source=&utm_medium=email&utm_campaign='

    const expected = {
      utm_source: '',
      utm_medium: 'email'
    }

    const result = StringUtils.getQueryParamsAllowingUndefinedUtmSource(inputStr)

    expect(result).toMatchObject(expected)
  })
})

describe('equalsIgnoreCase 2 strings', () => {
  it("should return true if 2 strings equals ignore case", () => {
    //Arrange
    const inputString1 = 'ABC DEF'
    const inputString2 = 'abc def'

    //Act
    let output = StringUtils.equalsIgnoreCase(inputString1, inputString2)

    //Assert
    expect(output).toEqual(true)
  })
})

describe('json string to object', () => {
  it("return parsed object if success, empty object if exception occurs", () => {
    //Arrange
    const inputString1 = "{\"attr\" : \"1\"}"
    const inputString2 = 'abc def'

    //Act
    let output1 = StringUtils.jsonToObject(inputString1)
    let output2 = StringUtils.jsonToObject(inputString2)

    //Assert
    expect(output1.attr).toEqual("1")
    expect(output2).toEqual({})
  })
})
