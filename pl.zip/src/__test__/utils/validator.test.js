import { checkCompanyNameValid } from "./../../common/validator.js";
import ValidationUtils from "../../utils/validationUtils";

describe("Using checkCompanyNameValid to validate company input", () => {
  const errorMessage = "error message";
  const companyNameInvalidValidate = checkCompanyNameValid(errorMessage)({ minLength: 4, alphabetMinLength: 3 });
  it('Return error message when company contain invalid character (not include Alphabets, Numeric, ".-,/()" space)', () => {
    // Arrange
    let inputString = "Pt indo ^^^";
    // Assert
    expect(companyNameInvalidValidate(inputString)).toBe(errorMessage);
  });
  it("Return error message when First Character does not Alphabet", () => {
    // Arrange
    let inputString = "3 Pt indo";
    // Assert
    expect(companyNameInvalidValidate(inputString)).not.toBe(void 0);
    expect(companyNameInvalidValidate(inputString)).toEqual(errorMessage);
  });
  it("Return error message when company name is less than 5 letters", () => {
    // Arrange
    let inputString = "Pt in";
    // Assert
    expect(companyNameInvalidValidate(inputString)).toBe(void 0);
  });
  it('Return undefined when company contain valid character (include Alphabets, Numeric, ".-,/()" space)', () => {
    // Arrange
    let inputString = "P/t. () 3,in-do";
    // Assert
    expect(companyNameInvalidValidate(inputString)).toBe(void 0);
  });
});

describe("Test nikValidation", () => {
  it("Input: Empty, Output expected: Masukkan nomor KTP Anda", () => {
    expect(ValidationUtils.customerPersonalInformation.nikValidation("")).toBe("Masukkan nomor KTP Anda");
  });
  it("Input: abcd, Output expected: Nomor KTP harus diisi dengan angka", () => {
    expect(ValidationUtils.customerPersonalInformation.nikValidation("abcd")).toBe(
      "Nomor KTP harus diisi dengan angka"
    );
  });
  it("Input: a string valid but length != 16, Output expected: Nomor KTP harus diisi dengan angka", () => {
    expect(ValidationUtils.customerPersonalInformation.nikValidation("123456789")).toBe(
      "Nomor KTP Anda harus 16 angka"
    );
  });
  it("Input: valid string, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.nikValidation("1234567891234567")).toBe(undefined);
  });
});

describe("Test nameValidation", () => {
  it("Input: Empty, Output expected: Masukkan nama lengkap Anda", () => {
    expect(ValidationUtils.customerPersonalInformation.nameValidation("")).toBe("Masukkan nama lengkap Anda");
  });
  it("Input: 1234a, Output expected: Nama harus diisi dengan huruf", () => {
    expect(ValidationUtils.customerPersonalInformation.nameValidation("1234a")).toBe("Nama harus diisi dengan huruf");
  });
  it("Input: Yogi, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.nameValidation("Yogi")).toBe(undefined);
  });
});

describe("Test contactNameValidation", () => {
  it("Input: Empty, Output expected: Masukkan nama lengkap kontak darurat", () => {
    expect(ValidationUtils.customerPersonalInformation.contactNameValidation("")).toBe(
      "Masukkan nama lengkap kontak darurat"
    );
  });
  it("Input: 1234a, Output expected: Nama harus diisi dengan huruf", () => {
    expect(ValidationUtils.customerPersonalInformation.contactNameValidation("1234a")).toBe(
      "Nama harus diisi dengan huruf"
    );
  });
  it("Input: Yogi, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.contactNameValidation("Yogi")).toBe(undefined);
  });
});

describe("Test phoneNumberValidation", () => {
  it("Input: Empty, Output expected: Masukkan nomor ponsel Anda", () => {
    expect(ValidationUtils.customerPersonalInformation.phoneNumberValidation("")).toBe("Masukkan nomor ponsel Anda");
  });
  it("Input: 1234a, Output expected: Nomor ponsel Anda tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.phoneNumberValidation("1234a")).toBe(
      "Nomor ponsel Anda tidak valid"
    );
  });
  it("Input: 0123456, Output expected: Nomor ponsel Anda tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.phoneNumberValidation("0123456")).toBe(
      "Nomor ponsel Anda tidak valid"
    );
  });
  it("Input: 012345678901234567, Output expected: Nomor ponsel Anda tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.phoneNumberValidation("012345678901234567")).toBe(
      "Nomor ponsel Anda tidak valid"
    );
  });
  it("Input: 01234567789, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.phoneNumberValidation("01234567789")).toBe(undefined);
  });
});

describe("Test emergencyPhoneNumberValidation", () => {
  it("Input: Empty, Output expected: Masukkan nomor ponsel kontak darurat", () => {
    expect(ValidationUtils.customerPersonalInformation.emergencyPhoneNumberValidation("")).toBe(
      "Masukkan nomor ponsel kontak darurat"
    );
  });
  it("Input: 123456789, Output expected: Nomor ponsel kontak darurat tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.emergencyPhoneNumberValidation("123456789")).toBe(
      "Nomor ponsel kontak darurat tidak valid"
    );
  });
  it("Input: 12345678901234567, Output expected: Nomor ponsel kontak darurat tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.emergencyPhoneNumberValidation("12345678901234567")).toBe(
      "Nomor ponsel kontak darurat tidak valid"
    );
  });
  it("Input: 0123456789 (the same with phone number of owner), Output expected: Nomor ponsel kontak darurat harus berbeda dengan nomor ponsel Anda", () => {
    expect(
      ValidationUtils.customerPersonalInformation.emergencyPhoneNumberValidation("0123456789", {
        phoneNumber: "0123456789"
      })
    ).toBe("Nomor ponsel kontak darurat harus berbeda dengan nomor ponsel Anda");
  });
  it("Input: 0123456789 (10 digits), Output expected: valid", () => {
    expect(
      ValidationUtils.customerPersonalInformation.emergencyPhoneNumberValidation("0123456789", {
        phoneNumber: "0123456788"
      })
    ).toBe(undefined);
  });
  it("Input: 012345678912345 (15 digits), Output expected: valid", () => {
    expect(
      ValidationUtils.customerPersonalInformation.emergencyPhoneNumberValidation("012345678912345", {
        phoneNumber: "0123456789"
      })
    ).toBe(undefined);
  });
});

describe("Test emergencyContactNameValidation", () => {
  it("Input: Empty, Output expected: Masukkan nama lengkap kontak darurat", () => {
    expect(ValidationUtils.customerPersonalInformation.emergencyContactNameValidation("")).toBe(
      "Masukkan nama lengkap kontak darurat"
    );
  });
  it("Input: 123456789, Output expected: Nama harus diisi dengan huruf", () => {
    expect(ValidationUtils.customerPersonalInformation.emergencyContactNameValidation("123456789")).toBe(
      "Nama harus diisi dengan huruf"
    );
  });
  it("Input: Real Name, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.emergencyContactNameValidation("Real Name")).toBe(undefined);
  });
});

describe("Test contactPhoneValidation", () => {
  it("Input: Empty, Output expected: Masukkan nomor ponsel kontak darurat", () => {
    expect(ValidationUtils.customerPersonalInformation.contactPhoneValidation("")).toBe(
      "Masukkan nomor ponsel kontak darurat"
    );
  });
  it("Input: 123456789, Output expected: Nomor ponsel kontak darurat tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.contactPhoneValidation("123456789")).toBe(
      "Nomor ponsel kontak darurat tidak valid"
    );
  });
  it("Input: string less than 9 characters, Output expected: Nomor ponsel kontak darurat tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.contactPhoneValidation("01234567")).toBe(
      "Nomor ponsel kontak darurat tidak valid"
    );
  });
  it("Input: string more than 16 characters, Output expected: Nomor ponsel kontak darurat tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.contactPhoneValidation("012345678901234567")).toBe(
      "Nomor ponsel kontak darurat tidak valid"
    );
  });
  it("Input: valid phone number, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.contactPhoneValidation("0123456789")).toBe(undefined);
  });
});

describe("Test dayOfBirthValidation", () => {
  it("Input: Empty, Output expected: Masukkan tanggal lahir Anda", () => {
    expect(ValidationUtils.customerPersonalInformation.dayOfBirthValidation("")).toBe("Masukkan tanggal lahir Anda");
  });
  it("Input: 123456789, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.dayOfBirthValidation("123456789")).toBe(undefined);
  });
  it("Input: 123456789, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.dayOfBirthValidation("123456789")).toBe(undefined);
  });
});

describe("Test emailValidation", () => {
  it("Input: Empty, Output expected: Masukkan alamat email Anda", () => {
    expect(ValidationUtils.customerPersonalInformation.emailValidation("")).toBe("Masukkan alamat email Anda");
  });
  it("Input: 123456789, Output expected: Format alamat email Anda tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.emailValidation("123456789")).toBe(
      "Format alamat email Anda tidak valid"
    );
  });
  it("Input: abc@abc, Output expected: Format alamat email Anda tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.emailValidation("abc@abc")).toBe(
      "Format alamat email Anda tidak valid"
    );
  });
  it("Input: abc@abc.com, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.emailValidation("abc@abc.com")).toBe(undefined);
  });
});

describe("Test wardValidation", () => {
  it("Input: Empty, Output expected: Masukkan kelurahan Anda", () => {
    expect(ValidationUtils.customerPersonalInformation.wardValidation("")).toBe("Masukkan kelurahan Anda");
  });
  it("Input: 434#332, Output expected: Format yang Anda masukkan tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.wardValidation("434#332")).toBe(
      "Format yang Anda masukkan tidak valid"
    );
  });
  it("Input: abc123,- .dds, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.wardValidation("abc123,- .dds")).toBe(undefined);
  });
});

describe("Test cityValidation", () => {
  it("Input: Empty, Output expected: Pilih kota Anda", () => {
    expect(ValidationUtils.customerPersonalInformation.cityValidation("")).toBe("Pilih kota Anda");
  });
  it("Input: abc123,- .dds, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.cityValidation("abc123,- .dds")).toBe(undefined);
  });
});

describe("Test relationshipValidation", () => {
  it("Input: Empty, Output expected: Pilih hubungan Anda", () => {
    expect(ValidationUtils.customerPersonalInformation.relationshipValidation("")).toBe("Pilih hubungan Anda");
  });
  it("Input: abc123,- .dds, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.relationshipValidation("abc123,- .dds")).toBe(undefined);
  });
});

describe("Test districtValidation", () => {
  it("Input: Empty, Output expected: Pilih hubungan Anda", () => {
    expect(ValidationUtils.customerPersonalInformation.districtValidation("")).toBe("Masukkan kecamatan Anda");
  });
  it("Input: %^&4#332, Output expected: Format yang Anda masukkan tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.districtValidation("%^&4#332")).toBe(
      "Format yang Anda masukkan tidak valid"
    );
  });
  it("Input: abc123,- .dds, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.districtValidation("abc123,- .dds")).toBe(undefined);
  });
});

describe("Test addressValidation", () => {
  it("Input: Empty, Output expected: Pilih hubungan Anda", () => {
    expect(ValidationUtils.customerPersonalInformation.addressValidation("")).toBe("Masukkan alamat Anda");
  });
  it("Input: %^&4#332, Output expected: Format yang Anda masukkan tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.addressValidation("%^&4#332")).toBe(
      "Format yang Anda masukkan tidak valid"
    );
  });
  it("Input: abc123456789, Output expected: Format yang Anda masukkan tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.addressValidation("abc123456789", 8)).toBe(
      "Format yang Anda masukkan tidak valid"
    );
  });
  it("Input: abc123456789, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.addressValidation("abc123456789", 15)).toBe(undefined);
  });
});

describe("Test loanPurposeValidation", () => {
  it("Input: Empty, Output expected: Pilih tujuan pinjaman Anda", () => {
    expect(ValidationUtils.customerPersonalInformation.loanPurposeValidation("")).toBe("Pilih tujuan pinjaman Anda");
  });
  it("Input: abc123,- .dds, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.loanPurposeValidation("abc123,- .dds")).toBe(undefined);
  });
});

describe("Test dobValidation", () => {
  it("Input: Empty, Output expected: Masukkan tanggal lahir Anda", () => {
    expect(ValidationUtils.customerPersonalInformation.dobValidation("")).toBe("Masukkan tanggal lahir Anda");
  });
  it("Input: 12/05/1899, Output expected: Tanggal lahir yang Anda masukkan tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.dobValidation({ day: 12, month: { id: 5 }, year: 1899 })).toBe(
      "Tanggal lahir yang Anda masukkan tidak valid"
    );
  });
  it("Input: -1/02/1988, Output expected: Tanggal lahir yang Anda masukkan tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.dobValidation({ day: -1, month: { id: 2 }, year: 1988 })).toBe(
      "Tanggal lahir yang Anda masukkan tidak valid"
    );
  });
  it("Input: 30/2/1988, Output expected: Tanggal lahir yang Anda masukkan tidak valid", () => {
    expect(ValidationUtils.customerPersonalInformation.dobValidation({ day: 30, month: { id: 2 }, year: 1988 })).toBe(
      "Tanggal lahir yang Anda masukkan tidak valid"
    );
  });
  it("Input: 12/05/2016 - less than 21 ages, Output expected: Usia Anda tidak sesuai dengan Syarat & Ketentuan KTA TymeDigital", () => {
    expect(ValidationUtils.customerPersonalInformation.dobValidation({ day: 12, month: { id: 5 }, year: 2016 })).toBe(
      "Usia Anda tidak sesuai dengan Syarat & Ketentuan KTA TymeDigital"
    );
  });
  it("Input: 12/03/1950 - more than 55 ages, Output expected: Usia Anda tidak sesuai dengan Syarat & Ketentuan KTA TymeDigital", () => {
    expect(ValidationUtils.customerPersonalInformation.dobValidation({ day: 12, month: { id: 3 }, year: 1950 })).toBe(
      "Usia Anda tidak sesuai dengan Syarat & Ketentuan KTA TymeDigital"
    );
  });
  it("Input: 12/05/1988, Output expected: valid", () => {
    expect(ValidationUtils.customerPersonalInformation.dobValidation({ day: 12, month: { id: 5 }, year: 1988 })).toBe(
      undefined
    );
  });
});

describe("Test earningsPerMonthValidation", () => {
  it("Input: Empty, Output expected: Masukkan penghasilan per bulan Anda", () => {
    expect(ValidationUtils.customerFinancialInformation.earningsPerMonthValidation("")).toBe(
      "Masukkan penghasilan per bulan Anda"
    );
  });
  it("Input: ., Output expected: Masukkan penghasilan per bulan Anda", () => {
    expect(ValidationUtils.customerFinancialInformation.earningsPerMonthValidation(".")).toBe(
      "Masukkan penghasilan per bulan Anda"
    );
  });
  it("Input: abc, Output expected: Penghasilan per bulan harus diisi dengan angka", () => {
    expect(ValidationUtils.customerFinancialInformation.earningsPerMonthValidation("abc")).toBe(
      "Penghasilan per bulan harus diisi dengan angka"
    );
  });
  it("Input: 4.999.999, Output expected: Penghasilan per bulan harus diisi dengan angka", () => {
    expect(ValidationUtils.customerFinancialInformation.earningsPerMonthValidation("4.999.999")).toBe(
      "Penghasilan per bulan harus minimum 5 juta rupiah"
    );
  });
  it("Input: 5.000.001, Output expected: Penghasilan per bulan harus diisi dengan angka", () => {
    expect(ValidationUtils.customerFinancialInformation.earningsPerMonthValidation("5.000.001")).toBe(undefined);
  });
});

describe("Test monthlyInstallmentValidation", () => {
  it("Input: monthlyInstallment is empty, haveMonthlyInstallment = true, Output expected: Masukkan total angsuran per bulan Anda", () => {
    expect(
      ValidationUtils.customerFinancialInformation.monthlyInstallmentValidation("", { haveMonthlyInstallment: true })
    ).toBe("Masukkan total angsuran per bulan Anda");
  });
  it("Input: monthlyInstallment is empty, haveMonthlyInstallment = false, Output expected: valid", () => {
    expect(
      ValidationUtils.customerFinancialInformation.monthlyInstallmentValidation("", { haveMonthlyInstallment: false })
    ).toBe(undefined);
  });
  it("Input: monthlyInstallment=abc, haveMonthlyInstallment = true, Output expected: Total angsuran per bulan harus diisi dengan angka", () => {
    expect(
      ValidationUtils.customerFinancialInformation.monthlyInstallmentValidation("abc", { haveMonthlyInstallment: true })
    ).toBe("Total angsuran per bulan harus diisi dengan angka");
  });
  it("Input: monthlyInstallment=1000, haveMonthlyInstallment = true, Output expected: Total angsuran per bulan harus diisi dengan angka", () => {
    expect(
      ValidationUtils.customerFinancialInformation.monthlyInstallmentValidation("1000", {
        haveMonthlyInstallment: true
      })
    ).toBe(undefined);
  });
});

describe("Test monthlyInstallmentSelection", () => {
  it("Input: Empty, Output expected: Anda harus menjawab pertanyaan ini", () => {
    expect(ValidationUtils.customerFinancialInformation.monthlyInstallmentSelection(void 0)).toBe(
      "Anda harus menjawab pertanyaan ini"
    );
  });
  it("Input: 1000, Output expected: valid", () => {
    expect(ValidationUtils.customerFinancialInformation.monthlyInstallmentSelection("1000")).toBe(undefined);
  });
});
