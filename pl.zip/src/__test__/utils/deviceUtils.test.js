import DeviceUtils from '../../utils/deviceUtils'

jest.mock('fingerprintjs', () => {
  return jest.fn().mockImplementation(() => {
    return {get: () => 'id'};
  });
});


describe('get device id', () => {
  it("test get device id, return mock device id", () => {
    expect(DeviceUtils.getDeviceId()).toEqual('id')
  })
})
