import { calculateLoanExpireDate } from '../../utils/decisionUtils'

describe('calculate approval loan expire date', () => {
  it('check result 06/12/17 when input date is 29/11/2017 (timestamp: 1512034207753)', () => {
    //Arrange
    let decisionDate = 1512034207753
    let validityPeriod = 7
    let expireDate = calculateLoanExpireDate(decisionDate, validityPeriod)

    // Act
    let expected = new Date(1512639007753)

    // Assert
    expect(expireDate).toEqual(expected)
  })
})