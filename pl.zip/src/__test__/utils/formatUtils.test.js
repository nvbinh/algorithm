import {
  formatPhoneNumber,
  formatCurrency,
  formatLoanExpireDate,
  maskEmailAddress,
  formatSecurityPhone
} from '../../utils/formatUtils'

describe('Format phone number with head is +62', () => {
  it('input empty - output empty', () => {
    expect(formatPhoneNumber(undefined)).toEqual('')
  })

  it('input 123456 - output 123456', () => {
    expect(formatPhoneNumber('123456')).toEqual('123456')
  })

  it('input: 01666458432 - output: +621666458432', () => {
    expect(formatPhoneNumber('01666458432')).toEqual('+621666458432')
  })

  it('input: 621666458432 - output: +621666458432', () => {
    expect(formatPhoneNumber('621666458432')).toEqual('+621666458432')
  })
})

describe('Format number with dot', () => {
  it('input 20000000 - output 20.000.000', () => {
    expect(formatCurrency(20000000)).toEqual('20.000.000')
  })
  it('input 20.000.000 - output 20.000.000', () => {
    expect(formatCurrency('20.000.000')).toEqual('20.000.000')
  })
  it("input undefined - output ''", () => {
    expect(formatCurrency(undefined)).toEqual('')
  })
  it("input 'abc' - output ''", () => {
    expect(formatCurrency('abc')).toEqual('')
  })
  it("input 0,123,123 - output 123.123", () => {
    expect(formatCurrency('0,123,123')).toEqual('123.123')
  })

})

describe('format approval loan expire date', () => {
  it('check result 06/12/17 when input date is 29/11/2017 (timestamp: 1512034207753)', () => {
    // Arrange
    let decisionDate = 1511947807753 // date is 29/11/2017
    let validityPeriod = 7 * 86400 * 1000
    let expireDate = new Date(decisionDate + validityPeriod)
    let formattedDate = formatLoanExpireDate(expireDate)

    // Act
    let expected = '06/12/17'

    // Assert
    expect(formattedDate).toEqual(expected)
  })
})

describe('mask email address', () => {
  it('Return empty string when email is null or empty', () => {
    // Arrange
    let emailNull = undefined
    let emailEmpty = ''

    // Act
    let expected = ''

    // Assert
    expect(maskEmailAddress(emailNull)).toEqual(expected)
    expect(maskEmailAddress(emailEmpty)).toEqual(expected)
  })

  it('Return same value for invalid email address', () => {
    // Arrange
    let invalidEmail = 'invalidemail'

    // Act
    let expected = 'invalidemail'

    // Assert
    expect(maskEmailAddress(invalidEmail)).toEqual(expected)
  })

  it('Return first char before @ plus double star ** when first part of email before @ is only 1 letter', () => {
    // Arrange
    let emailAddress = 'a@hubcba.com'

    // Act
    let expected = 'a**@hubcba.com'

    // Assert
    expect(maskEmailAddress(emailAddress)).toEqual(expected)
  })

  it('Return only the first 2 letters and mask the rest of letters before symbol "@" when first part of email has only 2 letters', () => {
    // Arrange
    let emailAddress = 'ph@hubcba.com'

    // Act
    let expected = 'ph**@hubcba.com'

    // Assert
    expect(maskEmailAddress(emailAddress)).toEqual(expected)
  })

  it('Return only the first 2 letters and mask the rest of letters before symbol "@" when first part of email has more than 2 letters', () => {
    // Arrange
    let emailAddress = 'ph.tr@hubcba.com'

    // Act
    let expected = 'ph**@hubcba.com'

    // Assert
    expect(maskEmailAddress(emailAddress)).toEqual(expected)
  })
})

describe('Format phone number', () => {
  it('input 0621234567 - output 062*****67', () => {
    expect(formatSecurityPhone('06212345678')).toEqual('062*****678')
  })
  it('the phone number is too short, it return the original input', () => {
    expect(formatSecurityPhone('0621234')).toEqual('0621234')
  })
  it('the phone number is invalid, it return the original input', () => {
    expect(formatSecurityPhone(void 0)).toEqual(void 0)
    expect(formatSecurityPhone(null)).toEqual(null)
    expect(formatSecurityPhone('')).toEqual('')
  })
})
