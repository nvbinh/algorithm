import configureMockStore from 'redux-mock-store'
import {createEpicMiddleware} from 'redux-observable'
import Rx from 'rxjs/Rx'
import ActionType from '../../actions/actionType'
import ActionFactory from '../../actions/actionFactory'

import '../setupTests'
import getDecisionStatusEpic from '../../middlewares/decision.epic'
import DecisionService from "../../services/decision.service"
import {DecisionStatus} from "../../common/constants"

const epicMiddlewares = createEpicMiddleware(getDecisionStatusEpic)
const mockStore = configureMockStore([epicMiddlewares])

jest.mock('../../services/decision.service')
jest.useFakeTimers()


const getDecisionStatusRunningResponse = {
  data: {
    jobStatus: DecisionStatus.RUNNING
  }
}
const getDecisionStatusCompletedResponse = {
  data: {
    jobStatus: DecisionStatus.COMPLETED
  }
}

const getDecisionStatusFailedResponse = {
  data: {
    jobStatus: DecisionStatus.FAILED
  }
}


describe('Get decision status success', () => {
  let store
  beforeEach(() => {
    store = mockStore({
      getConfigurationsAPIResponse: {configurations: {desisionStatusInterval: 1, desisionStatusMaxInterval: 3}},
      customerSubmitLoanResponse: {customerSession: {accessToken: '12344'}},
      otpStatus: {validate: {jobId: '12345'}}
    })
  })

  it('When over max retry then return jobStatus is TIME_OUT', () => {
    DecisionService.mockImplementation(() => ({
      getDecisionStatus: () => Rx.Observable.of(getDecisionStatusRunningResponse)
    }))

    let expected = [
      {meta: undefined, payload: undefined, type: ActionType.GET_DECISION_STATUS},
      {
        meta: undefined, payload: {jobStatus: DecisionStatus.TIME_OUT},
        type: ActionType.GET_DECISION_STATUS_SUCCESS
      }
    ]

    store.dispatch(ActionFactory.ofType(ActionType.GET_DECISION_STATUS))
    jest.runOnlyPendingTimers()
    expect(store.getActions()).toEqual(expected)
  })

  it('When decision completed then return jobStatus is COMPLETED', () => {
    DecisionService.mockImplementation(() => ({
      getDecisionStatus: () => Rx.Observable.of(getDecisionStatusCompletedResponse)
    }))

    let expected = [
      {meta: undefined, payload: undefined, type: ActionType.GET_DECISION_STATUS},
      {
        meta: undefined, payload: getDecisionStatusCompletedResponse.data,
        type: ActionType.GET_DECISION_STATUS_SUCCESS
      }
    ]

    store.dispatch(ActionFactory.ofType(ActionType.GET_DECISION_STATUS))
    jest.runOnlyPendingTimers()
    expect(store.getActions()).toEqual(expected)
  })

  it('When decision failed then return jobStatus is FAILED', () => {
    DecisionService.mockImplementation(() => ({
      getDecisionStatus: () => Rx.Observable.of(getDecisionStatusFailedResponse)
    }))

    let expected = [
      {meta: undefined, payload: undefined, type: ActionType.GET_DECISION_STATUS},
      {
        meta: undefined,
        type: ActionType.GET_DECISION_STATUS_SUCCESS,
        payload: getDecisionStatusFailedResponse.data
      }]

    store.dispatch(ActionFactory.ofType(ActionType.GET_DECISION_STATUS))
    jest.runOnlyPendingTimers()
    expect(store.getActions()).toEqual(expected)
  })
})

describe('Get decision status time out', () => {
  let store
  beforeEach(() => {
    store = mockStore({
      getConfigurationsAPIResponse: {configurations: {desisionStatusInterval: 1, desisionStatusMaxInterval: 1}},
      customerSubmitLoanResponse: {customerSession: {accessToken: '12344'}},
      otpStatus: {validate: {jobId: '12345'}}
    })
  })

  it('When jobStatus is RUNNING --> Expected: No any action was trigger', () => {
    DecisionService.mockImplementation(() => ({
      getDecisionStatus: () => Rx.Observable.of(getDecisionStatusRunningResponse)
    }))
    store.dispatch(ActionFactory.ofType(ActionType.GET_DECISION_STATUS))
    jest.runOnlyPendingTimers()
    expect(store.getActions().length).toEqual(2)
    expect(store.getActions()[1].type).toEqual(ActionType.GET_DECISION_STATUS_SUCCESS)
    expect(store.getActions()[1].payload.jobStatus).toEqual(DecisionStatus.TIME_OUT)
  })

  it('When get decision request timeout then do nothing', () => {
    DecisionService.mockImplementation(() => ({
      getDecisionStatus: () => Rx.Observable.of(getDecisionStatusCompletedResponse).delay(4000)
    }))
    store.dispatch(ActionFactory.ofType(ActionType.GET_DECISION_STATUS))
    jest.runOnlyPendingTimers()
    expect(store.getActions().length).toEqual(2)
    expect(store.getActions()[1].type).toEqual(ActionType.GET_DECISION_STATUS_SUCCESS)
  })
})

describe('Get decision status throw data exception', () => {
  let store
  beforeEach(() => {
    store = mockStore({
      getConfigurationsAPIResponse: void 0,
      customerSubmitLoanResponse: {customerSession: {accessToken: '12344'}},
      otpStatus: {validate: {jobId: '12345'}}
    })
  })

  it('When configuration data error then trigger action GET_DECISION_STATUS_FAILED', () => {
    DecisionService.mockImplementation(() => ({
      getDecisionStatus: () => Rx.Observable.throw(getDecisionStatusCompletedResponse)
    }))

    store.dispatch(ActionFactory.ofType(ActionType.GET_DECISION_STATUS))
    jest.runOnlyPendingTimers()
    expect(store.getActions()[1].type).toEqual(ActionType.GET_DECISION_STATUS_FAILED)
  })
})
