import configureMockStore from 'redux-mock-store'
import { createEpicMiddleware } from 'redux-observable'
import Rx from 'rxjs/Rx'

import { saveDataInSessionStorage } from '../../actions/actionCreator'
import saveDataInSessionStorageEpic from '../../middlewares/saveDataInSessionStorage.epic'
import '../setupTests'
import CacheUtils from '../../utils/cacheUtils'

const epicMiddlewares = createEpicMiddleware(saveDataInSessionStorageEpic)
const mockStore = configureMockStore([epicMiddlewares])

jest.mock('../../utils/cacheUtils')

describe('Invoking the screen duration API to log the duration time page', () => {
  let store

  beforeEach(() => {
    store = mockStore({})
  })

  afterEach(() => {
    epicMiddlewares.replaceEpic(saveDataInSessionStorageEpic)
  })

  it('Invoke save data to session storage', () => {
    store.dispatch(saveDataInSessionStorage({key: 'session', data: {data: 'cache'}}))

    expect(CacheUtils.loadCachedData).toHaveBeenCalledTimes(1)
    expect(CacheUtils.saveDataToCache).toHaveBeenCalledTimes(1)
  })
})
