import configureMockStore from 'redux-mock-store'
import { createEpicMiddleware } from 'redux-observable'
import Rx from 'rxjs/Rx'
import { getConfigurations } from '../../actions/actionCreator'
import getConfigurationsEpic from '../../middlewares/configurations.epic'
import ConfigurationsService from '../../services/configurations.service'
import '../setupTests'

const epicMiddlewares = createEpicMiddleware(getConfigurationsEpic)
const mockStore = configureMockStore([epicMiddlewares])

const getLoanConfigSuccessAPIResponse = {
  configurations: [
    {
      key: 'apim.personalloan.web.validityperiod',
      value: '3600'
    },
    {
      key: 'apim.personalloan.kiosk.validityperiod',
      value: '3600'
    },
    {
      key: 'personalloan.application.validityperiod',
      value: '7'
    },
    {
      key: 'personalloan.contract.penalty',
      value: '6%'
    },
    {
      key: 'personalloan.contract.template',
      value: 'template.html.loan_contract'
    },
    {
      key: 'usb.camera.payslip.width',
      value: '1280'
    },
    {
      key: 'usb.camera.payslip.height',
      value: '720'
    },
    {
      key: 'personalloan.income.amount.difference',
      value: '500000'
    },
    {
      key: 'personalloan.income.month.difference',
      value: '2'
    },
    {
      key: 'personalloan.time.caching',
      value: '3600'
    },
    {
      key: 'personalloan.client.recaptcha.google',
      value: '6LfljzQUAAAAALQNhxS0pJFGN2yzNwDs6XeqyNjf'
    }
  ]
}

const getConfigurationsAPIResponse = {
  'data': getLoanConfigSuccessAPIResponse,
  'errors': [],
  'warnings': [],
  'success': true
}

jest.mock('../../services/configurations.service')
ConfigurationsService.mockImplementation(() => ({
  getConfigurations: () => Rx.Observable.of(getConfigurationsAPIResponse)
}))

describe('getProductLoanInfo async actions', () => {
  let store

  beforeEach(() => {
    store = mockStore({getConfigurationsAPIResponse: {}})
  })

  afterEach(() => {
    epicMiddlewares.replaceEpic(getConfigurationsEpic)
  })

  it('should dispatch action GET_LOAN_CONFIG_SUCCESS', () => {
    store.dispatch(getConfigurations())

    expect(store.getActions()[0]).not.toBeFalsy()
    expect(store.getActions()[1]['payload']).not.toBeNull()
    expect(store.getActions()[1]['payload']).not.toBeUndefined()
    expect(store.getActions()[1]['payload']).not.toEqual({})
  })
})


