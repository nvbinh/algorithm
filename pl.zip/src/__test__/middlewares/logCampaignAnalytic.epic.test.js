import configureMockStore from 'redux-mock-store'
import { createEpicMiddleware } from 'redux-observable'
import Rx from 'rxjs/Rx'

import { logCampaignAnalytic } from '../../actions/actionCreator'
import logCampaignAnalyticEpic from '../../middlewares/logCampaignAnalytic.epic'
import AppService from '../../services/app.service'
import '../setupTests'

const epicMiddlewares = createEpicMiddleware(logCampaignAnalyticEpic)
const mockStore = configureMockStore([epicMiddlewares])

jest.mock('../../services/app.service')

describe('Invoking the screen duration API to log the duration time page', () => {
  let store

  beforeEach(() => {
    store = mockStore({
      customerSubmitLoanResponse: {
        customerId: '123456789',
        customerSession: {accessToken: '123456789'}
      }
    })

    AppService.mockClear();
  })

  afterEach(() => {
    epicMiddlewares.replaceEpic(logCampaignAnalyticEpic)
  })

  it('Invoke log time API success', () => {
    AppService.mockImplementation(() => ({
      logCampaignAnalytic: () => Rx.Observable.of('response')
    }))

    const expected = [
      {
        ...logCampaignAnalytic(),
        payload: void 0
      }
    ]

    store.dispatch(logCampaignAnalytic())

    expect(store.getActions()).toEqual(expected)
  })
})
