export const lov = {
  data: {
    ownerStatus: [
      {
        id: 82,
        code: "OWNER",
        name: "Owner",
        isDefault: false
      }
    ],
    province: [
      {
        id: 1,
        code: "0300-DKI JAYA",
        name: "JAKARTA",
        isDefault: false,
        town: [
          {
            id: 83,
            code: "0393-JAKARTA BARAT",
            name: "JAKARTA BARAT",
            isDefault: false
          },
          {
            id: 84,
            code: "0391-JAKARTA PUSAT",
            name: "JAKARTA PUSAT",
            isDefault: false
          },
          {
            id: 85,
            code: "0394-JAKARTA SELATAN",
            name: "JAKARTA SELATAN",
            isDefault: false
          },
          {
            id: 86,
            code: "0395-JAKARTA TIMUR",
            name: "JAKARTA TIMUR",
            isDefault: false
          },
          {
            id: 87,
            code: "0392-JAKARTA UTARA",
            name: "JAKARTA UTARA",
            isDefault: false
          },
          {
            id: 88,
            code: "0396-KEPULAUAN SERIBU",
            name: "KEPULAUAN SERIBU",
            isDefault: false
          }
        ]
      },
      {
        id: 2,
        code: "0200-BANTEN",
        name: "BANTEN",
        isDefault: false,
        town: [
          {
            id: 92,
            code: "0204-KAB TANGERANG",
            name: "TANGERANG (KAB)",
            isDefault: false
          },
          {
            id: 95,
            code: "0292-TANGERANG",
            name: "TANGERANG (KOTA)",
            isDefault: false
          }
        ]
      },
      {
        id: 3,
        code: "0100-JAWA BARAT",
        name: "JAWA BARAT",
        isDefault: false,
        town: [
          {
            id: 99,
            code: "0102-KAB BEKASI",
            name: "BEKASI (KAB)",
            isDefault: false
          },
          {
            id: 100,
            code: "0108-KAB BOGOR",
            name: "BOGOR (KAB)",
            isDefault: false
          },
          {
            id: 116,
            code: "0198-BEKASI",
            name: "BEKASI (KOTA)",
            isDefault: false
          },
          {
            id: 117,
            code: "0192-BOGOR",
            name: "BOGOR (KOTA)",
            isDefault: false
          },
          {
            id: 120,
            code: "0197-DEPOK",
            name: "DEPOK (KOTA)",
            isDefault: false
          }
        ]
      },
      {
        id: 5,
        code: "1200-JAWA TIMUR",
        name: "JAWA TIMUR",
        isDefault: false,
        town: [
          {
            id: 195,
            code: "1291-SURABAYA",
            name: "SURABAYA (KOTA)",
            isDefault: false
          }
        ]
      }
    ],
    lineOfBusinessGroups: [
      {
        id: 65,
        code: "LOBG1",
        name: "Jasa",
        isDefault: false,
        linesOfBusiness: [
          {
            id: 614,
            code: "47-BIRO PJALANAN >5M",
            name: "Biro Perjalanan Besar",
            isDefault: false
          },
          {
            id: 615,
            code: "48-BIRO PJALANAN <=5M",
            name: "Biro Perjalanan Kecil (≤5M)",
            isDefault: false
          },
          {
            id: 688,
            code: "999-TENAGA KERJA INDONESIA/TKI",
            name: "Tenaga Kerja Indonesia",
            isDefault: false
          },
          {
            id: 616,
            code: "16-JASA PERBANKAN",
            name: "Keuangan (Bank)",
            isDefault: false
          },
          {
            id: 736,
            code: "999-TENAGA KERJA OUTSOURCE",
            name: "Tenaga Kerja Outsource",
            isDefault: false
          },
          {
            id: 689,
            code: "999-KOPERASI",
            name: "Koperasi",
            isDefault: false
          },
          {
            id: 617,
            code: "15-JASA NON BANK",
            name: "Keuangan (Non Bank)",
            isDefault: false
          },
          {
            id: 618,
            code: "49-KONSTRUKSI_OPRATOR >5M",
            name: "Konstruksi dan Operator Besar (>5M)",
            isDefault: false
          },
          {
            id: 737,
            code: "999-LSM POLITIK JURNALISME DAN HUKUM",
            name: "LSM Politik, Jurnalisme, dan Hukum",
            isDefault: false
          },
          {
            id: 619,
            code: "50-KONSTRUKSI_OPRATOR<=5M",
            name: "Konstruksi dan Operator Kecil (<5M)",
            isDefault: false
          },
          {
            id: 738,
            code: "999-NGO INTERNASIONAL DAN LSM YAYASAN SOSIAL PENDIDIKAN KESEHATAN",
            name: "NGO Internasional dan LSM/Yayasan sosial, pendidikan, kesehatan",
            isDefault: false
          },
          {
            id: 620,
            code: "27-JASA PARKIR > 5M",
            name: "Parkir Besar",
            isDefault: false
          },
          {
            id: 621,
            code: "26-JASA PARKIR <=5M",
            name: "Parkir Kecil (≤5M)",
            isDefault: false
          },
          {
            id: 622,
            code: "17-JASA AKUNTAN KONSUL PAJAK",
            name: "Akuntan Publik dan Pajak",
            isDefault: false
          },
          {
            id: 623,
            code: "21-JASA EKSPEDISI",
            name: "Ekspedisi/Pergudangan",
            isDefault: false
          },
          {
            id: 624,
            code: "25-JASA HIBURAN_OLAHRAGA",
            name: "Jasa Sosial, hiburan dan olah raga",
            isDefault: false
          },
          {
            id: 625,
            code: "06-KOMINFOTEK",
            name: "IT",
            isDefault: false
          },
          {
            id: 626,
            code: "23-JASA PERORANGAN RT",
            name: "Jasa Rumah Tangga",
            isDefault: false
          },
          {
            id: 627,
            code: "22-JASA SERV PERAWATAN",
            name: "Service Perbaikan/Perawatan",
            isDefault: false
          },
          {
            id: 628,
            code: "54-KESEHATAN_RUMAH SAKIT",
            name: "Kesehatan/Rumah Sakit",
            isDefault: false
          },
          {
            id: 629,
            code: "19-JASA KONSUL PERUSAHAAN",
            name: "Konsultan Perusahaan",
            isDefault: false
          },
          {
            id: 630,
            code: "05-PENDIDIKAN_PELATIHAN",
            name: "Pendidikan/Pelatihan/Penelitian",
            isDefault: false
          },
          {
            id: 631,
            code: "53-PENYIARAN_PERCETAKAN",
            name: "Penyiaran/Percetakan",
            isDefault: false
          },
          {
            id: 632,
            code: "24-JASA SOSIAL_AGAMA",
            name: "Sosial/Agama",
            isDefault: false
          },
          {
            id: 633,
            code: "20-JASA TRANSPORTASI",
            name: "Transportasi",
            isDefault: false
          },
          {
            id: 634,
            code: "28-JASA LAIN",
            name: "Lainnya",
            isDefault: false
          }
        ]
      },
      {
        id: 66,
        code: "LOBG2",
        name: "Manufaktur",
        isDefault: false,
        linesOfBusiness: [
          {
            id: 635,
            code: "34-MANUFAK ALAT TRANSPOR",
            name: "Alat Transportasi/Mesin",
            isDefault: false
          },
          {
            id: 636,
            code: "32-MANUFAK ELEKTRONIK",
            name: "Elektronik",
            isDefault: false
          },
          {
            id: 637,
            code: "35-MANUFAK KIMIA_FARMASI",
            name: "Farmasi",
            isDefault: false
          },
          {
            id: 638,
            code: "30-MANUFAKTUR KULIT",
            name: "Kulit",
            isDefault: false
          },
          {
            id: 639,
            code: "33-MANUFAK LOGAM",
            name: "Logam",
            isDefault: false
          },
          {
            id: 640,
            code: "37-MANUFAK MAKANAN_MINUM",
            name: "Makanan Minuman",
            isDefault: false
          },
          {
            id: 641,
            code: "36-MANUFAK ALAT KANTOR_RT",
            name: "Peralatan Kantor/Rumah Tangga",
            isDefault: false
          },
          {
            id: 642,
            code: "29-MANUFAK PLASTIK_KARET",
            name: "Plastik/Karet",
            isDefault: false
          },
          {
            id: 643,
            code: "31-MANUFAK KAYU_FURN",
            name: "Produk/Perabotan Kayu",
            isDefault: false
          },
          {
            id: 644,
            code: "39-MANUFAK TEKSTIL",
            name: "Tekstil",
            isDefault: false
          },
          {
            id: 645,
            code: "38-MANUFAK MIRAS_TEMBAKAU",
            name: "Miras dan Tembakau",
            isDefault: false
          },
          {
            id: 646,
            code: "40-MANUFAKTUR LAIN",
            name: "Lainnya",
            isDefault: false
          }
        ]
      },
      {
        id: 67,
        code: "LOBG3",
        name: "Perdagangan",
        isDefault: false,
        linesOfBusiness: [
          {
            id: 647,
            code: "14-DEALER_SENI_ANTIK >5M",
            name: "Dealer Kendaraan/Seni Besar",
            isDefault: false
          },
          {
            id: 648,
            code: "13-DEALER_SHOWROOM <=5M",
            name: "Dealer/Showroom kecil (≤5M)",
            isDefault: false
          },
          {
            id: 649,
            code: "12-EKSPOR IMPOR >5M",
            name: "Ekspor Impor Besar",
            isDefault: false
          },
          {
            id: 650,
            code: "11-EKSPOR IMPOR <=5M",
            name: "Ekspor Impor Kecil (≤5M)",
            isDefault: false
          },
          {
            id: 651,
            code: "61-ISI PULSA >5M",
            name: "Pedagang Isi Pulsa Besar",
            isDefault: false
          },
          {
            id: 652,
            code: "62-ISI PULSA UP <=5M",
            name: "Pedagang Isi Pulsa (≤5M)",
            isDefault: false
          },
          {
            id: 653,
            code: "07-RESTO_HOTEL_WISATA>5M",
            name: "Resto/Hotel/Wisata Besar",
            isDefault: false
          },
          {
            id: 654,
            code: "08-RESTO_HOTEL_WISATA<=5M",
            name: "Resto/Hotel/Wisata Kecil (≤5M)",
            isDefault: false
          },
          {
            id: 655,
            code: "10-ECER_SUPRMKT_GROS >5M",
            name: "Ritel Besar",
            isDefault: false
          },
          {
            id: 656,
            code: "09-ECER_SUPERMKT_GROS<=5M",
            name: "Ritel Kecil (≤5M)",
            isDefault: false
          },
          {
            id: 657,
            code: "63-ONLINE SHOP >5M",
            name: "Toko Online Besar",
            isDefault: false
          },
          {
            id: 658,
            code: "64-ONLINE SHOP <=5M",
            name: "Toko Online Kecil (≤5M)",
            isDefault: false
          },
          {
            id: 659,
            code: "60-MULTI LEVEL MARKETING",
            name: "Multi Level Marketing",
            isDefault: false
          },
          {
            id: 660,
            code: "57-PERHIASAN",
            name: "Perhiasan",
            isDefault: false
          },
          {
            id: 661,
            code: "56-POM BENSIN",
            name: "SPBU",
            isDefault: false
          },
          {
            id: 662,
            code: "51-PERDAGANGAN LAIN",
            name: "Lainnya",
            isDefault: false
          }
        ]
      },
      {
        id: 68,
        code: "LOBG4",
        name: "Lainnya",
        isDefault: false,
        linesOfBusiness: [
          {
            id: 663,
            code: "72-DIN KESEHATAN GOL IV",
            name: "Dinas Kesehatan Gol ≥ IV",
            isDefault: false
          },
          {
            id: 664,
            code: "71-DIN PENDIDIKAN GOL IV",
            name: "Dinas Pendidikan Gol ≥ IV",
            isDefault: false
          },
          {
            id: 665,
            code: "44-HUTAN_TEBANG KAYU",
            name: "Kehutanan dan Tebang Kayu",
            isDefault: false
          },
          {
            id: 666,
            code: "59-BALAI LELANG_GADAI",
            name: "Lelang/Gadai",
            isDefault: false
          },
          {
            id: 690,
            code: "999-PERSENJATAAN/SENJATA PERANG",
            name: "Persenjataan/Senjata Perang/Bahan Peledak",
            isDefault: false
          },
          {
            id: 667,
            code: "55-LISTRIK_GAS_AIR",
            name: "Listrik/Gas/Air",
            isDefault: false
          },
          {
            id: 668,
            code: "58-MONEY CHANGER",
            name: "Money Changer",
            isDefault: false
          },
          {
            id: 692,
            code: "999-PENGEBORAN LEPAS PANTAI DAN TEKNISI PERTAMBANGAN OFFSITE",
            name: "Pekerja Teknisi Pertambangan, Minyak & Gas Lepas Pantai",
            isDefault: false
          },
          {
            id: 669,
            code: "45-TERNAK_IKAN",
            name: "Perikanan",
            isDefault: false
          },
          {
            id: 693,
            code: "999-PENGEBORAN BUKAN LEPAS PANTAI ATAU TEKNISI PERTAMBANGAN ONSITE",
            name: "Pekerja Teknisi Pertambangan, Minyak & Gas Bukan Lepas Pantai",
            isDefault: false
          },
          {
            id: 670,
            code: "43-TANI_KEBUN_BURU_TAMAN",
            name: "Pertanian/Perkebunan",
            isDefault: false
          },
          {
            id: 671,
            code: "52-REAL ESTATE_SEWA",
            name: "Real Estate/Sewa Properti",
            isDefault: false
          },
          {
            id: 672,
            code: "41-TAMBANG ENERGI",
            name: "Tambang Energi",
            isDefault: false
          },
          {
            id: 673,
            code: "42-TAMBANG NON ENERGI",
            name: "Tambang Non Energi",
            isDefault: false
          },
          {
            id: 739,
            code: "999-PUSAT HIBURAN ANAK KELUARGA OLAHRAGA",
            name: "Pusat Hiburan anak/keluarga/olahraga",
            isDefault: false
          },
          {
            id: 740,
            code: "999-SPA MASSAGE KARAOKE DEWASA DISKOTIK",
            name: "Spa/massage, karaoke dewasa, diskotik",
            isDefault: false
          }
        ]
      }
    ],
    gender: [
      {
        id: 79,
        code: "O",
        name: "Tidak terdefinisi",
        isDefault: false
      },
      {
        id: 80,
        code: "M",
        name: "Laki - laki",
        isDefault: false
      },
      {
        id: 81,
        code: "F",
        name: "Perempuan",
        isDefault: false
      }
    ],
    loanPurpose: [
      {
        id: 708,
        code: "89",
        name: "Pendidikan",
        isDefault: false
      },
      {
        id: 709,
        code: "89",
        name: "Pernikahan",
        isDefault: false
      },
      {
        id: 710,
        code: "85",
        name: "Renovasi",
        isDefault: false
      },
      {
        id: 711,
        code: "89",
        name: "Liburan",
        isDefault: false
      },
      {
        id: 712,
        code: "89",
        name: "Konsumtif",
        isDefault: false
      }
    ],
    relationship: [
      {
        id: 713,
        code: "999-ORANG TUA",
        name: "Orang Tua",
        isDefault: false
      },
      {
        id: 714,
        code: "999-SAUDARA KANDUNG",
        name: "Saudara Kandung",
        isDefault: false
      },
      {
        id: 715,
        code: "999-SUAMI/ISTRI",
        name: "Suami/Istri",
        isDefault: false
      },
      {
        id: 716,
        code: "999-KERABAT LAIN",
        name: "Kerabat Lain",
        isDefault: false
      }
    ],
    occupations: [
      {
        id: 34,
        code: "M01-KARYAWAN",
        name: "Karyawan, Pegawai, Pensiunan",
        isDefault: false,
        jobTitles: [
          {
            id: 581,
            code: "SENIOR MANAJEMEN",
            name: "Swasta - Pejabat Eksekutif",
            isDefault: false
          },
          {
            id: 583,
            code: "STAFF",
            name: "Karyawan Swasta",
            isDefault: false
          },
          {
            id: 717,
            code: "DRIVER TRANSPORTASI ONLINE",
            name: "Driver Transportasi Online",
            isDefault: false
          },
          {
            id: 718,
            code: "KARYAWAN TRANSPORTASI",
            name: "Karyawan Transportasi",
            isDefault: false
          }
        ]
      },
      {
        id: 35,
        code: "M06-KARYAWAN BUMN",
        name: "Karyawan, Pegawai, Pensiunan",
        isDefault: false,
        jobTitles: [
          {
            id: 584,
            code: "KARYAWAN BUMN/BUMD/BHMN",
            name: "BUMN/ BUMD",
            isDefault: false
          }
        ]
      },
      {
        id: 36,
        code: "M07-PEGAWAI PEMERINTAH",
        name: "Karyawan, Pegawai, Pensiunan",
        isDefault: false,
        jobTitles: [
          {
            id: 585,
            code: "PEGAWAI PEMERINTAH  ( HONORER S/D GOL III)",
            name: "PNS Golongan",
            isDefault: true
          }
        ]
      },
      {
        id: 37,
        code: "M08-PEGAWAI NON GOLONGAN",
        name: "Karyawan, Pegawai, Pensiunan",
        isDefault: false,
        jobTitles: [
          {
            id: 587,
            code: "PEGAWAI NON GOLONGAN  ( HONORER S/D GOL III)",
            name: "PNS Non Golongan",
            isDefault: true
          }
        ]
      },
      {
        id: 38,
        code: "H13-KARYAWAN KPP BEACUKAI",
        name: "Karyawan, Pegawai, Pensiunan",
        isDefault: false,
        jobTitles: [
          {
            id: 586,
            code: "KARYAWAN KPP/BEACUKAI",
            name: "Pajak & Bea Cukai",
            isDefault: true
          }
        ]
      },
      {
        id: 39,
        code: "L01-GURU_DOSEN_INSTRUKTUR",
        name: "Wirausaha & Profesional",
        isDefault: false,
        jobTitles: [
          {
            id: 588,
            code: "GURU/DOSEN/INSTRUKTUR",
            name: "Guru/Dosen/Instruktur",
            isDefault: true
          }
        ]
      },
      {
        id: 40,
        code: "L02-DOKTER",
        name: "Wirausaha & Profesional",
        isDefault: false,
        jobTitles: [
          {
            id: 589,
            code: "DOKTER",
            name: "Dokter",
            isDefault: true
          }
        ]
      },
      {
        id: 41,
        code: "M02-WIRAUSAHA",
        name: "Wirausaha & Profesional",
        isDefault: false,
        jobTitles: [
          {
            id: 590,
            code: "WIRAUSAHA",
            name: "Wirausaha lainnya",
            isDefault: false
          },
          {
            id: 719,
            code: "WIRAUSAHA BIRO PERJALANAN UNDER 5M",
            name: "Wirausaha Biro Perjalanan (omset <5M/ thn)",
            isDefault: true
          },
          {
            id: 720,
            code: "WIRAUSAHA KONSTRUKSI UNDER 5M",
            name: "Wirausaha konstruksi (omset <5M/ thn)",
            isDefault: true
          },
          {
            id: 721,
            code: "WIRAUSAHA EKSPEDISI/PERGUDANGAN",
            name: "Wirausaha ekspedisi/ pergudangan",
            isDefault: true
          },
          {
            id: 722,
            code: "WIRAUSAHA BIDANG IT",
            name: "Wirausaha bidang IT",
            isDefault: true
          },
          {
            id: 723,
            code: "WIRAUSAHA JASA RUMAH TANGGA",
            name: "Wirausaha jasa rumah tangga",
            isDefault: true
          },
          {
            id: 724,
            code: "WIRAUSAHA PRODUKSI MAKANAN AND MINUMAN NON ALKOHOL",
            name: "Wirausaha produksi makanan & minuman non alkohol",
            isDefault: true
          },
          {
            id: 725,
            code: "WIRAUSAHA TEKSTIL",
            name: "Wirausaha tekstil",
            isDefault: true
          },
          {
            id: 726,
            code: "WIRAUSAHA DEALER KENDARAAN OMSET UNDER 5M",
            name: "Wirausaha dealer kendaraan (omset <5M/ thn)",
            isDefault: true
          },
          {
            id: 727,
            code: "WIRAUSAHA PEDAGANG ISI PULSA OMSET UNDER 5M",
            name: "Wirausaha pedagang isi pulsa (omset <5M/ thn)",
            isDefault: true
          },
          {
            id: 728,
            code: "WIRAUSAHA RESTORAN OMSET UNDER 5M",
            name: "Wirausaha restoran (omset <5M/ thn)",
            isDefault: true
          },
          {
            id: 729,
            code: "WIRAUSAHA RITEL OMSET UNDER 5M TERMASUK APOTEK SEMBAKO KELONTONG",
            name: "Wirausaha ritel (omset <5M/ thn) termasuk apotek, toko sembako/ kelontong",
            isDefault: true
          },
          {
            id: 730,
            code: "WIRAUSAHA ONLINE OMSET UNDER 5M",
            name: "Wirausaha online (omset <5M/ thn)",
            isDefault: true
          },
          {
            id: 731,
            code: "WIRAUSAHA PERDAGANGAN SARANG BURUNG WALET",
            name: "Wirausaha perdagangan sarang burung walet",
            isDefault: true
          },
          {
            id: 732,
            code: "WIRAUSAHA PERDAGANGAN KOMPUTER NON ONLINE",
            name: "Wirausaha perdagangan komputer non online",
            isDefault: true
          }
        ]
      },
      {
        id: 42,
        code: "M11-WARTAWAN",
        name: "Wartawan, Artis, Atlet",
        isDefault: false,
        jobTitles: [
          {
            id: 591,
            code: "WARTAWAN",
            name: "Wartawan",
            isDefault: true
          }
        ]
      },
      {
        id: 43,
        code: "M12-SOSIAL SENI OLAHRAGA",
        name: "Wartawan, Artis, Atlet",
        isDefault: false,
        jobTitles: [
          {
            id: 733,
            code: "PEKERJA SOSIAL",
            name: "Pekerja Sosial",
            isDefault: true
          },
          {
            id: 734,
            code: "ARTIS",
            name: "Artis",
            isDefault: true
          },
          {
            id: 735,
            code: "ATLET",
            name: "Atlet",
            isDefault: true
          }
        ]
      },
      {
        id: 44,
        code: "M05-PENSIUNAN",
        name: "Karyawan, Pegawai, Pensiunan",
        isDefault: false,
        jobTitles: [
          {
            id: 593,
            code: "PENSIUNAN",
            name: "Pensiunan",
            isDefault: false
          }
        ]
      },
      {
        id: 45,
        code: "M09-ANGGOTA MILITER",
        name: "Militer & Kepolisian",
        isDefault: false,
        jobTitles: [
          {
            id: 594,
            code: "PERWIRA PERTAMA MILITER",
            name: "Perwira Pertama Militer",
            isDefault: true
          }
        ]
      },
      {
        id: 46,
        code: "M10-ANGGOTA KEPOLISIAN",
        name: "Militer & Kepolisian",
        isDefault: false,
        jobTitles: [
          {
            id: 595,
            code: "PERWIRA PERTAMA KEPOLISIAN",
            name: "Perwira Pertama Kepolisian",
            isDefault: true
          }
        ]
      },
      {
        id: 47,
        code: "H04-PEJABAT MILITER",
        name: "Militer & Kepolisian",
        isDefault: false,
        jobTitles: [
          {
            id: 596,
            code: "PEJABAT MILITER",
            name: "Perwira Menengah/Tinggi Militer",
            isDefault: true
          }
        ]
      },
      {
        id: 48,
        code: "H05-PEJABAT KEPOLISIAN",
        name: "Militer & Kepolisian",
        isDefault: false,
        jobTitles: [
          {
            id: 597,
            code: "PEJABAT KEPOLISIAN",
            name: "Perwira Menengah/Tinggi Kepolisian",
            isDefault: true
          }
        ]
      },
      {
        id: 52,
        code: "H01-PEJABAT BUMN",
        name:
          "Pejabat Negara/BUMN/Non Golongan, Pekerja Hukum, Pengurus Parpol, Broker, Pemuka Agama, Anggota Legislatif",
        isDefault: false,
        jobTitles: [
          {
            id: 601,
            code: "PEJABAT BUMN",
            name: "Pejabat BUMN",
            isDefault: true
          }
        ]
      },
      {
        id: 53,
        code: "H02-PEJABAT PEMERINTAH",
        name:
          "Pejabat Negara/BUMN/Non Golongan, Pekerja Hukum, Pengurus Parpol, Broker, Pemuka Agama, Anggota Legislatif",
        isDefault: false,
        jobTitles: [
          {
            id: 602,
            code: "PEJABAT PEMERINTAH",
            name: "Pejabat Pemerintah",
            isDefault: true
          }
        ]
      },
      {
        id: 54,
        code: "H03-PEJABAT NON GOLONGAN",
        name:
          "Pejabat Negara/BUMN/Non Golongan, Pekerja Hukum, Pengurus Parpol, Broker, Pemuka Agama, Anggota Legislatif",
        isDefault: false,
        jobTitles: [
          {
            id: 603,
            code: "PEJABAT NON GOLONGAN",
            name: "Pejabat Non Golongan",
            isDefault: true
          }
        ]
      },
      {
        id: 55,
        code: "H06-PENGACARA",
        name:
          "Pejabat Negara/BUMN/Non Golongan, Pekerja Hukum, Pengurus Parpol, Broker, Pemuka Agama, Anggota Legislatif",
        isDefault: false,
        jobTitles: [
          {
            id: 604,
            code: "PENGACARA",
            name: "Pengacara",
            isDefault: true
          }
        ]
      },
      {
        id: 56,
        code: "H07-KEJAKSAAN",
        name:
          "Pejabat Negara/BUMN/Non Golongan, Pekerja Hukum, Pengurus Parpol, Broker, Pemuka Agama, Anggota Legislatif",
        isDefault: false,
        jobTitles: [
          {
            id: 605,
            code: "KEJAKSAAN",
            name: "Kejaksaan",
            isDefault: true
          }
        ]
      },
      {
        id: 57,
        code: "H08-HAKIM",
        name:
          "Pejabat Negara/BUMN/Non Golongan, Pekerja Hukum, Pengurus Parpol, Broker, Pemuka Agama, Anggota Legislatif",
        isDefault: false,
        jobTitles: [
          {
            id: 606,
            code: "HAKIM",
            name: "Hakim",
            isDefault: true
          }
        ]
      },
      {
        id: 58,
        code: "H09-NOTARIS",
        name:
          "Pejabat Negara/BUMN/Non Golongan, Pekerja Hukum, Pengurus Parpol, Broker, Pemuka Agama, Anggota Legislatif",
        isDefault: false,
        jobTitles: [
          {
            id: 607,
            code: "NOTARIS",
            name: "Notaris",
            isDefault: true
          }
        ]
      },
      {
        id: 59,
        code: "H10-ANGGOTA LEGISLATIF",
        name:
          "Pejabat Negara/BUMN/Non Golongan, Pekerja Hukum, Pengurus Parpol, Broker, Pemuka Agama, Anggota Legislatif",
        isDefault: false,
        jobTitles: [
          {
            id: 608,
            code: "ANGGOTA LEGISLATIF",
            name: "Anggota Legislatif",
            isDefault: true
          }
        ]
      },
      {
        id: 60,
        code: "H11-PENGURUS PARPOL",
        name:
          "Pejabat Negara/BUMN/Non Golongan, Pekerja Hukum, Pengurus Parpol, Broker, Pemuka Agama, Anggota Legislatif",
        isDefault: false,
        jobTitles: [
          {
            id: 609,
            code: "PENGURUS PARPOL",
            name: "Pengurus Parpol",
            isDefault: true
          }
        ]
      },
      {
        id: 61,
        code: "H12-AUDITOR PENGAWAS",
        name:
          "Pejabat Negara/BUMN/Non Golongan, Pekerja Hukum, Pengurus Parpol, Broker, Pemuka Agama, Anggota Legislatif",
        isDefault: false,
        jobTitles: [
          {
            id: 610,
            code: "AUDITOR PENGAWAS",
            name: "Auditor Pengawas",
            isDefault: true
          }
        ]
      },
      {
        id: 62,
        code: "H14-BROKER AGENT",
        name:
          "Pejabat Negara/BUMN/Non Golongan, Pekerja Hukum, Pengurus Parpol, Broker, Pemuka Agama, Anggota Legislatif",
        isDefault: false,
        jobTitles: [
          {
            id: 611,
            code: "BROKER AGEN",
            name: "Broker/Agen",
            isDefault: true
          }
        ]
      },
      {
        id: 63,
        code: "H15-DUTA BESAR DIPLOMATIK",
        name:
          "Pejabat Negara/BUMN/Non Golongan, Pekerja Hukum, Pengurus Parpol, Broker, Pemuka Agama, Anggota Legislatif",
        isDefault: false,
        jobTitles: [
          {
            id: 612,
            code: "DUTA BESAR DIPLOMATIK",
            name: "Duta Besar Diplomatik",
            isDefault: true
          }
        ]
      },
      {
        id: 64,
        code: "H16-PEMUKA AGAMA",
        name:
          "Pejabat Negara/BUMN/Non Golongan, Pekerja Hukum, Pengurus Parpol, Broker, Pemuka Agama, Anggota Legislatif",
        isDefault: false,
        jobTitles: [
          {
            id: 613,
            code: "PEMUKA AGAMA",
            name: "Pemuka Agama",
            isDefault: true
          }
        ]
      },
      {
        id: 694,
        code: "999-PELAUT",
        name: "Pelaut",
        isDefault: false,
        jobTitles: [
          {
            id: 695,
            code: "999-PELAUT / KAPTEN KAPAL",
            name: "Pelaut / Kapten Kapal",
            isDefault: false
          }
        ]
      },
      {
        id: 696,
        code: "999-STAFF COLLECTION",
        name: "Karyawan, Pegawai, Pensiunan",
        isDefault: false,
        jobTitles: [
          {
            id: 697,
            code: "999-STAFF COLLECTION/PENAGIH HUTANG",
            name: "Debt Collector/Penagih Hutang",
            isDefault: false
          }
        ]
      }
    ],
    maritalStatus: [
      {
        id: 76,
        code: "B",
        name: "Belum Kawin",
        isDefault: false
      },
      {
        id: 77,
        code: "K",
        name: "Kawin",
        isDefault: false
      },
      {
        id: 78,
        code: "J",
        name: "Janda/Duda",
        isDefault: false
      }
    ]
  },
  lastFetched: 1533874998290
};
