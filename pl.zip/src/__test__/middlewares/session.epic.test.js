import configureMockStore from 'redux-mock-store'
import { createEpicMiddleware } from 'redux-observable'
import Rx from 'rxjs/Rx'

import revokeCustomerSessionEpic from '../../middlewares/session.epic'
import SessionService from '../../services/session.service'
import '../setupTests'
import ActionFactory from '../../actions/actionFactory'
import ActionType from '../../actions/actionType'

const epicMiddlewares = createEpicMiddleware(revokeCustomerSessionEpic)
const mockStore = configureMockStore([epicMiddlewares])

jest.mock('../../services/session.service')
describe('Test revoke customer session', () => {
  let store

  beforeEach(() => {
    store = mockStore({customerSubmitLoanResponse: {customerSession: {accessToken: '1234'}}})
  })

  it('Try to revoke customer session and no expect response', () => {
    let revokeCustomerSession = jest.fn(() => Rx.Observable.of({data: {configurations: {}}}))
    SessionService.mockImplementation(() => ({
      revokeCustomerSession: revokeCustomerSession
    }))

    store.dispatch(ActionFactory.create(ActionType.REVOKE_CUSTOMER_SESSION, {
      method: 'WEB',
      sessionKey: '1234'
    }))

    expect(revokeCustomerSession).toHaveBeenCalled()
  })
})
