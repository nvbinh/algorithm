import configureMockStore from 'redux-mock-store'
import { createEpicMiddleware } from 'redux-observable'
import Rx from 'rxjs/Rx'
import ActionType from '../../actions/actionType'
import ActionFactory from '../../actions/actionFactory'

import '../setupTests'
import getLOVMappingEpic from '../../middlewares/lovMapping.epic'
import AppService from '../../services/app.service'

const epicMiddlewares = createEpicMiddleware(getLOVMappingEpic)
const mockStore = configureMockStore([epicMiddlewares])
const getLovMappingResponse = {
  "data": {
    "jobTitles": []
  }
}

jest.mock('../../services/app.service')
AppService.mockImplementation(() => ({
  getLOVMapping: () => Rx.Observable.of(getLovMappingResponse)
}))

describe('getLOVMapping async action', () => {
  let store

  beforeEach(() => {
    store = mockStore({getLovMappingResponse: {}})
  })

  afterEach(() => {
    epicMiddlewares.replaceEpic(getLOVMappingEpic)
  })

  it('should dispatch action GET_LOV_REQUEST_SUCCESS', () => {

    // Act
    store.dispatch(ActionFactory.ofType(ActionType.GET_LOV_MAPPING))

    // Assert
    expect(store.getActions()[0]).not.toBeFalsy()
    expect(store.getActions()[1]['payload']).not.toBeNull()
    expect(store.getActions()[1]['payload']).not.toBeUndefined()
    expect(store.getActions()[1]['payload']).not.toEqual({})
  })
})

