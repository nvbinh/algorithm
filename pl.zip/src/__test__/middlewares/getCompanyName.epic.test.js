import configureMockStore from 'redux-mock-store'
import {createEpicMiddleware} from 'redux-observable'
import Rx from 'rxjs/Rx'

import getCompanyNameEpic from '../../middlewares/getCompanyNameEpic'
import CompanyNameService from '../../services/companyNameService'
import '../setupTests'
import ActionFactory from "../../actions/actionFactory"
import ActionType from "../../actions/actionType"

const epicMiddlewares = createEpicMiddleware(getCompanyNameEpic)
const mockStore = configureMockStore([epicMiddlewares])

jest.mock('../../services/companyNameService')
jest.useFakeTimers()

const responseSuccess = {
  "data": [
    {
      "id": "1",
      "name": "Amsterdam",
      "score": 19.162907
    },
    {
      "id": "2",
      "name": "Amstelveen",
      "score": 19.162907
    },
    {
      "id": "3",
      "name": "Ouderkerk aan de Amstel",
      "score": 9.581453
    }
  ],
  "errors": [],
  "warnings": [],
  "success": true
}

describe('Test get company name', () => {
  let store

  beforeEach(() => {
    store = mockStore({getConfigurationsAPIResponse: {configurations: {limitedRecordSearchingCompany: 10}}})
  })

  it('Try to revoke customer session and no expect response', () => {
    CompanyNameService.mockImplementation(() => ({
      getCompanyName: () => {
        return Rx.Observable.of(responseSuccess)
      }
    }))

    let expected = [{meta: undefined, payload: {}, type: 'GET_COMPANY_NAME'}, {
      meta: undefined,
      payload: {
        data: [
          {
            id: '1',
            name: 'Amsterdam',
            score: 19.162907
          },
          {
            id: '2',
            name: 'Amstelveen',
            score: 19.162907
          },
          {
            id: '3',
            name: 'Ouderkerk aan de Amstel',
            score: 9.581453
          }
        ]
      },
      type: 'GET_COMPANY_NAME_DONE'
    }]

    store.dispatch(ActionFactory.create(ActionType.GET_COMPANY_NAME, {}))
    jest.runOnlyPendingTimers()
    expect(store.getActions()).toEqual(expected)
  })
})


