import configureMockStore from "redux-mock-store";
import { createEpicMiddleware } from "redux-observable";
import Rx from "rxjs/Rx";
import ActionType from "../../actions/actionType";
import ActionFactory from "../../actions/actionFactory";

import "../setupTests";
import getLOVEpic from "../../middlewares/lov.epic";
import AppService from "../../services/app.service";

const epicMiddlewares = createEpicMiddleware(getLOVEpic);
const mockStore = configureMockStore([epicMiddlewares]);
const getLOVAPIResponse = {
  data: {
    ownerStatus: [
      {
        id: 82,
        code: "OWNER",
        name: "Owner"
      }
    ],
    province: [
      {
        id: 1,
        code: "0300-DKI JAYA",
        name: "JAKARTA",
        town: [
          {
            id: 83,
            code: "0393-JAKARTA BARAT",
            name: "JAKARTA BARAT"
          },
          {
            id: 84,
            code: "0391-JAKARTA PUSAT",
            name: "JAKARTA PUSAT"
          },
          {
            id: 85,
            code: "0394-JAKARTA SELATAN",
            name: "JAKARTA SELATAN"
          },
          {
            id: 86,
            code: "0395-JAKARTA TIMUR",
            name: "JAKARTA TIMUR"
          },
          {
            id: 87,
            code: "0392-JAKARTA UTARA",
            name: "JAKARTA UTARA"
          },
          {
            id: 88,
            code: "0396-KEPULAUAN SERIBU",
            name: "KEPULAUAN SERIBU"
          }
        ]
      },
      {
        id: 2,
        code: "0200-BANTEN",
        name: "BANTEN",
        town: [
          {
            id: 92,
            code: "0204-KAB TANGERANG",
            name: "TANGERANG (KAB)"
          },
          {
            id: 95,
            code: "0292-TANGERANG",
            name: "TANGERANG (KOTA)"
          }
        ]
      },
      {
        id: 3,
        code: "0100-JAWA BARAT",
        name: "JAWA BARAT",
        town: [
          {
            id: 99,
            code: "0102-KAB BEKASI",
            name: "BEKASI (KAB)"
          },
          {
            id: 100,
            code: "0108-KAB BOGOR",
            name: "BOGOR (KAB)"
          },
          {
            id: 116,
            code: "0198-BEKASI",
            name: "BEKASI (KOTA)"
          },
          {
            id: 117,
            code: "0192-BOGOR",
            name: "BOGOR (KOTA)"
          },
          {
            id: 120,
            code: "0197-DEPOK",
            name: "DEPOK (KOTA)"
          }
        ]
      },
      {
        id: 5,
        code: "1200-JAWA TIMUR",
        name: "JAWA TIMUR",
        town: [
          {
            id: 195,
            code: "1291-SURABAYA",
            name: "SURABAYA (KOTA)"
          }
        ]
      }
    ],
    lineOfBusinessGroups: [
      {
        id: 65,
        code: "LOBG1",
        name: "Jasa",
        linesOfBusiness: [
          {
            id: 614,
            code: "47-BIRO PJALANAN >5M",
            name: "Biro Perjalanan Besar"
          },
          {
            id: 615,
            code: "48-BIRO PJALANAN <=5M",
            name: "Biro Perjalanan Kecil (≤5M)"
          },
          {
            id: 616,
            code: "16-JASA PERBANKAN",
            name: "Keuangan (Bank)"
          },
          {
            id: 617,
            code: "15-JASA NON BANK",
            name: "Keuangan (Non Bank)"
          },
          {
            id: 634,
            code: "28-JASA LAIN",
            name: "Lainnya"
          }
        ]
      }
    ],
    gender: [
      {
        id: 79,
        code: "O",
        name: "Tidak terdefinisi"
      },
      {
        id: 80,
        code: "M",
        name: "Laki - laki"
      },
      {
        id: 81,
        code: "F",
        name: "Perempuan"
      }
    ],
    loanPurpose: [
      {
        id: 69,
        code: "PENDIDIKAN",
        name: "Pendidikan"
      },
      {
        id: 70,
        code: "PERNIKAHAN",
        name: "Pernikahan"
      },
      {
        id: 71,
        code: "RENOVASI",
        name: "Renovasi"
      },
      {
        id: 72,
        code: "ELEKTRONIK",
        name: "Elektronik"
      },
      {
        id: 73,
        code: "LIBURAN",
        name: "Liburan"
      },
      {
        id: 74,
        code: "PENGOBATAN",
        name: "Pengobatan"
      },
      {
        id: 75,
        code: "LAINNYA",
        name: "Lainnya"
      }
    ],
    occupations: [
      {
        id: 34,
        code: "M01-KARYAWAN",
        name: "Karyawan, Pegawai, Pensiunan",
        jobTitles: [
          {
            id: 581,
            code: "SENIOR MANAJEMEN",
            name: "Swasta - Manajemen Senior/Pejabat Eksekutif Bank"
          },
          {
            id: 582,
            code: "MANAGER",
            name: "Swasta - Manajer"
          },
          {
            id: 583,
            code: "STAFF",
            name: "Swasta - Staf"
          }
        ]
      }
    ],
    maritalStatus: [
      {
        id: 76,
        code: "B",
        name: "Belum Kawin"
      },
      {
        id: 77,
        code: "K",
        name: "Kawin"
      },
      {
        id: 78,
        code: "J",
        name: "Janda/Duda"
      }
    ]
  },
  lastFetched: 1508483907223
};

jest.mock("../../services/app.service");
AppService.mockImplementation(() => ({
  getLOV: () => Rx.Observable.of(getLOVAPIResponse)
}));

describe("getLOV async action", () => {
  let store;

  beforeEach(() => {
    store = mockStore({ getLOVAPIResponse: {} });
  });

  afterEach(() => {
    epicMiddlewares.replaceEpic(getLOVEpic);
  });

  it("should dispatch action GET_LOV_REQUEST_SUCCESS", () => {
    // Act
    store.dispatch(ActionFactory.ofType(ActionType.GET_LOV));

    // Assert
    expect(store.getActions()[0]).not.toBeFalsy();
    expect(store.getActions()[1]["payload"]).not.toBeNull();
    expect(store.getActions()[1]["payload"]).not.toBeUndefined();
    expect(store.getActions()[1]["payload"]).not.toEqual({});
  });
});
