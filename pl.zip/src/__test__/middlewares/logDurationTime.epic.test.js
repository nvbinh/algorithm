import configureMockStore from 'redux-mock-store'
import { createEpicMiddleware } from 'redux-observable'
import Rx from 'rxjs/Rx'

import { logDurationTimeToServer } from '../../actions/actionCreator'
import logDurationTimeEpic from '../../middlewares/logDurationTime.epic'
import AppService from '../../services/app.service'
import '../setupTests'

const epicMiddlewares = createEpicMiddleware(logDurationTimeEpic)
const mockStore = configureMockStore([epicMiddlewares])

jest.mock('../../services/app.service')

describe('Invoking the screen duration API to log the duration time page', () => {
  let store

  beforeEach(() => {
    store = mockStore({
      customerSubmitLoanResponse: {
        customerId: '123456789',
        customerSession: {accessToken: '123456789'}
      },
      timeTracking: {},
    })

    AppService.mockClear();
  })

  afterEach(() => {
    epicMiddlewares.replaceEpic(logDurationTimeEpic)
  })

  it('Invoke log time API success', () => {
    AppService.mockImplementation(() => ({
      logDurationTime: () => Rx.Observable.of('response')
    }))

    const expected = [
      {
        ...logDurationTimeToServer(),
        payload: void 0
      }
    ]

    store.dispatch(logDurationTimeToServer())

    expect(store.getActions()).toEqual(expected)
  })
})
