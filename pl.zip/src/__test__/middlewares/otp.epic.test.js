import configureMockStore from 'redux-mock-store'
import { createEpicMiddleware } from 'redux-observable'
import Rx from 'rxjs/Rx'
import { combineEpics } from 'redux-observable'

import {
  getOtp,
  getOtpSuccess,
  getOtpFail,
  validateOtp,
  validateOtpSuccess,
  validateOtpFail
} from '../../actions/actionCreator'
import { generateOtpEpic, validateOtpEpic } from '../../middlewares/otp'
import OtpService from '../../services/otp'

const rootEpic = combineEpics(generateOtpEpic, validateOtpEpic)
const epicMiddlewares = createEpicMiddleware(rootEpic)
const mockStore = configureMockStore([epicMiddlewares])

jest.mock('../../services/otp')

describe('generate OTP', () => {
  let store

  beforeEach(() => {
    store = mockStore({
      customerSubmitLoanResponse: {
        customerId: '',
        customerSession: {
          applicationNumber: '123456789',
          accessToken: '123456789'
        }
      },
      getConfigurationsAPIResponse: {configurations: {otpTemplate: 'template'}},
      form: {customerPersonalInformation: {values: {phoneNumber: '123456789'}}}
    })
  })

  afterEach(() => {
    epicMiddlewares.replaceEpic(generateOtpEpic)
  })

  it('generate OTP success', () => {
    OtpService.mockImplementation(() => ({
      generateOtp: () => Rx.Observable.of(generateOtpSuccessResponse)
    }))

    const expected = [
      {
        ...getOtp(),
        payload: void 0,
        meta: void 0
      },
      {
        ...getOtpSuccess(),
        payload: null,
        meta: void 0
      }
    ]

    store.dispatch(getOtp())

    expect(store.getActions()).toEqual(expected)
  })

  it('generate OTP error', () => {
    OtpService.mockImplementation(() => ({
      generateOtp: () => Rx.Observable.of(generateOtpErrorResponse)
    }))

    const expected = [
      {
        ...getOtp(),
        payload: void 0,
        meta: void 0
      },
      {
        ...getOtpFail(),
        payload: payload,
        meta: void 0
      }
    ]

    store.dispatch(getOtp())

    expect(store.getActions()).toEqual(expected)
  })

  it('generate OTP throw exception', () => {
    OtpService.mockImplementation(() => ({
      generateOtp: () => Rx.Observable.of(1).map(val => { throw 'error' })
    }))

    const expected = [
      {
        ...getOtp(),
        payload: void 0,
        meta: void 0
      },
      {
        ...getOtpFail(),
        payload: 'error',
        meta: void 0
      }
    ]

    store.dispatch(getOtp())

    expect(store.getActions()).toEqual(expected)
  })
})

describe('validate OTP', () => {
  let store

  beforeEach(() => {
    store = mockStore({
      customerSubmitLoanResponse: {
        customerId: '123456789',
        customerSession: {
          accessToken: '123456789'
        }
      }
    })
  })

  afterEach(() => {
    epicMiddlewares.replaceEpic(validateOtpEpic)
  })

  it('validate OTP success', () => {
    OtpService.mockImplementation(() => ({
      validateOtp: (otpCode) => Rx.Observable.of(validateOtpSuccessResponse)
    }))

    const expected = [
      {
        ...validateOtp(),
        payload: {otpCode: '123456'},
        meta: void 0
      },
      {
        ...validateOtpSuccess(),
        payload: {'jobId': '78b476a1-4f75-4d22-bab9-af1819c12edd'},
        meta: void 0
      }
    ]

    store.dispatch(validateOtp({otpCode: '123456'}))

    expect(store.getActions()).toEqual(expected)
  })

  it('validate OTP invalid', () => {
    OtpService.mockImplementation(() => ({
      validateOtp: (otpCode) => Rx.Observable.of(validateOtpInvalidResponse)
    }))

    const expected = [
      {
        ...validateOtp(),
        payload: {otpCode: '123456'},
        meta: void 0
      },
      {
        ...validateOtpFail(),
        payload: {'status': 'invalid'},
        meta: void 0
      }
    ]

    store.dispatch(validateOtp({otpCode: '123456'}))

    expect(store.getActions()).toEqual(expected)
  })

  it('validate OTP exception', () => {
    OtpService.mockImplementation(() => ({
      validateOtp: (otpCode) => Rx.Observable.of(1).map(val => { throw 'error' })
    }))

    const expected = [
      {
        ...validateOtp(),
        payload: {otpCode: '123456'},
        meta: void 0
      },
      {
        ...validateOtpFail(),
        payload: {'status': 'network_error'},
        meta: void 0
      }
    ]

    store.dispatch(validateOtp({otpCode: '123456'}))

    expect(store.getActions()).toEqual(expected)
  })
})

const payload = {
  'code': 'IC00500',
  'message': 'Error while generating OTP',
  'channel': 'IC'
}
const generateOtpSuccessResponse = {
  'data': null,
  'errors': [],
  'warnings': [],
  'success': true
}
const generateOtpErrorResponse = {
  'data': null,
  'errors': [
    payload
  ],
  'warnings': [],
  'success': false
}

const validateOtpSuccessResponse = {
  'data': {
    'jobId': '78b476a1-4f75-4d22-bab9-af1819c12edd'
  },
  'errors': [],
  'warnings': [],
  'success': true
}

const validateOtpInvalidResponse = {
  'data': null,
  'errors': [
    {
      'code': 'IC00602',
      'message': 'Invalid OTP',
      'channel': 'IC'
    }
  ],
  'warnings': [],
  'success': false
}
