import configureMockStore from "redux-mock-store";
import { createEpicMiddleware } from "redux-observable";
import Rx from "rxjs/Rx";
import "../setupTests";

import ActionType from "../../actions/actionType";
import { createCustomer } from "../../middlewares";
import CustomerService from "../../services/customer.service";
import ActionFactory from "../../actions/actionFactory";

import { lov } from "./mock/lov";

const epicMiddlewares = createEpicMiddleware(createCustomer);
const mockStore = configureMockStore([epicMiddlewares]);

jest.mock("../../services/customer.service");

describe("submitLoan async actions", () => {
  let store;

  beforeEach(() => {
    store = mockStore({ ...globalState });
  });

  afterEach(() => {
    epicMiddlewares.replaceEpic(createCustomer);
  });

  it("should dispatch action CUSTOMER_SUBMIT_LOAN", () => {
    CustomerService.mockImplementation(() => ({
      createCustomer: formValues => Rx.Observable.of(submitLoanResponse)
    }));

    const expectedActions = [
      {
        type: ActionType.CUSTOMER_SUBMIT_LOAN,
        payload: payload,
        meta: void 0
      },
      {
        type: ActionType.CUSTOMER_SUBMIT_LOAN_SUCCESS,
        payload: submitLoanResponse.data,
        meta: void 0
      },
      { meta: undefined, payload: undefined, type: "GET_OTP" },
      { meta: undefined, payload: undefined, type: "LOG_CAMPAIGN_ANALYTICS" }
    ];

    store.dispatch(ActionFactory.create(ActionType.CUSTOMER_SUBMIT_LOAN, payload));

    expect(store.getActions()).toEqual(expectedActions);
  });

  it('should dispatch action create customer fail when error code is "500"', () => {
    CustomerService.mockImplementation(() => ({
      createCustomer: formValues => Rx.Observable.of(submitLoanErrorResponse)
    }));

    const expectedActions = [
      {
        type: ActionType.CUSTOMER_SUBMIT_LOAN,
        payload: payload,
        meta: void 0
      },
      {
        type: ActionType.CUSTOMER_SUBMIT_LOAN_FAILED,
        payload: submitLoanErrorResponse.errors[0],
        meta: void 0
      }
    ];

    store.dispatch(ActionFactory.create(ActionType.CUSTOMER_SUBMIT_LOAN, payload));

    expect(store.getActions()).toEqual(expectedActions);
  });

  it("should dispatch action create customer fail when http request is exception", () => {
    CustomerService.mockImplementation(() => ({
      createCustomer: formValues =>
        Rx.Observable.of(1).map(val => {
          throw "error";
        })
    }));

    const expectedActions = [
      {
        type: ActionType.CUSTOMER_SUBMIT_LOAN,
        payload: payload,
        meta: void 0
      },
      {
        type: ActionType.CUSTOMER_SUBMIT_LOAN_FAILED,
        payload: "error",
        meta: void 0
      }
    ];

    store.dispatch(ActionFactory.create(ActionType.CUSTOMER_SUBMIT_LOAN, payload));

    expect(store.getActions()).toEqual(expectedActions);
  });
});

const payload = { reCaptchaToken: "reCaptchaToken" };

const globalState = {
  form: {
    customerPersonalInformation: {
      values: {
        address: "27/33 Cong Hoa, Quan Tan Binh",
        birthday: { day: 27, month: { id: 9 }, year: 1976 },
        city: "Tangerang (kab)",
        cityCode: "0204-KAB TANGERANG",
        district: "adasd",
        email: "abc@email.com",
        fullName: "FullName",
        fullNameContact: "FullNameContact",
        nik: "1234567890123456",
        phoneNumber: "01666459432",
        phoneNumberContact: "01666459432",
        ward: "ffdfdf",
        emergencyPhoneNumber: "012133234243",
        emergencyFullName: "test",
        relationship: [{ key: "test", value: "test" }]
      }
    },
    customerWorkingInformation: {
      values: {
        companyName: "PT Bank Commonwealth",
        occupation: { value: "Karyawan, Pegawai, Pensiunan" },
        jobTitle: {
          key: "SENIOR MANAJEMEN",
          value: "Swasta - Pejabat Eksekutif"
        },
        lineOfBusinessGroup: {
          key: "",
          value: ""
        },
        lineOfBusiness: {
          key: "",
          value: ""
        }
      }
    },
    customerFinancialInformation: {
      values: {
        haveMonthlyInstallment: false,
        earningPerMonth: "43232432423432",
        amount: 10000000,
        tenure: 12,
        interestInstallment: 1000334,
        reCaptchaToken: "12eweweqwew",
        loanStatus: {
          key: "ELEKTRONIK",
          value: "Elektronik"
        }
      }
    }
  },
  getConfigurationsAPIResponse: {
    configurations: [
      { "apim.personalloan.kiosk.validityperiod": "3600" },
      { "apim.personalloan.web.validityperiod": "3600" },
      { "personalloan.application.validityperiod": "7" },
      { "personalloan.client.recaptcha.google": "6LfljzQUAAAAALQNhxS0pJFGN2yzNwDs6XeqyNjf" },
      { "personalloan.contract.penalty": "6%" },
      { "personalloan.contract.template": "template.html.loan_contract" },
      { "personalloan.income.amount.difference": "500000" },
      { "personalloan.income.month.differenc": "2" },
      { "personalloan.interest.month": "0.0167" },
      { "personalloan.loansubmission.daysfrozenafterapproving": "7" },
      { "personalloan.loansubmission.daysfrozenafterrejecting": "90" },
      { "personalloan.max_amount": "30000000" },
      { "personalloan.max_tenure": "18" },
      { "personalloan.min_amount": "10000000" },
      { "personalloan.min_tenure": "12" },
      { "personalloan.step_amount": "1000000" },
      { "personalloan.time.caching": "3600" },
      { "usb.camera.payslip.height": "1200" },
      { "usb.camera.payslip.width": "1600" }
    ]
  },
  getLOVAPIResponse: {
    ...lov
  },
  loanInformation: {
    amount: 98765432,
    tenure: 18,
    monthlyInstallmentAmount: 765432
  }
};

const submitLoanResponse = {
  data: {
    customerId: 9059,
    customerSession: {
      accessToken: "dbb55f12c4e69e7e6ac5f9ea5576af7",
      applicationNumber: "KPL2018011100000018",
      expiresIn: "3600"
    }
  },
  errors: [],
  warnings: [],
  success: true
};

const submitLoanErrorResponse = {
  data: null,
  errors: [
    {
      code: "IC00500",
      message: "Can not get session key from API key manager",
      channel: "IC"
    }
  ],
  warnings: [],
  success: false
};
