import appReducer from '../../reducers/app.reducer'
import StringUtils from '../../utils/stringUtils'

let initialState = {}

let previousState = {
  key: 'previousStateKey',
  payload: 'previousStatePayload'
}

describe('on dispatched action of not interested', () => {
  it('should return initial state', () => {
    //Arrange

    //Act
    let state = appReducer(undefined, {
      type: 'SOME_OTHER_ACTION'
    })

    //Assert
    expect(state).toEqual(initialState)
  })
})

describe('on dispatched action of not interested', () => {
  it('should return previous state', () => {
    //Arrange

    //Act
    let state = appReducer(previousState, {
      type: 'SOME_OTHER_ACTION'
    })

    //Assert
    expect(state).toEqual(previousState)
  })
})

describe('on dispatched action of type API_ERROR_INTERNAL_SERVER_ERROR', () => {
  it('should set urlToRedirect to /internalServerError', () => {
    //Arrange

    //Act
    let state = appReducer(previousState, {
      type: 'API_ERROR_INTERNAL_SERVER_ERROR'
    })

    //Assert
    expect(state.urlToRedirect).toEqual('/internalServerError')
  })
})

describe('on dispatched action of type API_ERROR_UNAUTHORIZED', () => {
  it('should set urlToRedirect to /unauthorized', () => {
    //Arrange

    //Act
    let state = appReducer(previousState, {
      type: 'API_ERROR_UNAUTHORIZED'
    })

    //Assert
    expect(state.urlToRedirect).toEqual('/unauthorized')
  })
})

describe('on dispatched action of type API_ERROR_FORBIDDEN', () => {
  it('should set urlToRedirect to /forbidden', () => {
    //Arrange

    //Act
    let state = appReducer(previousState, {
      type: 'API_ERROR_FORBIDDEN'
    })

    //Assert
    expect(state.urlToRedirect).toEqual('/forbidden')
  })
})

describe('on dispatched action of type PAGE_REDIRECTED', () => {
  it('should clear urlToRedirect', () => {
    //Arrange

    //Act
    let state = appReducer(previousState, {
      type: 'PAGE_REDIRECTED'
    })

    //Assert
    expect(StringUtils.isEmpty(state.urlToRedirect)).toEqual(true)
  })
})
