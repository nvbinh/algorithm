import { root } from "../../reducers/root.reducer";
import ActionType from "../../actions/actionType";

const companyNames = root.companyNames;
const initialState = {
  isFetching: false,
  searchList: []
};

describe("Company name reducer", () => {
  it("should return the initial state", () => {
    expect(companyNames(void 0, {})).toEqual(initialState);
  });

  it('should handle GET_COMPANY_NAME with "isFetching" value by true', () => {
    expect(companyNames(void 0, { type: ActionType.GET_COMPANY_NAME })).toEqual({
      isFetching: true,
      searchList: []
    });
  });

  it("should return initialState when handle CLEAR_COMPANY_NAME", () => {
    expect(
      companyNames(
        {
          searchList: [],
          isFetching: true
        },
        { type: ActionType.CLEAR_COMPANY_NAME }
      )
    ).toEqual({ searchList: [], isFetching: false });
  });
  it("should return payload data when handle GET_COMPANY_NAME_DONE", () => {
    expect(
      companyNames(
        {
          searchList: [],
          isFetching: true
        },
        {
          type: ActionType.GET_COMPANY_NAME_DONE,
          payload: {
            data: [{ name: "company 001" }, { name: "company 002" }]
          }
        }
      )
    ).toEqual({
      searchList: [{ value: "company 001" }, { value: "company 002" }],
      isFetching: false
    });
  });
});
