import otpStatus from '../../reducers/otpReducer'
import {
  getOtp,
  getOtpSuccess,
  getOtpFail,
  validateOtp,
  validateOtpSuccess,
  validateOtpFail
} from '../../actions/actionCreator'

let initialState = {
  action: void 0,
  validate: {
    status: void 0,
    attempted: 0,
    jobId: void 0
  },
  getOtp: {
    status: void 0,
    attempted: 0
  }
}

describe('Otp reducer, in case validate action', () => {
  it('validate OTP action invoke, otp action is validation, and validation status is processing', () => {
    let state = otpStatus(initialState, validateOtp())

    expect(state).toEqual({
      action: 'VALIDATION',
      validate: {
        status: 'processing',
        attempted: 0,
        jobId: void 0
      },
      getOtp: {
        status: void 0,
        attempted: 0
      }
    })
  })

  it('validate OTP success action invoke, otp action is validation, validation status is "success", and job ID have value "123456789"', () => {
    let state = otpStatus(initialState, validateOtpSuccess({jobId: '123456789'}))

    expect(state).toEqual({
      action: 'VALIDATION',
      validate: {
        status: 'success',
        attempted: 1,
        jobId: '123456789'
      },
      getOtp: {
        status: void 0,
        attempted: 0
      }
    })
  })

  it('validate OTP fail action invoke, otp action is validation, and validation status is expire', () => {
    let state = otpStatus(initialState, validateOtpFail({status: 'expired'}))

    expect(state).toEqual({
      action: 'VALIDATION',
      validate: {
        status: 'expired',
        attempted: 1,
        jobId: void 0
      },
      getOtp: {
        status: void 0,
        attempted: 0
      }
    })
  })

  it('validate OTP fail action invoke, otp action is validation, and validation attempt is increase correctly', () => {
    let state = otpStatus(initialState, validateOtpFail({status: 'invalid'}))

    expect(state).toEqual({
      action: 'VALIDATION',
      validate: {
        status: 'invalid',
        attempted: 1,
        jobId: void 0
      },
      getOtp: {
        status: void 0,
        attempted: 0
      }
    })

    state = otpStatus(state, validateOtpFail({status: 'expired'}))

    expect(state).toEqual({
      action: 'VALIDATION',
      validate: {
        status: 'expired',
        attempted: 2,
        jobId: void 0
      },
      getOtp: {
        status: void 0,
        attempted: 0
      }
    })
  })
})

describe('Otp reducer, in case get Otp action', () => {
  it('invoke get OTP action by resend status, otp action is "GET", and resend attempt is increase by 1', () => {
    let state = otpStatus(initialState, getOtp())

    expect(state).toEqual({
      action: 'GET',
      validate: {
        status: void 0,
        attempted: 0,
        jobId: void 0
      },
      getOtp: {
        status: 'processing',
        attempted: 1
      }
    })
  })

  it('invoke get OTP action by resend status, otp action is "GET", and resend attempt is increase by 2', () => {
    let state = otpStatus(initialState, getOtp())

    expect(state).toEqual({
      action: 'GET',
      validate: {
        status: void 0,
        attempted: 0,
        jobId: void 0
      },
      getOtp: {
        status: 'processing',
        attempted: 1
      }
    })

    state = otpStatus(state, getOtp())

    expect(state).toEqual({
      action: 'GET',
      validate: {
        status: void 0,
        attempted: 0,
        jobId: void 0
      },
      getOtp: {
        status: 'processing',
        attempted: 2
      }
    })
  })

  it('invoke get OTP action success, otp action is "GET", and return success status is true', () => {
    let state = otpStatus(initialState, getOtpSuccess())

    expect(state).toEqual({
      action: 'GET',
      validate: {
        status: void 0,
        attempted: 0,
        jobId: void 0
      },
      getOtp: {
        status: 'success',
        attempted: 0
      }
    })
  })

  it('invoke get OTP action fail, otp action is "GET", and return success status is false', () => {
    let state = otpStatus(initialState, getOtpFail())

    expect(state).toEqual({
      action: 'GET',
      validate: {
        status: void 0,
        attempted: 0,
        jobId: void 0
      },
      getOtp: {
        status: 'failed',
        attempted: 0
      }
    })
  })
})
