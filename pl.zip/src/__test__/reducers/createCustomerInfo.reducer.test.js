import { root } from "../../reducers/root.reducer";
import { PLStatus } from "../../common/constants";
import ActionType from "../../actions/actionType";

const reducer = root.customerSubmitLoanResponse;

const initialState = {
  status: void 0
};

describe("create customer information reducer", () => {
  it("should return initial state", () => {
    expect(reducer(void 0, {})).toEqual(initialState);
  });

  it('should return status state is "processing" when handle CUSTOMER_SUBMIT_LOAN', () => {
    expect(reducer(initialState, { type: ActionType.CUSTOMER_SUBMIT_LOAN })).toEqual({
      status: PLStatus.PROCCESSING
    });
  });

  it('should return status state is "success" and payload data when handle CUSTOMER_SUBMIT_LOAN_SUCCESS', () => {
    expect(
      reducer(initialState, {
        type: ActionType.CUSTOMER_SUBMIT_LOAN_SUCCESS,
        payload: { data: "this is payload" }
      })
    ).toEqual({
      status: PLStatus.SUCCESS,
      data: "this is payload"
    });
  });

  it('should return status state is "failed" and payload data when handle CUSTOMER_SUBMIT_LOAN_FAILED', () => {
    expect(
      reducer(initialState, {
        type: ActionType.CUSTOMER_SUBMIT_LOAN_FAILED,
        payload: { data: "this is payload" }
      })
    ).toEqual({
      status: PLStatus.FAILED,
      data: "this is payload"
    });
  });
});
