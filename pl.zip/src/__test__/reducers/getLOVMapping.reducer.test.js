import getLOVMappingReducer from '../../reducers/getLOVMapping.reducer'

let initialState = {}

let previousState = {
  key: 'previousStateKey',
  payload: 'previousStatePayload'
}

describe('on dispatched action of not interested', () => {
  it('should return initial state', () => {
    //Arrange

    //Act
    let state = getLOVMappingReducer(undefined, {
      type: 'SOME_OTHER_ACTION'
    })

    //Assert
    expect(state).toEqual(initialState)
  })
})

describe('on dispatched action of not interested', () => {
  it('should return previous state', () => {
    //Arrange

    //Act
    let state = getLOVMappingReducer(previousState, {
      type: 'SOME_OTHER_ACTION'
    })

    //Assert
    expect(state).toEqual(previousState)
  })
})

describe('on dispatched action of type GET_LOV_MAPPING_REQUEST_SUCCESS', () => {
  it('should return success response', () => {
    //Arrange
    let successResponse = {
      data: 'success response'
    }

    //Act
    let state = getLOVMappingReducer(previousState, {
      type: 'GET_LOV_MAPPING_REQUEST_SUCCESS',
      payload: successResponse
    })

    //Assert
    expect(state.data).toEqual('success response')
  })
})

describe('on dispatched action of type GET_LOV_MAPPING_REQUEST_FAILED', () => {
  it('should return error response', () => {
    //Arrange
    let errorResponse = {
      errors: [{
        message: 'error message'
      }]
    }

    //Act
    let state = getLOVMappingReducer(previousState, {
      type: 'GET_LOV_MAPPING_REQUEST_FAILED',
      payload: errorResponse
    })

    //Assert
    expect(state.errors[0].message).toEqual('error message')
  })
})