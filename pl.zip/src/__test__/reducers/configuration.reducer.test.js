import { root } from "../../reducers/root.reducer";
import ActionType from "../../actions/actionType";
import { defaultConfig } from "../../common/constants";

const reducer = root.getConfigurationsAPIResponse;
const initialState = {
    configurations: {...defaultConfig},
    tracking: {
        gTagId: undefined,
        fbPixelId: undefined,
        gTagConversionLabel: undefined
    }
};

describe("configuration reducer", () => {
    it("should return the initial state", () => {
        expect(reducer(void 0, {})).toEqual(initialState);
    });

    it("should return initial state when handle GET_LOAN_CONFIG", () => {
        expect(reducer(void 0, {type: ActionType.GET_LOAN_CONFIG})).toEqual(initialState);
    });

    it("should return payload data when handle GET_LOAN_CONFIG_SUCCESS", () => {
        expect(
            reducer(initialState, {
                type: ActionType.GET_LOAN_CONFIG_SUCCESS,
                payload: {data: {configurations: {key: "this is payload data"}}}
            })
        ).toEqual({
            configurations: {key: "this is payload data"},
            tracking: {
                gTagId: undefined,
                fbPixelId: undefined,
                gTagConversionLabel: undefined
            }
        });
    });
});
