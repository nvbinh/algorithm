const sessionStorageMock = {
  storage: {},
  getItem: function (k) {
    return this.storage[k]
  },
  setItem: function (k, v) {
    this.storage[k] = v
  },
  clear: function () {
    this.storage = {}
  }
}
global.sessionStorage = sessionStorageMock
