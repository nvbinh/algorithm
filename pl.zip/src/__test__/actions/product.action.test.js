import {initCustomerSessionBegin, initCustomerSessionSuccess, initCustomerSessionFailed, getProductInfo, getProductInfoSuccess, getProductInfoFailed} from '../../actions/product.action'

/******  getProductInfo ******/
describe('on getProductInfoBegin()', () => {
  it('should return getProductInfoBegin action without payload', () => {
    //Arrange

    //Act
    let action = getProductInfo()

    //Assert.
    expect(action).toEqual({
      type: 'GET_PRODUCT_INFO',
      payload: undefined
    })
  })
})

describe('on getProductInfoSuccess(successResponse)', () => {
  it('should return getProductInfoSuccess action with successResponse as the payload', () => {
    //Arrange

    //Act
    let action = getProductInfoSuccess({})

    //Assert
    expect(action).toEqual({
      type: 'GET_PRODUCT_INFO_REQUEST_SUCCESS',
      payload: {}
    })
  })
})

describe('on getProductInfoFailed(errorResponse)', () => {
  it('should return getProductInfoFailed action with errorResponse as the payload', () => {
    //Arrange

    //Act
    let action = getProductInfoFailed({})

    //Assert
    expect(action).toEqual({
      type: 'GET_PRODUCT_INFO_REQUEST_FAILED',
      payload: {}
    })
  })
})
/******  getProductInfo ******/

/******  initCustomerSession ******/
describe('on initCustomerSessionBegin()', () => {
  it('should return initCustomerSessionBegin action without payload', () => {
    //Arrange

    //Act
    let action = initCustomerSessionBegin()

    //Assert.
    expect(action).toEqual({
      type: 'INIT_CUSTOMER_SESSION_REQUEST_BEGIN',
      payload: undefined
    })
  })
})

describe('on initCustomerSessionSuccess(successResponse)', () => {
  it('should return initCustomerSessionSuccess action with successResponse as the payload', () => {
    //Arrange

    //Act
    let action = initCustomerSessionSuccess({})

    //Assert
    expect(action).toEqual({
      type: 'INIT_CUSTOMER_SESSION_REQUEST_SUCCESS',
      payload: {}
    })
  })
})

describe('on initCustomerSessionFailed(errorResponse)', () => {
  it('should return initCustomerSessionFailed action with errorResponse as the payload', () => {
    //Arrange

    //Act
    let action = initCustomerSessionFailed({})

    //Assert
    expect(action).toEqual({
      type: 'INIT_CUSTOMER_SESSION_REQUEST_FAILED',
      payload: {}
    })
  })
})
/******  initCustomerSession ******/