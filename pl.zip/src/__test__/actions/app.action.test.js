import {setRedirectUrl, getLOVBegin, getLOVSuccess, getLOVFailed}  from '../../actions/app.action'

/******  setRedirectUrl ******/
describe('on setRedirectUrl("http://url-to-redirect")', () => {
  it('should return setRedirectUrl action without payload', () => {
    //Arrange

    //Act
    let action = setRedirectUrl('http://url-to-redirect')

    //Assert
    expect(action).toEqual({
      type: 'SET_REDIRECT_URL',
      payload: 'http://url-to-redirect'
    })
  })
})
/******  setRedirectUrl ******/

/******  getLOV ******/
describe('on getLOVBegin()', () => {
  it('should return getLOVBegin action without payload', () => {
    //Arrange

    //Act
    let action = getLOVBegin()

    //Assert.
    expect(action).toEqual({
      type: 'GET_LOV_REQUEST_BEGIN',
      payload: undefined
    })
  })
})

describe('on getLOVSuccess(successResponse)', () => {
  it('should return getLOVSuccess action with successResponse as the payload', () => {
    //Arrange

    //Act
    let action = getLOVSuccess({})

    //Assert
    expect(action).toEqual({
      type: 'GET_LOV_REQUEST_SUCCESS',
      payload: {}
    })
  })
})

describe('on getLOVFailed(errorResponse)', () => {
  it('should return getLOVFailed action with errorResponse as the payload', () => {
    //Arrange

    //Act
    let action = getLOVFailed({})

    //Assert
    expect(action).toEqual({
      type: 'GET_LOV_REQUEST_FAILED',
      payload: {}
    })
  })
})
/******  getLOV ******/