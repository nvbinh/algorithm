import { getWorkingInfoSuccess } from "./../actions/actionCreator";

const initialState = {
  occupation: {},
  jobTitle: { isEnable: false },
  lineOfBusinessGroup: { isEnable: false },
  lineOfBusiness: { isEnable: false }
};

export const workingInformation = (state = initialState, { type = "-", payload = {}, meta = {} }) => {
  if (type === getWorkingInfoSuccess().type) {
    return { ...state, ...payload };
  } else if (type === "@@redux-form/CHANGE" && meta.form === "customerWorkingInformation") {
    return (
      {
        occupation: {
          ...state,
          jobTitle: { isEnable: false },
          lineOfBusinessGroup: { isEnable: false },
          lineOfBusiness: { isEnable: false }
        },
        jobTitle: {
          ...state,
          lineOfBusinessGroup: { isEnable: false },
          lineOfBusiness: { isEnable: false }
        },
        lineOfBusinessGroup: {
          ...state,
          lineOfBusiness: { isEnable: false }
        },
        lineOfBusiness: {
          ...state
        }
      }[meta.field] || state
    );
  } else {
    return state;
  }
};

export const workingInformationForm = {
  customerWorkingInformation: (state = initialState, { type = "-", payload = {}, meta = {} }) => {
    if (type === getWorkingInfoSuccess().type) {
      return payload.lineOfBusinessGroup &&
        payload.lineOfBusinessGroup.value &&
        payload.lineOfBusiness &&
        payload.lineOfBusiness.value
        ? {
            ...state,
            values: {
              ...state.values,
              lineOfBusinessGroup: payload.lineOfBusinessGroup && payload.lineOfBusinessGroup.value,
              lineOfBusiness: payload.lineOfBusiness && payload.lineOfBusiness.value
            }
          }
        : state;
    } else if (type === "@@redux-form/CHANGE" && meta.form === "customerWorkingInformation") {
      return (
        {
          occupation: {
            ...state,
            values: {
              ...state.values,
              jobTitle: void 0,
              lineOfBusinessGroup: void 0,
              lineOfBusiness: void 0
            }
          },
          jobTitle: {
            ...state,
            values: {
              ...state.values,
              lineOfBusinessGroup: void 0,
              lineOfBusiness: void 0
            }
          },
          lineOfBusinessGroup: {
            ...state,
            values: {
              ...state.values,
              lineOfBusiness: void 0
            }
          }
        }[meta.field] || state
      );
    } else {
      return state;
    }
  }
};
