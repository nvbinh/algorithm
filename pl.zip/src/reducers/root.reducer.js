import { combineReducers } from "redux";
import getLOVReducer from "./getLOV.reducer";
import configurationsReducer from "./configurations.reducer";
import appReducer from "./app.reducer";
import { reducer as formReducer } from "redux-form";
import createCustomerInfoReducer from "./createCustomerInfo.reducer";
import { getLOVMappingReducer } from "./getLOVMapping.reducer";
import getDecisionStatusReducer from "./getDecisionStatus.reducer";
import companyNameReducer from "./companyNameReducer";
import otpReducer from "./otpReducer";
import ActionType from "../actions/actionType";
import { workingInformation, workingInformationForm } from "./workingInformation";
import { loanInformation } from "./loanInformation";

const defaultConfigReducer = {
  getLOVAPIResponse: {},
  getConfigurationsAPIResponse: {},
  getLovMappingResponse: {}
};
const getDefautReducer = (configReducer = defaultConfigReducer) =>
  configReducer;

export const root = {
  form: formReducer.plugin(workingInformationForm),
  app: appReducer,
  getLOVAPIResponse: getLOVReducer,
  customerSubmitLoanResponse: createCustomerInfoReducer,
  getConfigurationsAPIResponse: configurationsReducer,
  getLovMappingResponse: getLOVMappingReducer,
  decisionStatus: getDecisionStatusReducer,
  companyNames: companyNameReducer,
  otpStatus: otpReducer,
  workingInformation,
  loanInformation
};

export const plReducer = combineReducers(root);

const rootReducer = (state, action) => {
  if (action.type === ActionType.RESET_APP) {
    const {
      getLOVAPIResponse,
      getConfigurationsAPIResponse,
      getLovMappingResponse
    } = state;
    const configReducer = getDefautReducer({
      getLOVAPIResponse,
      getConfigurationsAPIResponse,
      getLovMappingResponse
    });

    state = { ...configReducer };
  }

  return plReducer(state, action);
};

export default rootReducer;
