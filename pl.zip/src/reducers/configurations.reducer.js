import ActionType from './../actions/actionType'
import { defaultConfig } from './../common/constants'

const initialState = {
    configurations: {...defaultConfig},
    tracking: {
        gTagId: undefined,
        fbPixelId: undefined,
        gTagConversionLabel: undefined
    }
}

export const configurationsReducer = (state = initialState, action) => {
    switch (action.type) {
        case ActionType.GET_LOAN_CONFIG:
            return state
        case ActionType.GET_LOAN_CONFIG_SUCCESS:
            return {
                ...state,
                configurations: action.payload.data.configurations
            }
        case ActionType.GET_TRACKING_ID_SUCCESS:
            return {
                ...state,
                tracking: {
                    ...action.payload.data
                }
            }
        default:
            return state
    }
}

export default configurationsReducer
