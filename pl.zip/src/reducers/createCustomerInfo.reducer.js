import ActionType from '../actions/actionType'
import { PLStatus } from '../common/constants'

const initialState = {
  status: void 0
}

const createCustomerInfoReducer = (state = initialState, {type, payload}) => {
  switch (type) {
    case ActionType.CUSTOMER_SUBMIT_LOAN:
      return {
        ...state,
        status: PLStatus.PROCCESSING
      }
    case ActionType.CUSTOMER_SUBMIT_LOAN_SUCCESS:
      return {
        ...state,
        ...payload,
        status: PLStatus.SUCCESS
      }
    case ActionType.CUSTOMER_SUBMIT_LOAN_FAILED:
      return {
        ...state,
        ...payload,
        status: PLStatus.FAILED
      }
    default:
      return state
  }
}

export default createCustomerInfoReducer
