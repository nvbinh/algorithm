import ActionType from './../actions/actionType'

const initialState = {}

export const getLOVMappingReducer = (state = initialState, action) => {
  switch (action.type) {
    case ActionType.GET_LOV_MAPPING:
      return state
    case ActionType.GET_LOV_MAPPING_REQUEST_SUCCESS:
      return action.payload
    case ActionType.GET_LOV_MAPPING_REQUEST_FAILED:
      return action.payload
    default:
      return state
  }
}

export default getLOVMappingReducer