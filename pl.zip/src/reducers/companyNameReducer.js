import ActionType from "../actions/actionType";

const initialState = {
  searchList: [],
  isFetching: false
};

const companyNameReducer = (state = initialState, { type, payload }) => {
  switch (type) {
    case ActionType.GET_COMPANY_NAME:
      return { ...state, isFetching: true, searchList: [] };
    case ActionType.CLEAR_COMPANY_NAME:
      return { ...state, isFetching: false, searchList: [] };
    case ActionType.GET_COMPANY_NAME_DONE:
      return {
        searchList: payload.data.map(({ name: value }) => ({ value })),
        isFetching: false
      };
    default:
      return state;
  }
};

export default companyNameReducer;
