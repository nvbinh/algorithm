import ActionType from './../actions/actionType'
import { DecisionStatus } from '../common/constants'

const initialState = {
  jobStatus: void 0,
  loanInfo: {
    status: void 0,
    rejectedReason: void 0,
    detail: {
      approvedLoanInformation: {},
      additionalInformation: {}
    }
  }
}

export const getDecisionStatusReducer = (state = initialState, action) => {
  switch (action.type) {
    case ActionType.GET_DECISION_STATUS:
      return state
    case ActionType.GET_DECISION_STATUS_SUCCESS:
      const { jobStatus, decisionInformation } = action.payload
      const loanInfo = decisionInformation
        ? {
          loanInfo: {
            status: decisionInformation.loanStatus,
            rejectedReason: decisionInformation.rejectedReasons.length > 0 && decisionInformation.rejectedReasons[0].code,
            detail: {...decisionInformation}
          }
        }
        : {}
      return {
        ...state,
        jobStatus,
        ...loanInfo
      }
    case ActionType.GET_DECISION_STATUS_FAILED:
      return {
        ...state,
        jobStatus: DecisionStatus.FAILED
      }
    default:
      return state
  }
}

export default getDecisionStatusReducer
