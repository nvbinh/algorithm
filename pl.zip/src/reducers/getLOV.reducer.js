import ActionType from './../actions/actionType'

const initialState = {
  data: {}
}

export const getLOVReducer = (state = initialState, action) => {
  switch (action.type) {
    case ActionType.GET_LOV_REQUEST_BEGIN:
      return state

    case ActionType.GET_LOV_REQUEST_SUCCESS:
      return {...state, ...action.payload}

    case ActionType.GET_LOV_REQUEST_FAILED:
      return {...state, ...action.payload}

    default:
      return state
  }
}

export default getLOVReducer
