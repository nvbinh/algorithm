import ActionType from './../actions/actionType'
import { Otp, OtpAction, PLStatus, OtpStatus } from '../common/constants'

const initialState = {
  action: void 0,
  validate: {
    status: void 0,
    attempted: 0,
    jobId: void 0
  },
  getOtp: {
    status: void 0,
    attempted: 0
  }
}

export const otpReducer = (state = initialState, action) => {
  const {
    validate,
    validate: {attempted: attemptedValidation},
    getOtp,
    getOtp: {attempted: attemptedSendOtp}
  } = state
  switch (action.type) {
    case ActionType.VALIDATE_OTP:
      return {
        ...state,
        action: OtpAction.VALIDATION,
        validate: {
          ...validate,
          status: 'processing'
        }
      }
    case ActionType.VALIDATE_OTP_SUCCESS:
      const {jobId} = action.payload
      return {
        ...state,
        action: OtpAction.VALIDATION,
        validate: {
          ...validate,
          attempted: attemptedValidation + 1,
          status: PLStatus.SUCCESS,
          jobId
        }
      }
    case ActionType.VALIDATE_OTP_FAIL:
      const {status} = action.payload
      const attempted = attemptedValidation + 1
      return {
        ...state,
        action: OtpAction.VALIDATION,
        validate: {
          ...validate,
          attempted,
          status: attempted === Otp.MAX_ATTEMPT ? OtpStatus.MAX_ATTEMPT : status
        }
      }
    case ActionType.GET_OTP:
      return {
        ...state,
        action: OtpAction.GET,
        getOtp: {
          status: PLStatus.PROCCESSING,
          attempted: attemptedSendOtp + 1
        },
        validate: {
          status: void 0,
          attempted: 0,
          jobId: void 0
        }
      }
    case ActionType.GET_OTP_SUCCESS:
      return {
        ...state,
        action: OtpAction.GET,
        getOtp: {
          ...getOtp,
          status: PLStatus.SUCCESS
        }
      }
    case ActionType.GET_OTP_FAIL:
      return {
        ...state,
        action: OtpAction.GET,
        getOtp: {
          ...getOtp,
          status: PLStatus.FAILED
        }
      }
    default:
      return state
  }
}

export default otpReducer
