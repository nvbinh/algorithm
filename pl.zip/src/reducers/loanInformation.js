import ActionType from './../actions/actionType'

export const loanInformation = (state = {}, action) => {
  switch (action.type) {
    case ActionType.UPDATE_LOAN_INFORMATION:
      return {...state, ...action.payload}
    default:
      return state
  }
}

