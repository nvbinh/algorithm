import Fingerprint from 'fingerprintjs'

export default class DeviceUtils {

  /**
   * get device msisdn number using the browser's fingerprint
   */
  static getDeviceId () {
    return new Fingerprint().get()
  }
}