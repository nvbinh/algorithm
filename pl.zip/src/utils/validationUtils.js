import ObjectUtils from "./objectUtils";
import StringUtils from "./stringUtils";
import { Defines as Constants, Defines } from "../common/constants";

function calculateAge(birthDay, birthMonth, birthYear) {
  let currentDate = new Date();
  let currentYear = currentDate.getFullYear();
  let currentMonth = currentDate.getMonth();
  let currentDay = currentDate.getDate();
  let calculatedAge = currentYear - birthYear;

  if (
    currentMonth < birthMonth - 1 ||
    (birthMonth - 1 === currentMonth && currentDay < birthDay)
  ) {
    calculatedAge--;
  }
  return calculatedAge;
}

const ValidationUtils = {
  customerPersonalInformation: {
    nikValidation: value => {
      if (!value) {
        return "Masukkan nomor KTP Anda";
      } else if (!/^[0-9]*$/.test(value)) {
        return "Nomor KTP harus diisi dengan angka";
      } else if (value.length !== 16) {
        return "Nomor KTP Anda harus 16 angka";
      }
      return undefined;
    },
    nameValidation: value => {
      if (!value) {
        return "Masukkan nama lengkap Anda";
      } else if (!/^[a-zA-Z\s]*$/.test(value)) {
        return "Nama harus diisi dengan huruf";
      }
      return undefined;
    },
    contactNameValidation: value => {
      if (!value) {
        return "Masukkan nama lengkap kontak darurat";
      } else if (!/^[a-zA-Z\s]*$/.test(value)) {
        return "Nama harus diisi dengan huruf";
      }
      return undefined;
    },
    phoneNumberValidation: value => {
      let emptyCheck = emptyValidation("Masukkan nomor ponsel Anda");
      let lengthCheck = lengthValidation("Nomor ponsel Anda tidak valid");
      return validatePhoneNumber(value, undefined, [
        emptyCheck,
        undefined,
        lengthCheck
      ]);
    },
    emergencyPhoneNumberValidation: (value, allValues) => {
      let matchCheck = matchValidation(
        "Nomor ponsel kontak darurat harus berbeda dengan nomor ponsel Anda"
      );
      let previousPhoneNumber = allValues ? allValues.phoneNumber : undefined;
      return validatePhoneNumber(value, previousPhoneNumber, [
        commonEmptyValidation,
        matchCheck,
        commonLengthValidation
      ]);
    },
    emergencyContactNameValidation: value => {
      if (!value) {
        return "Masukkan nama lengkap kontak darurat";
      } else if (!/^([a-zA-Z\s])*$/.test(value)) {
        return "Nama harus diisi dengan huruf";
      }
      return undefined;
    },
    contactPhoneValidation: value => {
      return validatePhoneNumber(value, undefined, [
        commonEmptyValidation,
        undefined,
        commonLengthValidation
      ]);
    },
    dayOfBirthValidation: value =>
      value ? undefined : "Masukkan tanggal lahir Anda",
    emailValidation: value => {
      if (!value) {
        return "Masukkan alamat email Anda";
      } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(value)) {
        return "Format alamat email Anda tidak valid";
      }
      return undefined;
    },
    wardValidation: value => {
      if (!value) {
        return "Masukkan kelurahan Anda";
      } else if (!/^[a-zA-Z0-9-,.()/'\s]*$/.test(value)) {
        return "Format yang Anda masukkan tidak valid";
      }
      return undefined;
    },
    cityValidation: value => {
      if (!value) {
        return "Pilih kota Anda";
      }
      return undefined;
    },
    relationshipValidation: value => {
      if (!value) {
        return "Pilih hubungan Anda";
      }
      return undefined;
    },
    districtValidation: value => {
      if (!value) {
        return "Masukkan kecamatan Anda";
      } else if (!/^[a-zA-Z0-9-,.()/'\s]*$/.test(value)) {
        return "Format yang Anda masukkan tidak valid";
      }
      return undefined;
    },
    addressValidation: (value, maxLength) => {
      if (!value) {
        return "Masukkan alamat Anda";
      } else if (
        !/^[a-zA-Z0-9-,.()/'\s\u2018\u2019]*$/.test(value) ||
        value.length > maxLength
      ) {
        return "Format yang Anda masukkan tidak valid";
      }
      return undefined;
    },
    loanPurposeValidation: value => {
      if (!value) {
        return "Pilih tujuan pinjaman Anda";
      }
      return undefined;
    },
    dobValidation: (
      { day, month, year } = { day: "", month: {}, year: "" }
    ) => {
      if (
        StringUtils.isEmpty(day) ||
        (month && Object.keys(month).length === 0) ||
        StringUtils.isEmpty(year)
      ) {
        return "Masukkan tanggal lahir Anda";
      }

      let monthLength = new Date(year, month.id, 0).getDate();
      if (
        year < Constants.MIN_YEAR_LOAN_CUSTOMER ||
        day <= 0 ||
        day > monthLength
      ) {
        return "Tanggal lahir yang Anda masukkan tidak valid";
      }

      let age = calculateAge(day, month, year);
      if (
        age < Constants.MIN_AGE_LOAN_CUSTOMER ||
        age > Constants.MAX_AGE_LOAN_CUSTOMER
      ) {
        return "Usia Anda tidak sesuai dengan Syarat & Ketentuan KTA TymeDigital";
      }
      return undefined;
    }
  },

  customerFinancialInformation: {
    earningsPerMonthValidation: value => {
      const earningPerMonth = value && value.replace(/\./g, "");
      if (!earningPerMonth) {
        return "Masukkan penghasilan per bulan Anda";
      } else if (!earningPerMonth.match("^([0-9]+)$")) {
        return "Penghasilan per bulan harus diisi dengan angka";
      } else if (Defines.MIN_MONTHLY_INCOME_IN_RUPIAH > earningPerMonth) {
        return "Penghasilan per bulan harus minimum 5 juta rupiah";
      }
      return undefined;
    },
    monthlyInstallmentValidation: (value, allValues) => {
      const totalMonthlyInstallment = value && value.replace(/\./g, "");
      const haveMonthlyInstallment =
        allValues && allValues.haveMonthlyInstallment;
      if (!haveMonthlyInstallment) {
        return undefined;
      }
      if (!totalMonthlyInstallment) {
        return "Masukkan total angsuran per bulan Anda";
      } else if (!totalMonthlyInstallment.match("^([0-9]+)$")) {
        return "Total angsuran per bulan harus diisi dengan angka";
      }
      return undefined;
    },
    monthlyInstallmentSelection: value => {
      if (ObjectUtils.isEmpty(value)) {
        return "Anda harus menjawab pertanyaan ini";
      }
      return undefined;
    }
  }
};

const validatePhoneNumber = (
  phoneNumber1,
  phoneNumber2,
  [emptyValidation, matchValidation, lengthValidation]
) => {
  return matchValidation
    ? emptyValidation(phoneNumber1) ||
        lengthValidation(phoneNumber1) ||
        matchValidation(phoneNumber1, phoneNumber2)
    : emptyValidation(phoneNumber1) || lengthValidation(phoneNumber1);
};

const emptyValidation = message => phoneNumber => {
  if (!phoneNumber) return message;
  return undefined;
};

const lengthValidation = message => phoneNumber => {
  if (
    !/^(62)[0-9]{8,13}$/.test(phoneNumber) &&
    !/^(0)[0-9]{9,14}$/.test(phoneNumber)
  )
    return message;
  return undefined;
};

const commonEmptyValidation = emptyValidation(
  "Masukkan nomor ponsel kontak darurat"
);
const commonLengthValidation = lengthValidation(
  "Nomor ponsel kontak darurat tidak valid"
);

const matchValidation = message => (phoneNumber1, phoneNumber2) => {
  if (
    phoneNumber1 &&
    phoneNumber2 &&
    phoneNumber1.match(PHONE_REGEX) &&
    phoneNumber2.match(PHONE_REGEX) &&
    phoneNumber1.match(PHONE_REGEX)[2] === phoneNumber2.match(PHONE_REGEX)[2]
  )
    return message;
  return undefined;
};

const PHONE_REGEX = /^(0|62)([0-9]*)$/;

export default ValidationUtils;
