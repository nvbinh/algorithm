import { LoanSimulation, MarriageStatus } from '../common/constants'

export const getDependent = (numberOfDependents) => Math.min(numberOfDependents, 4)

export const getProxyExpensePercent = (proxyExpensePercentMapping) => (marriageStatus) => proxyExpensePercentMapping[marriageStatus]

export const getMarriageStatus = (marriageStatusInput) => (numberOfDependents) =>
  marriageStatusInput === MarriageStatus.MARRIED
    ? MarriageStatus.MARRIED
    : numberOfDependents > 0
      ? MarriageStatus.SINGLE_PARENT
      : MarriageStatus.SINGLE

export const calculateProxyExpense = (proxyExpensePercentMapping, proxyExpenseOnNumberOfChildren) => (marriageStatusInput, numberOfDependentsInput, declaredIncome) => {
  const marriageStatus = getMarriageStatus(marriageStatusInput)(numberOfDependentsInput)
  const proxyExpensePercent = getProxyExpensePercent(proxyExpensePercentMapping)(marriageStatus)
  const numberOfDependents = getDependent(numberOfDependentsInput)

  return (proxyExpensePercent * declaredIncome) + (numberOfDependents * proxyExpenseOnNumberOfChildren)
}

export const calculateMonthlyIncome = (declaredIncome, proxyExpense) => declaredIncome - proxyExpense

const calculateFirstEligibleMonthlyInstallment = (dbr) => (monthlyIncome, totalInstallment) =>
  (dbr * monthlyIncome) - totalInstallment

export const calculateEligibleMonthlyInstallment = (eligibleLoanAmount, tenure, interest) =>
  Math.round(eligibleLoanAmount / tenure + (eligibleLoanAmount * interest * tenure) / tenure)

export const calculateCreditLimit = (dbr) => (monthlyIncome, totalInstallment, tenure, interest) => {
  const eligibleMonthlyInstallment = calculateFirstEligibleMonthlyInstallment(dbr)(monthlyIncome, totalInstallment)
  return roundDown(eligibleMonthlyInstallment * tenure / (1 + (interest * tenure)))
}

export const roundDown = (number) => {
  const THOUSAND = 1000
  let multiplesNumber = THOUSAND
  while (number / multiplesNumber >= THOUSAND) {
    multiplesNumber *= THOUSAND
  }
  let roundedMultiples = Math.floor(number / multiplesNumber)
  return roundedMultiples * multiplesNumber
}

export const calculateEligibleLoanAmount = (monthlyIncome, creditLimit, maxLoanAmount) =>
  Math.min(
    Math.min(
      creditLimit,
      roundDown(5 * monthlyIncome)
    ),
    maxLoanAmount
  )
