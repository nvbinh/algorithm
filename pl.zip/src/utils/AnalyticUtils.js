import ReactPixel from "react-facebook-pixel";
import { Gtagger } from "gtagger";

import StringUtils from "./stringUtils";
import { PL_KEY } from "../common/constants";
import ObjectUtils from "./objectUtils";

const AnalyticUtils = {
  getUtmObject: () =>
    StringUtils.jsonToObject(
      sessionStorage.getItem(PL_KEY.UTM_CAMPAIN_SESSION_STORAGE)
    ),

  getTracking: utmParam => {
    const utmObj = AnalyticUtils.getUtmObject();
    return !ObjectUtils.isEmpty(utmObj) ? utmObj[utmParam] : "";
  },

  activeFacebookTracking: id => {
    ReactPixel.init(id);
    ReactPixel.pageView();
  },

  activeFacebookTrackingEvent: eventName => {
    ReactPixel.trackCustom(eventName);
  },

  initGtag: gtmId => Gtagger.initialize(gtmId),

  runGtag: (...parameters) => Gtagger.run(...parameters),

  activeGtagTrackingEvent: (gTagConversionLabel, pageName) =>
  {
      try {
        JSON.parse(gTagConversionLabel)
          .forEach(({ event_name, conversion_label, page }) =>
            page
              && page.toLowerCase() === pageName.toLowerCase()
              && Gtagger.run("event", event_name, conversion_label)
          )
      }
      catch (e) {
      }
  },

};

export default AnalyticUtils;
