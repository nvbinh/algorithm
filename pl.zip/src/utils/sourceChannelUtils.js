import { PL_SOURCE } from './../common/constants'
export const getSourceChannel = ({source = 'AC'}) => {
  let cleanSourceChannel = source.replace(/\s/g, '').toUpperCase()
  return [PL_SOURCE.EC, PL_SOURCE.TS].includes(cleanSourceChannel)? cleanSourceChannel : PL_SOURCE.AC
}