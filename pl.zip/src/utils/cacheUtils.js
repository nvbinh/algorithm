import { Observable } from 'rxjs'
import { defaultConfig } from '../common/constants'
import StringUtils from './stringUtils'

const CacheUtils = {
  // Cached keys
  LOCAL_STORAGE_KEY_GET_LOV: 'GET_LOV',
  LOCAL_STORAGE_KEY_GET_LOV_MAPPING: 'GET_LOV_MAPPING',
  LOCAL_STORAGE_KEY_GET_LOAN_CONFIG: 'GET_LOAN_CONFIG',
  SESSION_STORAGE_TRACKING_TIME: 'SESSION_STORAGE_TRACKING_TIME',

  // Utility functions
  /**
   * cachedTimeout value in milliseconds
   */
  getCachedTimeout: cachedData => {
    let config = (cachedData && cachedData.data && cachedData.data.configurations) || []
    return (config.timeCaching * 1000) || defaultConfig.timeCaching
  },

  isCachedDataStale: (lastFetched, cachedTimeout = defaultConfig.timeCaching) => {
    if (lastFetched === undefined) return true
    // check whether to perform the async call if the data is older than the allowed limit
    return (Date.now() - lastFetched) > cachedTimeout
  },

  loadCachedData: cachedKey => {
    return StringUtils.jsonToObject(sessionStorage.getItem(cachedKey))
  },

  saveDataToCache: (cachedKey, data) => {
    sessionStorage.setItem(
      cachedKey,
      JSON.stringify(data)
    )
  },

  /**
   * Utility function for handling request from server:
   *  - Return Observable of cached data if it's available and still is up-to-date.
   *  - Return Observable of new data from API if it's not available or data is stale (outdated).
   * @param: requestObservable is an Observable that trigger an api call from BaseService
   * @param: cachedKey is the key of the service that would be called for caching
   *
   */
  handleRequest: (requestObservable, cachedKey) => {
    let cachedData = CacheUtils.loadCachedData(cachedKey)
    let lastFetched = cachedData && cachedData.lastFetched
    let localConfigurationsData = CacheUtils.loadCachedData(CacheUtils.LOCAL_STORAGE_KEY_GET_LOAN_CONFIG)
    let cachedDataObservable = CacheUtils.isCachedDataStale(lastFetched, CacheUtils.getCachedTimeout(localConfigurationsData))
      ? Observable.empty() : Observable.of(cachedData)
    return (
      Observable.concat(
        cachedDataObservable,
        requestObservable
          .map(resp => resp.data)
          .map(data => ({data, lastFetched: Date.now()}))
          .do(data => CacheUtils.saveDataToCache(cachedKey, data))
          .catch(() => Observable.empty())
      )
        .first()
    )
  }
}

export default CacheUtils
