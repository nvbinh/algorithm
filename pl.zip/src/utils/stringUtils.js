import { PL_KEY_SOURCE } from "../common/constants";

export default class StringUtils {
  /**
   * Helper method to check if a given string is undefined, null or blank
   * @param {input string} input string to check empty
   */
  static isEmpty(input) {
    return input === undefined || input === null || input === "" || input === "undefined";
  }

  /**
   * capitalize the first character of each word in a string
   * @param {*String} inputString input string
   */
  static capitalizeFirstCharacterOfEachWord(inputString) {
    return this.isEmpty(inputString)
      ? ""
      : inputString.toLowerCase().replace(/(^|\s)[a-z]/g, function(f) {
          return f.toUpperCase();
        });
  }

  static getQueryParams(query = "", isAcceptedNotDefineValue) {
    if (!query) {
      return {};
    }

    return (/^[?#]/.test(query) ? query.slice(1) : query).split("&").reduce((acc, cur) => {
      const [key, value] = cur.split("=");
      !!key &&
        (!!value || isAcceptedNotDefineValue) &&
        (acc[key] = decodeURIComponent(!!value ? value.replace(/\+/g, " ") : ""));
      return acc;
    }, {});
  }

  static getQueryParamsAllowingUndefinedUtmSource(query = "") {
    let result = StringUtils.getQueryParams(query, true);
    return Object.keys(result)
      .filter(key => (key !== PL_KEY_SOURCE && !!result[key]) || key === PL_KEY_SOURCE)
      .reduce((obj, key) => {
        obj[key] = result[key];
        return obj;
      }, {});
  }

  static equalsIgnoreCase(str1, str2) {
    return !this.isEmpty(str1) && !this.isEmpty(str2) && str1.toLowerCase() === str2.toLowerCase();
  }

  static jsonToObject(str) {
    try {
      return JSON.parse(str);
    } catch (e) {
      return {};
    }
  }
}
