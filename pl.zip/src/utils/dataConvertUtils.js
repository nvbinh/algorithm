import StringUtils from "./stringUtils";
import ObjectUtils from "./objectUtils";
import "./arrayUtils";

export default class DataConvertUtils {
  /**
   * Helper function to convert a list of LOV's provinces into list of Option objects to be used by the OptionList component
   * @param lovs
   * @returns List of towns/cities
   */
  static convertLOVToListOfCity(province = []) {
    return province
      .filter(province => !StringUtils.isEmpty(province.town))
      .map(province =>
        province.town.map(function(town) {
          return {
            key: town.code,
            value: StringUtils.capitalizeFirstCharacterOfEachWord(town.name)
          };
        })
      )
      .reduce((towns1, towns2) => towns1.concat(towns2), []);
  }

  /**
   * Helper function to get a Emergency Relation ship list to be used by the Emergency Contact widget
   * @param {*list of LOV return from getLOV API} lovs
   */
  static convertLOVToListOfEmergencyContactRelationship(lovs) {
    if (
      ObjectUtils.isEmpty(lovs) ||
      Array.isArray(lovs) ||
      ObjectUtils.isEmpty(lovs.relationship) ||
      !Array.isArray(lovs.relationship)
    ) {
      return [];
    }

    return lovs.relationship.map(item => ({
      key: item.code,
      value: item.name
    }));
  }
}
