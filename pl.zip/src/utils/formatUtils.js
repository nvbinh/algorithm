import moment from "moment";
import StringUtils from "./stringUtils";

const PATTERN_NON_NUMBER = /\D/g;
/**
 * Format currency to split hundred, thousand,... by specific symbol
 * @param symbol - The specific symbol like as dot, comma,...
 */
export const thousandNumberFormat = symbol => number => {
  if (number === undefined) return "";
  number = number.toString().replace(PATTERN_NON_NUMBER, "");
  if (StringUtils.isEmpty(number)) return "";
  return parseInt(number, 10)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, symbol);
};

const ZERO_PHONE_REGEX = /^(0)([0-9]*)$/;
const SIXTY_TWO_PHONE_REGEX = /^(62)([0-9]*)$/;

export const formatPhoneNumber = phoneNumber => {
  if (StringUtils.isEmpty(phoneNumber)) return "";
  if (ZERO_PHONE_REGEX.test(phoneNumber))
    return `+62${phoneNumber.substring(1)}`;
  if (SIXTY_TWO_PHONE_REGEX.test(phoneNumber)) return `+${phoneNumber}`;
  return phoneNumber;
};

export const formatCurrency = thousandNumberFormat(".");

export const formatLoanExpireDate = date => {
  return moment(date).format("DD/MM/YY");
};

export const maskEmailAddress = email => {
  if (StringUtils.isEmpty(email)) return "";
  let parts = email.split("@");
  if (parts.length > 1) {
    let result = parts[0];
    if (result.length === 1) {
      result = `${result}**@${parts[1]}`;
    } else {
      result = `${result.substring(0, 2)}**@${parts[1]}`;
    }
    return result;
  }
  return email;
};

export const formatSecurityPhone = phoneNumber =>
  (!!phoneNumber && phoneNumber.replace(/(\d{3})(\d{5})(\d+)/g, "$1*****$3")) ||
  phoneNumber;

export const roundFloatingIssue = number => Math.round(number * 100 * 100) / 100;
