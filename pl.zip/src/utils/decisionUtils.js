export const calculateLoanExpireDate = (
  decisionDate = new Date(),
  validityPeriod
) => new Date(decisionDate + validityPeriod * 86400 * 1000);
